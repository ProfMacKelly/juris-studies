> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-6.-the-body-as-commodity) · Snapshot: 2026-11-02 · Original path: `unit-6.-the-body-as-commodity`

---

# UNIT 6. The Body as Commodity

