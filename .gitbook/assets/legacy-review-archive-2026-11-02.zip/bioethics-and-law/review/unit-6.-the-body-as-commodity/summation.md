> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-6.-the-body-as-commodity/summation) · Snapshot: 2026-11-02 · Original path: `unit-6.-the-body-as-commodity/summation`

---

# Summation

In this unit, you have seen how the courts have confronted the complicated issues that arise when the body becomes a commodity, specifically the question of whether the body is a property or a privacy interest.

You have also observed how treating the body as either property or privacy interest quickly erodes the Biblical view of the human body and paves the way for ever more expansive commodification of the body.

Among other things, this unit may have demonstrated how courts can lose sight of the most fundamental aspects of a case (e.g., what is the human body, who does it belong to, and whether the sanctity of life and the _imago dei_ forbid these practices) by focusing instead on the narrow issues (e.g., where the descendent intended for his sperm to be used for conceiving a child after his death).

In the [next unit](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-7), we will consider the issue of reproduction, specifically, the conflicting interests of mother and child that can lead either to birth or abortion.







