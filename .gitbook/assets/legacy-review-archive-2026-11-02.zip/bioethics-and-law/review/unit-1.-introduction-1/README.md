> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-1.-introduction-1) · Snapshot: 2026-11-02 · Original path: `unit-1.-introduction-1`

---

# UNIT 1. Introduction

