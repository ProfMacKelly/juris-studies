> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-1.-introduction-1/1.4-foundations-of-the-bioethics-law-relationship) · Snapshot: 2026-11-02 · Original path: `unit-1.-introduction-1/1.4-foundations-of-the-bioethics-law-relationship`

---

# 1.4 Foundations of the Bioethics-Law Relationship

## Contents

<table data-view="cards"><thead><tr><th></th><th></th><th></th><th data-hidden data-card-target data-type="content-ref"></th></tr></thead><tbody><tr><td><strong>1.4.1</strong> <em>Canterbury v. Spence</em></td><td></td><td></td><td><a href="1.4-foundations-of-the-bioethics-law-relationship/1.4.1-canterbury-v.-spence">1.4.1-canterbury-v.-spence</a></td></tr><tr><td><strong>1.4.2</strong> <em>K.A.C. v. Benson</em></td><td></td><td></td><td><a href="1.4-foundations-of-the-bioethics-law-relationship/1.4.2-k.a.c.-v.-benson">1.4.2-k.a.c.-v.-benson</a></td></tr><tr><td></td><td></td><td></td><td></td></tr></tbody></table>
