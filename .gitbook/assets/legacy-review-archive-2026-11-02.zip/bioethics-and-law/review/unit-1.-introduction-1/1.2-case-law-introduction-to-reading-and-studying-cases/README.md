> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-1.-introduction-1/1.2-case-law-introduction-to-reading-and-studying-cases) · Snapshot: 2026-11-02 · Original path: `unit-1.-introduction-1/1.2-case-law-introduction-to-reading-and-studying-cases`

---

# 1.2 Case Law: Introduction to Reading & Studying Cases

## Contents

<table data-view="cards"><thead><tr><th></th><th></th><th></th><th data-hidden data-card-target data-type="content-ref"></th></tr></thead><tbody><tr><td><strong>1.2.1</strong> How to Read a Case</td><td></td><td></td><td><a href="1.2-case-law-introduction-to-reading-and-studying-cases/1.2.1-how-to-read-a-case">1.2.1-how-to-read-a-case</a></td></tr><tr><td><strong>1.2.2</strong> How to Brief a Case</td><td></td><td></td><td><a href="1.2-case-law-introduction-to-reading-and-studying-cases/1.2.2-how-to-brief-a-case">1.2.2-how-to-brief-a-case</a></td></tr><tr><td><strong>1.2.3</strong> Examples: Case &#x26; Case Brief (with Explanatory Annotations)</td><td></td><td></td><td><a href="1.2-case-law-introduction-to-reading-and-studying-cases/1.2.3-examples-case-and-case-brief-with-explanatory-annotations">1.2.3-examples-case-and-case-brief-with-explanatory-annotations</a></td></tr></tbody></table>
