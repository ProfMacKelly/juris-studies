> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-1.-introduction-1/1.2-case-law-introduction-to-reading-and-studying-cases/1.2.3-examples-case-and-case-brief-with-explanatory-annotations) · Snapshot: 2026-11-02 · Original path: `unit-1.-introduction-1/1.2-case-law-introduction-to-reading-and-studying-cases/1.2.3-examples-case-and-case-brief-with-explanatory-annotations`

---

# 1.2.3 Examples: Case & Case Brief (with Explanatory Annotations)

<table data-view="cards"><thead><tr><th></th><th></th><th></th><th data-hidden data-card-target data-type="content-ref"></th></tr></thead><tbody><tr><td><strong>1.2.3.1</strong> Case: Florida v. Jardines (Annotated)</td><td></td><td></td><td><a href="1.2.3-examples-case-and-case-brief-with-explanatory-annotations/1.2.3.1-case-florida-v.-jardines-annotated">1.2.3.1-case-florida-v.-jardines-annotated</a></td></tr><tr><td><strong>1.2.3.2</strong> Case Brief: Florida v. Jardines (Annotated)</td><td></td><td></td><td><a href="1.2.3-examples-case-and-case-brief-with-explanatory-annotations/1.2.3.2-case-brief-florida-v.-jardines-annotated">1.2.3.2-case-brief-florida-v.-jardines-annotated</a></td></tr></tbody></table>
