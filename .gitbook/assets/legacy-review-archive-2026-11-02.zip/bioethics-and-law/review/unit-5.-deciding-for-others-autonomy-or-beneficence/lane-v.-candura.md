> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-5.-deciding-for-others-autonomy-or-beneficence/lane-v.-candura) · Snapshot: 2026-11-02 · Original path: `unit-5.-deciding-for-others-autonomy-or-beneficence/lane-v.-candura`

---

# Lane v. Candura

6 Mass. App. Ct. 377, 376 N.E.2d 1232 (1978)

**GRACE R. LANE**\
**vs.**\
**ROSARIA CANDURA**

Appeals Court of Massachusetts

BY THE COURT.

This case concerns a 77-year old widow, Mrs. Rosaria Candura, of Arlington, who is presently a patient at the Symmes Hospital in Arlington suffering from gangrene in the right foot and lower leg. Her attending physicians recommended in April that the leg be amputated without delay. After some vacillation, she refused to consent to the operation, and she persists in that refusal.[\[1\]](#footnotes) Her daughter, Grace R. Lane, of Medford, filed a petition in the Probate Court for Middlesex County seeking appointment of herself as temporary guardian with authority to consent to the operation on behalf of her mother. An order and a judgment were entered in the Probate Court to that effect, from which the guardian ad litem appointed to represent Mrs. Candura has appealed.

We hold that Mrs. Candura has the right under the law to refuse to submit either to medical treatment or a surgical operation, that on the evidence and findings in this case the decision is one that she may determine for herself, and that therefore her leg may not be amputated unless she consents to that course of action.

The right of a person in most circumstances to decline treatment is clearly recognized in the important recent case of _Superintendent of Belchertown State Sch._ v. _Saikewicz,_ [373 Mass. 728](https://scholar.google.com/scholar_case?case=2165107287898894579\&q=373+Mass.+728\&hl=en\&as_sdt=6,50) (1977). "The constitutional right to privacy, as we conceive it, is an expression of the sanctity of individual free choice and self-determination as fundamental constituents of life. The value of life as so perceived is lessened not by a decision to refuse treatment, but by the failure to allow a competent human being the right of choice." _Id._ [at 742](https://scholar.google.com/scholar_case?case=2165107287898894579\&q=373+Mass.+728\&hl=en\&as_sdt=6,50#p742). Although the _Saikewicz_ case also recognizes certain countervailing interests of the State which may in some cases outweigh the right of a competent individual to refuse life saving or life prolonging treatment,[\[2\]](#footnotes) the case before us does not involve factors which would bring it within those lines of cases and thus warrant a court's overriding the will of a competent person.

The principal question arising on the record before us, therefore, is whether Mrs. Candura has the legally requisite competence of mind and will to make the choice for herself. We look first to the findings of fact made by the judge who heard the testimony, including that of Mrs. Candura herself. His decision does not include a clear-cut finding that Mrs. Candura lacks the requisite legal competence. The nearest approach to such a finding is contained in the following passage from his decision:

> It is fair to conclude — without necessarily finding that the ward is mentally ill for all purposes — that she is incapable of making a rational and competent choice to undergo or reject the proposed surgery to her right leg. To this extent, at least, her behavior is irrational. She has closed her mind to the entire issue to the extent that the Court cannot conclude that her decision to reject further treatment is rational and informed.... In the absence of substantial evidence that the ward has come to her current position as a result of a rational process after careful consideration of the medical alternatives, the Court finds that her confused mental condition resulting from her underlying senility and depression warrants the exercise of the jurisdiction of this Court and the application of a substitute choice for the ward as enunciated in the \[_Saikewicz_] case....

In context, the quoted passage means only that, given some indications of a degree of senility and confusion on some subjects, the judge was not satisfied that Mrs. Candura arrived at her decision in a rational manner, i.e., "after careful consideration of the medical alternatives." We do not think that the passage can be construed as a finding of legal incompetence, and we do not think that the evidence in the case would have warranted such a finding.[\[3\]](#footnotes)

The facts found by the judge or established by uncontradicted evidence are as follows. Mrs. Candura was born in Italy, emigrated to the United States in 1918, was married, and had a daughter and three sons. She lost her husband in 1976 and has been depressed and unhappy since that time. Her relationship with her children is marked by a considerable degree of conflict. She lived in her own home until her hospitalization in November, 1977. In 1974 she had an infection in a toe on her right foot which became gangrenous. It was discovered at that time that she was diabetic. The toe was amputated. In 1977 she bruised her right leg while getting into a bus. The bruise developed into gangrene which resulted in an operation in November, 1977, in which a portion of her right foot was amputated. At that time an arterial bypass was done to decrease the likelihood that gangrene would recur. She went from the hospital to a rehabilitation center, where she remained until April. She then returned to the hospital and was found to have gangrene in the remainder of the foot. She originally agreed to amputation of the leg, but she withdrew her consent on the morning scheduled for the operation. She was discharged on April 21 and went to her daughter's home but returned to the Symmes Hospital after a few days. Around May 9, responding to the persuasion of a doctor who has known Mrs. Candura for many years, she consented to the operation, but soon thereafter she reiterated her refusal. She has discussed with some persons the reasons for her decision: that she has been unhappy since the death of her husband; that she does not wish to be a burden to her children; that she does not believe that the operation will cure her; that she does not wish to live as an invalid or in a nursing home; and that she does not fear death but welcomes it.&#x20;

\[Mrs. Candura] is discouraged by the failure of the earlier operations to arrest the advance of the gangrene. She tends to be stubborn and somewhat irascible. In her own testimony before the judge she expressed a desire to get well but indicated that she was resigned to death and was adamantly against the operation. Her testimony (corroborated by that of several of the witnesses) showed that she is lucid on some matters and confused on others. Her train of thought sometimes wanders. Her conception of time is distorted. She is hostile to certain doctors. She is on occasion defensive[\[4\]](#footnotes) and sometimes combative in her responses to questioning. But she has exhibited a high degree of awareness and acuity when responding to questions  concerning the proposed operation. She has made it clear that she does not wish to have the operation even though that decision will in all likelihood lead shortly to her death. We find no indication in any of the testimony that that is not a choice with full appreciation of the consequences. The most that is shown is that the decision involves strong emotional factors, that she does not choose to discuss the decision with certain persons, and that occasionally her resolve against giving consent weakens.

We start with the proposition that, in a proceeding for the appointment of a guardian under \[Mass [General Law 201](https://malegislature.gov/Laws/GeneralLaws/PartII/TitleII/Chapter201) \[...] (permanent and temporary guardianships, respectively), the burden is on the petitioner to prove that the proposed ward is incompetent. A person is presumed to be competent unless shown by the evidence not to be competent. Such evidence is lacking in this case. We recognize that Dr. Kelley, one of two psychiatrists who testified, did state that in his opinion Mrs. Candura was incompetent to make a rational choice whether to consent to the operation. His opinion appears to have been based upon (1) his inference from her unwillingness to discuss the problem with him that she was unable to face up to the problem or to understand that her refusal constituted a choice; (2) his characterization of "an unwilling\[ness], for whatever reason, to consent to life saving treatment ... as suicidal"; and (3) a possibility, not established by evidence as a reasonable probability, that her mind might be impaired by toxicity caused by the gangrenous condition.[\[5\]](#footnotes) His testimony, read closely, and in the context of the questions put to him, indicates that his opinion is not one of incompetency in the legal sense, but rather that her ability to make a rational choice (by which he means the _medically_ rational choice) is impaired by the confusion existing in her mind by virtue of her consideration of irrational and emotional factors.

A careful analysis of the evidence in this case, including the superficially conflicting psychiatric testimony, indicates that there is no real conflict as to the underlying facts. Certainly, the evidence presents no issue of credibility. The principal question is whether the facts established by the evidence justify a conclusion of legal incompetence. The panel are unanimous in the opinion that they do not.

The decision of the judge, as well as the opinion of Dr. Kelley, predicates the necessity for the appointment of a guardian chiefly on the irrationality (in medical terms) of Mrs. Candura's decision to reject the amputation. Until she changed her original decision and withdrew her consent to the amputation, her competence was not questioned.[\[6\]](#footnotes) But the irrationality of her decision, does not justify a conclusion that Mrs. Candura is incompetent in the legal sense. The law protects her right to make her own decision to accept or reject treatment, whether that decision is wise or unwise.[\[7\]](#footnotes)

Similarly, the fact that she has vacillated in her resolve not to submit to the operation does not justify a conclusion that her capacity to make the decision is impaired to the point of legal incompetence. Indeed, her reaction may be readily understandable in the light of her prior surgical experience and the prospect of living the remainder of her life nonambulatory. Senile symptoms, in the abstract, may, of course, justify a finding of incompetence, but the inquiry must be more particular. What is lacking in this case is evidence that Mrs. Candura's areas of forgetfulness and confusion cause, or relate in any way to, impairment of her ability to understand that in rejecting the amputation she is, in effect, choosing death over life. This is not a case, therefore, like _State_ v. _Northern_ \[...][^1], in which the ward elected both to live and to reject an amputation operation, not appreciating that she must choose, Rather, this case is like _In the Matter of Quackenbush_ \[...][^2], in which an elderly person, although subject (like Mrs. Candura) to fluctuations in mental lucidity and to occasional losses of his train of thought, was held to be competent to reject a proposed operation to amputate gangrenous legs because he was capable of appreciating the nature and consequences of his decision. \[...][^3]

Mrs. Candura's decision may be regarded by most as unfortunate, but on the record in this case it is not the uninformed decision of a person incapable of appreciating the nature and consequences of her act. We cannot anticipate whether she will reconsider and will consent to the operation, but we are all of the opinion that the operation may not be forced on her against her will.

The order appointing a temporary guardian and the judgment authorizing the temporary guardian to consent to the operation are reversed, and a new judgment is to enter dismissing the petition.

_So ordered._

## _Footnotes_

\[1] We were informed at argument that on Saturday, May 20, 1978, she indicated that she would consent to the operation but changed her mind on Sunday.

\[2] See discussion in 373 Mass. at 741-745. Two of the State interests discussed, the protection of innocent third persons, such as children, see _Holmes_ v. _Silver Cross Hosp.,_ 340 F. Supp. 125 (D. Ill. 1972), and the prevention of suicide, see the _Saikewicz_ case at 743 n. 11, and _Erickson_ v. _Dilgard,_ 44 Misc.2d 27 (N.Y. Sup. Ct. 1962), have no application to this case. The other two State interests, the preservation of life and the protection of the integrity of the medical profession, call for a balancing of those interests against the "strong interest \[of the individual] in being free from nonconsensual invasion of his bodily integrity." 373 Mass. at 739. The magnitude of the invasion proposed in this case is decisive in applying the balancing test.

\[3] There was clearly no evidence that Mrs. Candura was incompetent at the time she made her decision against the operation in April. There was some evidence of deterioration in her condition since that time, but we think that the evidence did not justify a finding of incompetence even at the time of the hearing.

\[4] A social worker, Ann Gillis, who is one of those with whom Mrs. Candura has discussed her decision, responded to certain questions as follows:

> Q. "Have you ever had any concern over her ability to rationalize clearly on questions?"
>
> A. "To some extent but I would say the emotional factor in her just tuning out has as much to do with it if not more than perhaps any organic process."
>
> Q. "So, you find her rational to a point and then tuning out as to other matters?"
>
> A. "Yes. I've also seen her tuning out in direct relationship to the input that she is getting that is not acceptable to her."
>
> Q. "\[D]o you feel that you could say, in your experience having interviewed and talked with Mrs. Candura as often as you have, that she does understand the nature and consequences of her decision when she refuses to have surgery?"
>
> A. "I certainly felt when I started to see her in the beginning that she did but at this point I think there are a lot of other issues that are tied up in this. The issue of control over her own life and the response she has to people trying to influence her, the negative response she has to that."

\[5] Another psychiatrist, Dr. Zeckel, who is apparently an associate of Dr. Kelley, and who offered an opinion that Mrs. Candura was competent, has been successful in eliciting from her the factors contributing to her choice. When asked to explain why his opinion differed from that of Dr. Kelley, Dr. Zeckel answered, "I think it is just a personal philosophy type of thing where I believe the person\[s] themselves ought to be given the benefit of the doubt as to what they want to do with their lives, whereas, Dr. Kelley, I guess, is more protective. I can't really speak for him but his general philosophy is different from mine." Dr. Kelley stated, at one point in his testimony, "You know, it comes down really to a philosophical \[difference], I hope there is no psychiatric argument in this case. It's the right of a patient to decide they want to die and I spend all my life trying to keep people alive so I take quite a different view."

\[6] Even now the interveners (the Symmes Hospital and two physicians) stand prepared, and correctly so, to perform the amputation operation upon the basis of her consent, if she should give it.

\[7] In that case the court stated: "Even though we may consider appellant's beliefs unwise, foolish or ridiculous, in the absence of an overriding danger to society we may not permit interference therewith in the form of a conservatorship established in the waning hours of her life for the sole purpose of compelling her to accept medical treatment forbidden by her religious principles, and previously refused by her with full knowledge of the probable consequences." 32 Ill.2d at 373. See _People_ v. _Privitera,_ 141 Cal. Rptr. 764, 769-770 (Ct. App. 1977). See also Burger, J., dissenting, in _Application of President & Directors of Georgetown College, Inc.,_ 331 F.2d 1010, 1017 (1964).

***

<details>

<summary><mark style="color:red;">Editorial Notes,</mark> <mark style="color:red;"><strong>Attributions, and Licensing</strong></mark></summary>

Editing to the [original](https://scholar.google.com/scholar_case?case=12758396049872879027\&q=6+Mass.+App.+Ct.+377\&hl=en\&as_sdt=6,50), excluding any original footnotes (hyperlinked or otherwise), by Matthew L. Mac Kelly. Many of the court's citations to authorities have been omitted for length and readability purposes. Otherwise, elisions are identified by bracketed ellipses (e.g., \[...]), several of which reveal elided text by clicking on inline annotation indicators (e.g., \[...][^4]). Judicial decisions and annotations thereto are not subject to copyright protection and are in the public domain. _See, e.g., Georgia v. Public.Resource.Org, Inc_., [140 S. Ct. 1498](https://scholar.google.com/scholar_case?case=8288711378870515248\&q=Georgia+et+al.+v.+Public.Resource.Org,+Inc.\&hl=en\&as_sdt=6,50) (2020). This page is in the public domain.

</details>

[^1]: 563 S.W.2d 197 (Tenn. App.), cert denied, 575 S.W.2d 946 (Tenn. 1978)

[^2]: 156 N.J. Super. 282 (Morris County Ct. 1978)

[^3]: See generally _In re Osborne,_ 294 A.2d 372 (D.C. 1972) (guardianship to consent to blood transfusion denied); _In re Melideo,_ 88 Misc.2d 974 (N.Y. Sup. Ct. 1976) (court permission for blood transfusion denied); _In re Yetter,_ 62 Pa. D. & C.2d 619 (1973) (guardianship to consent to biopsy and surgical removal of possible breast cancer denied, notwithstanding patient's delusions on some subjects). Contrast _Matter of Schiller,_ 148 N.J. Super. 168 (Super. Ct. Ch. Div. 1977), and _Application of L.I. Jewish-Hillside Medical Center,_ 73 Misc.2d 395 (N.Y. Sup. Ct. 1973), both amputation cases in which the patient was held to be incompetent

[^4]: Elided text here.
