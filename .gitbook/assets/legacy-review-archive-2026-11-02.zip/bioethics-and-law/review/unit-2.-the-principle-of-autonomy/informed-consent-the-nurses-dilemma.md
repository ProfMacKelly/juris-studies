> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-2.-the-principle-of-autonomy/informed-consent-the-nurses-dilemma) · Snapshot: 2026-11-02 · Original path: `unit-2.-the-principle-of-autonomy/informed-consent-the-nurses-dilemma`

---

# Informed consent: The nurse's dilemma

Tabak, N. (1996). Informed consent: The nurse's dilemma. [_Medicine and Law, 15_(1), 7-16](https://heinonline.org/HOL/Page?handle=hein.journals/mlv15\&div=9\&g_sent=1\&casa_token=0sB2ex-JKbQAAAAA:9TDqqUULyXES-sStsS8yoKeCcbSn8Hz7kxD6C6bFP10KBbo_oXeZEMpFE_HTVxfgHZBcvj4GiDP_\&collection=journals).

* Note: Part of this week's Journal Entry assignment relates to this reading.

