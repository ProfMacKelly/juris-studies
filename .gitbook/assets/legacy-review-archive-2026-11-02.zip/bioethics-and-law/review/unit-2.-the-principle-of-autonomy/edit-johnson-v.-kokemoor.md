> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-2.-the-principle-of-autonomy/edit-johnson-v.-kokemoor) · Snapshot: 2026-11-02 · Original path: `unit-2.-the-principle-of-autonomy/edit-johnson-v.-kokemoor`

---

# Edit Johnson v. Kokemoor

* [_Johnson v. Kokemoor_](https://scholar.google.com/scholar_case?case=10421018059591899078\&q=199+Wis.2d+615\&hl=en\&as_sdt=6,50), 545 N.W.2d 495 (Wis. 1996)
