> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-2.-the-principle-of-autonomy/summation) · Snapshot: 2026-11-02 · Original path: `unit-2.-the-principle-of-autonomy/summation`

---

# Summation

In this unit, you learned the foundations of informed consent as a legal doctrine, and how it has evolved through case law.

You have seen the relative roles of the doctor and the patient and the complex relationship that is built between them when autonomy comes into view. You also learned about the various justifications for informed consent, and read arguments about why they may not sufficiently support our reliance on the doctrine.

The [next unit](broken-reference) continues to emphasize autonomy but will focus more narrowly on how the law regulates decisions at the end of life, both when the patient is dying and _not_ dying.&#x20;
