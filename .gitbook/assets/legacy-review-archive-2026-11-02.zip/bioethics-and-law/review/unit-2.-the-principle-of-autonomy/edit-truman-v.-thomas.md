> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-2.-the-principle-of-autonomy/edit-truman-v.-thomas) · Snapshot: 2026-11-02 · Original path: `unit-2.-the-principle-of-autonomy/edit-truman-v.-thomas`

---

# Edit Truman v. Thomas

* [_Truman v. Thomas_](https://scholar.google.com/scholar_case?case=4583670149937548076\&q=611+P.2d+902\&hl=en\&as_sdt=6,50), 611 P.2d 902 (Cal. 1980)
