> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-2.-the-principle-of-autonomy/edit-mcgeshick-v.-choucair) · Snapshot: 2026-11-02 · Original path: `unit-2.-the-principle-of-autonomy/edit-mcgeshick-v.-choucair`

---

# Edit McGeshick v. Choucair

* [_McGeshick v._](https://scholar.google.com/scholar_case?case=14554245756054658399\&q=9+F.3d+1229\&hl=en\&as_sdt=6,50)[ _Choucair_](https://scholar.google.com/scholar_case?case=14554245756054658399\&q=9+F.3d+1229\&hl=en\&as_sdt=6,50), 9 F.3d 1229 (7th Cir. 1993) **(**_**Notice how this court treats the case above, Truman v. Thomas**_**.)**
