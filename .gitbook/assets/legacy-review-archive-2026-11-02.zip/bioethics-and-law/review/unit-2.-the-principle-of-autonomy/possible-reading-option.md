> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-2.-the-principle-of-autonomy/possible-reading-option) · Snapshot: 2026-11-02 · Original path: `unit-2.-the-principle-of-autonomy/possible-reading-option`

---

# \[possible reading option]

[Peter H. Schuck, _Rethinking Informed Consent_, 103 Yale L. J. 899 (1994)](https://openyls.law.yale.edu/bitstream/handle/20.500.13051/2111/Rethinking_Informed_Consent.pdf?sequence=2)&#x20;
