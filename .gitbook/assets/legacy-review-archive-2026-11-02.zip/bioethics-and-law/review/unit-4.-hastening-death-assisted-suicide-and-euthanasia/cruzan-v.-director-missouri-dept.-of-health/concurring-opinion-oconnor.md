> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-4.-hastening-death-assisted-suicide-and-euthanasia/cruzan-v.-director-missouri-dept.-of-health/concurring-opinion-oconnor) · Snapshot: 2026-11-02 · Original path: `unit-4.-hastening-death-assisted-suicide-and-euthanasia/cruzan-v.-director-missouri-dept.-of-health/concurring-opinion-oconnor`

---

# Concurring Opinion (O'Connor)

JUSTICE O'CONNOR, concurring.

I agree that a protected liberty interest in refusing unwanted medical treatment may be inferred from our prior decisions and that the refusal of artificially delivered food and water is encompassed within that liberty interest. I write separately to clarify why I believe this to be so.

As the Court notes, the liberty interest in refusing medical treatment flows from decisions involving the State's invasions into the body. Because our notions of liberty are inextricably entwined with our idea of physical freedom and self-determination, the Court has often deemed state incursions into the body repugnant to the interests protected by the Due Process Clause. See, _e. g.,_ [_Rochin_ v. _California_ ](https://scholar.google.com/scholar_case?case=13189177772806165249\&q=497+U.S.+261+\&hl=en\&as_sdt=6,50)\[...][^1] ("Illegally breaking into the privacy of the petitioner, the struggle to open his mouth and remove what was there, the forcible extraction of his stomach's contents . . . is bound to offend even hardened sensibilities") \[...]. Our Fourth Amendment jurisprudence has echoed this same concern. \[...][^2] The State's imposition of medical treatment on an unwilling competent adult necessarily involves some form of restraint and intrusion. A seriously ill or dying patient whose wishes are not honored may feel a captive of the machinery required for life-sustaining measures or other medical interventions. Such forced treatment may burden that individual's liberty interests as much as any state coercion. \[...]

The State's artificial provision of nutrition and hydration implicates identical concerns. Artificial feeding cannot readily be distinguished from other forms of medical treatment. \[...][^3] Whether or not the techniques used to pass food and water into the patient's alimentary tract are termed "medical treatment," it is clear they all involve some degree of intrusion and restraint. Feeding a patient by means of a nasogastric tube requires a physician to pass a long flexible tube through the patient's nose, throat, and esophagus and into the stomach. Because of the discomfort such a tube causes, "\[m]any patients need to be restrained forcibly and their hands put into large mittens to prevent them from removing the tube." \[...][^4] A gastrostomy tube (as was used to provide food and water to Nancy Cruzan) or jejunostomy tube must be surgically implanted into the stomach or small intestine. \[...][^5] Requiring a competent adult to endure such procedures against her will burdens the patient's liberty, dignity, and freedom to determine the course of her own treatment. Accordingly, the liberty guaranteed by the Due Process Clause must protect, if it protects anything, an individual's deeply personal decision to reject medical treatment, including the artificial delivery of food and water.

I also write separately to emphasize that the Court does not today decide the issue whether a State must also give effect to the decisions of a surrogate decisionmaker. In my view, such a duty may well be constitutionally required to protect the patient's liberty interest in refusing medical treatment. Few individuals provide explicit oral or written instructions regarding their intent to refuse medical treatment should they become incompetent.[\[1\]](https://scholar.google.com/scholar_case?case=8467471114673973761\&q=497+U.S.+261+\&hl=en\&as_sdt=6,50#\[14]) States which decline to consider any evidence other than such instructions may frequently fail to honor a patient's intent. Such failures might be avoided if the State considered an equally probative source of evidence: the patient's appointment of a proxy to make health care decisions on her behalf. Delegating the authority to make medical decisions to a family member or friend is becoming a common method of planning for the future. \[...][^6] Several States have recognized the practical wisdom of such a procedure by enacting durable power of attorney statutes that specifically authorize an individual to appoint a surrogate to make medical treatment decisions.[\[2\]](https://scholar.google.com/scholar_case?case=8467471114673973761\&q=497+U.S.+261+\&hl=en\&as_sdt=6,50#\[15]) Some state courts have suggested that an agent appointed pursuant to a general durable power of attorney statute would also be empowered to make health care decisions on behalf of the patient.[\[3\]](https://scholar.google.com/scholar_case?case=8467471114673973761\&q=497+U.S.+261+\&hl=en\&as_sdt=6,50#\[16]) \[...] Other States allow an individual to designate a proxy to carry out the intent of a living will.[\[4\]](https://scholar.google.com/scholar_case?case=8467471114673973761\&q=497+U.S.+261+\&hl=en\&as_sdt=6,50#\[17]) These procedures for surrogate decisionmaking, which appear to be rapidly gaining in acceptance, may be a valuable additional safeguard of the patient's interest in directing his medical care. Moreover, as patients are likely to select a family member as a surrogate, \[...][^7] giving effect to a proxy's decisions may also protect the "freedom of personal choice in matters of. . . family life." \[...][^8]&#x20;

Today's decision, holding only that the Constitution permits a State to require clear and convincing evidence of Nancy Cruzan's desire to have artificial hydration and nutrition withdrawn, does not preclude a future determination that the Constitution requires the States to implement the decisions of a patient's duly appointed surrogate. Nor does it prevent States from developing other approaches for protecting an incompetent individual's liberty interest in refusing medical treatment. As is evident from the Court's survey of state court decisions, no national consensus has yet emerged on the best solution for this difficult and sensitive problem. Today we decide only that one State's practice does not violate the Constitution; the more challenging task of crafting appropriate procedures for safeguarding incompetents' liberty interests is entrusted to the "laboratory" of the States in the first instance.

***

Tags: autonomy, self-determination, informed consent, constitutional rights, right of privacy, right to refuse treatment, right to refuse medical treatment, withdrawal of treatment, persistent vegetative state, life support, right to die, feeding tube, artificial nutrition, artificial hydration, competence, quality of life, advanced directive, living will, substituted judgment, suicide

***

<details>

<summary><mark style="color:red;"><strong>Editorial Notes, Attributions, and Licensing</strong></mark></summary>

Editing to the [original](https://scholar.google.com/scholar_case?case=8467471114673973761\&q=497+U.S.+261+\&hl=en\&as_sdt=6,50#p287), excluding any original footnotes (hyperlinked or otherwise), by Matthew L. Mac Kelly. Many of the court's citations to authorities have been omitted for length and readability purposes. Otherwise, elisions are identified by bracketed ellipses (e.g., \[...]), several of which reveal elided text by clicking on inline annotation indicators (e.g., \[...][^9]). Judicial decisions and annotations thereto are not subject to copyright protection and are in the public domain. _See, e.g., Georgia v. Public.Resource.Org, Inc_., [140 S. Ct. 1498](https://scholar.google.com/scholar_case?case=8288711378870515248\&q=Georgia+et+al.+v.+Public.Resource.Org,+Inc.\&hl=en\&as_sdt=6,50) (2020). This page is in the public domain.

</details>

[^1]: [342 U. S. 165, 172 (1952)](https://scholar.google.com/scholar_case?case=13189177772806165249\&q=497+U.S.+261+\&hl=en\&as_sdt=6,50)

[^2]: See _Schmerber_ v. _California,_ 384 U. S. 757, 772 (1966) ("The integrity of an individual's person is a cherished value of our society"); _Winston_ v. _Lee,_ 470 U. S. 753, 759 (1985) ("A compelled surgical intrusion into an individual's body for evidence . . . implicates expectations of privacy and security of such magnitude that the intrusion may be \`unreasonable' even if likely to produce evidence of a crime").

[^3]: See, _e. g.,_ Council on Ethical and Judicial Affairs, American Medical Association, AMA Ethical Opinion 2.20, Withholding or Withdrawing Life-Prolonging Medical Treatment, Current Opinions 13 (1989); The Hastings Center, Guidelines on the Termination of Life-Sustaining Treatment and the Care of the Dying 59 (1987).&#x20;

[^4]: Major, The Medical Procedures for Providing Food and Water: Indications and Effects, in By No Extraordinary Means: The Choice to Forgo Life-Sustaining Food and Water 25 (J. Lynn ed. 1986).&#x20;

[^5]: Office of Technology Assessment Task Force, Life-Sustaining Technologies and the Elderly 282 (1988).

[^6]: See, _e. g.,_ Areen, The Legal Status of Consent Obtained from Families of Adult Patients to Withhold or Withdraw Treatment, 258 JAMA 229, 230 (1987).

[^7]: see 2 President's Commission for the Study of Ethical Problems in Medicine and Biomedical and Behavioral Research, Making Health Care Decisions 240 (1982)

[^8]: _&#x43;leveland Board of Education_ v. _LaFleur,_ 414 U. S. 632, 639 (1974).

[^9]: Elided text here.
