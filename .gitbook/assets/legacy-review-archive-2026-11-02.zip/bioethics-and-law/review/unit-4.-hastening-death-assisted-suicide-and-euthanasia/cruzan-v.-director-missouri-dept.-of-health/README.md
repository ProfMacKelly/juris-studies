> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-4.-hastening-death-assisted-suicide-and-euthanasia/cruzan-v.-director-missouri-dept.-of-health) · Snapshot: 2026-11-02 · Original path: `unit-4.-hastening-death-assisted-suicide-and-euthanasia/cruzan-v.-director-missouri-dept.-of-health`

---

# Cruzan v. Director, Missouri Dept. of Health



{% hint style="info" %}
Note: This case focuses on whether a married but separated person who chooses not to receive a blood transfusion for religious reasons can be compelled to receive medical treatment on the basis that their death would cause the abandonment of four minor children.
{% endhint %}

497 U.S. 261 (1990)&#x20;

United States Supreme Court

**Cruzan, by Her Parents and Co-Guardians, Cruzan et ux.**\
**v.**\
**Director, Missouri Department of Health et al.**

<table data-view="cards"><thead><tr><th></th><th></th><th></th><th data-hidden data-card-target data-type="content-ref"></th></tr></thead><tbody><tr><td><p><strong>Plurality Opinion</strong></p><p>(Rehnquist, joined by O'Connor, Scalia, Kennedy)</p></td><td></td><td></td><td><a href="cruzan-v.-director-missouri-dept.-of-health/plurality-opinion">plurality-opinion</a></td></tr><tr><td><p><strong>Concurring Opinion</strong></p><p>(O'Connor)</p></td><td></td><td></td><td><a href="cruzan-v.-director-missouri-dept.-of-health/concurring-opinion-oconnor">concurring-opinion-oconnor</a></td></tr><tr><td><p><strong>Concurring Opinion</strong></p><p>(Scalia)</p></td><td></td><td></td><td><a href="cruzan-v.-director-missouri-dept.-of-health/concurring-opinion-scalia">concurring-opinion-scalia</a></td></tr><tr><td><p><strong>Dissenting Opinion</strong></p><p>(Brennan, joined by Marshall, Blackmun)</p></td><td></td><td></td><td><a href="cruzan-v.-director-missouri-dept.-of-health/dissenting-opinion-brennan-joined-by-marshall-blackmun">dissenting-opinion-brennan-joined-by-marshall-blackmun</a></td></tr><tr><td><p><strong>Dissenting Opinion</strong></p><p>(Stevens)</p></td><td></td><td></td><td><a href="cruzan-v.-director-missouri-dept.-of-health/dissenting-opinion-stevens">dissenting-opinion-stevens</a></td></tr></tbody></table>
