> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-4.-hastening-death-assisted-suicide-and-euthanasia/the-empirical-slippery-slope-from-voluntary-to-non-voluntary-euthanasia) · Snapshot: 2026-11-02 · Original path: `unit-4.-hastening-death-assisted-suicide-and-euthanasia/the-empirical-slippery-slope-from-voluntary-to-non-voluntary-euthanasia`

---

# The Empirical Slippery Slope from Voluntary to Non-Voluntary Euthanasia

Read the following article:&#x20;

* Lewis, P. (2007, Spring). The Empirical Slippery Slope from Voluntary to Non-Voluntary Euthanasia. _The Journal of Law, Medicine & Ethics, 35_(1), 197-210. [https://doi.org/10.1111/j.1748-720X.2007.00124.x](https://cuw.idm.oclc.org/login?url=https://www.proquest.com/scholarly-journals/empirical-slippery-slope-voluntary-non-euthanasia/docview/223496117/se-2?accountid=10249)

