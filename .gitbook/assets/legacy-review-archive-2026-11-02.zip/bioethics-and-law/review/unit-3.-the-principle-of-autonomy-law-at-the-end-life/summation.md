> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-3.-the-principle-of-autonomy-law-at-the-end-life/summation) · Snapshot: 2026-11-02 · Original path: `unit-3.-the-principle-of-autonomy-law-at-the-end-life/summation`

---

# Summation

In this unit, you learned the various ways that courts have looked—and continue to look—at when “death” actually occurs, and what is required to pronounce it in relation to the ending of medical treatment. You have observed how courts developed different criteria and often drew potentially arbitrary lines to make this determination.

You also explored how the principle of autonomy informs a patient’s decision to refuse life-saving medical treatment. More specifically, you have considered the difference between a patient who is dying and one who is not, and how the notion of autonomy can change in those different scenarios.

The [next unit](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-4.-hastening-death-assisted-suicide-and-euthanasia) continues examining the issue of death, moving into the controversial arena of killing: assisted suicide and euthanasia.

