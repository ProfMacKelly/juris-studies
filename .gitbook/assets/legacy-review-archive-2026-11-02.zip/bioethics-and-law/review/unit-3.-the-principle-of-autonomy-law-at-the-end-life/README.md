> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-3.-the-principle-of-autonomy-law-at-the-end-life) · Snapshot: 2026-11-02 · Original path: `unit-3.-the-principle-of-autonomy-law-at-the-end-life`

---

# UNIT 3. The Principle of Autonomy: Law at the End Life

## Sections

[Unit Overview](unit-3.-the-principle-of-autonomy-law-at-the-end-life/unit-overview)

[_In re Welfare of Bowman_](unit-3.-the-principle-of-autonomy-law-at-the-end-life/in-re-welfare-of-bowman)

[_In re T.A.C.P._](unit-3.-the-principle-of-autonomy-law-at-the-end-life/in-re-t.a.c.p.)

[_Bouvia v. Superior Court_](unit-3.-the-principle-of-autonomy-law-at-the-end-life/bouvia-v.-superior-court)

[_McKay v. Bergstedt_](unit-3.-the-principle-of-autonomy-law-at-the-end-life/mckay-v.-bergstedt)

[_In re Dubreuil_](unit-3.-the-principle-of-autonomy-law-at-the-end-life/in-re-dubreuil)

[Summation](unit-3.-the-principle-of-autonomy-law-at-the-end-life/summation)

[Suggested Reading (Voluntary)](unit-3.-the-principle-of-autonomy-law-at-the-end-life/suggested-reading-voluntary)
