> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Bioethics and the Law](https://profmackelly.gitbook.io/bioethics-and-the-law/unit-3.-the-principle-of-autonomy-law-at-the-end-life/suggested-reading-voluntary) · Snapshot: 2026-11-02 · Original path: `unit-3.-the-principle-of-autonomy-law-at-the-end-life/suggested-reading-voluntary`

---

# Suggested Reading (Voluntary)

* [Smith, W.J. (2014, Spring). Total brain failure is death. _Human Life Review, 40_, 19-30](http://search.proquest.com.cuw.ezproxy.switchinc.org/magazines/total-brain-failure-is-death/docview/1545332158/se-2). (The previous link was to access this article through the CUW library. The text is [also available here](https://www.discovery.org/a/23171/).
* [Haney, D.Q. (1979, August 23). Patients may not really mean 'death with dignity,' doctors told. _The Free Lance-Star_, p. 28](https://news.google.com/newspapers?id=jOBLAAAAIBAJ\&sjid=Z4sDAAAAIBAJ\&pg=6695%2C1239443).

