# Bioethics and the Law — Legacy Review Archive

> REVIEW ARCHIVE. Juris Studies is the main version. These snapshots are retained for editorial comparison, not as the approved teaching version.

Snapshot date: 2026-11-02. Source space: `imw8Zvv6aKxFdVFbYMqp`. Source revision: `l8ZqLLCNgnwBXl9rZXNx`.

Legacy site: https://profmackelly.gitbook.io/bioethics-and-the-law/

The originals/ folder contains the exact Markdown returned by the pinned GitBook revision. These are API Markdown snapshots, not byte-for-byte exports of repository files. The review/ folder contains the same text with resolvable legacy-relative links made absolute and a source/review notice added. Footnotes, attributions and conflict text remain present. Media stays linked to the existing public source URLs; binary media is not bundled.

pages.csv lists all retained readings, original visibility, the comparison classification and possible Juris Studies counterparts. Candidate counterparts are aids for human review. No title match does not prove a topic is missing or unique.

## Readings

- [Bioethics and the Law Sourcebook](review/README.md) — no-title-match
- [UNIT 1. Introduction](review/README%20(1).md) — no-title-match — originally hidden
- [UNIT 1. Introduction](review/unit-1.-introduction-1/README.md) — no-title-match
- [1.1 Preparing to Understand Legal Thinking, Reasoning & Analysis](review/unit-1.-introduction-1/1.1-preparing-to-understand-legal-thinking-reasoning-and-analysis/README.md) — no-title-match
- [1.1.1 Introduction to Deductive (Rule-Based) Reasoning](review/unit-1.-introduction-1/1.1-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.1.1-introduction-to-deductive-rule-based-reasoning.md) — different-review
- [1.1.2 Introduction to Analogical Reasoning—A Type of Inductive Reasoning](review/unit-1.-introduction-1/1.1-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.1.2-introduction-to-analogical-reasoning-a-type-of-inductive-reasoning.md) — different-review
- [1.1.3 Is a Hot Dog a Sandwich?](review/unit-1.-introduction-1/1.1-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.1.3-is-a-hot-dog-a-sandwich.md) — different-review
- [1.1.4 More on "It Depends"](review/unit-1.-introduction-1/1.1-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.1.4-more-on-it-depends.md) — no-title-match — originally hidden
- [1.1.4 Beware of Bald Assertions](review/unit-1.-introduction-1/1.1-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.1.4-beware-of-bald-assertions.md) — no-title-match
- [1.1.5 Supplementary Attributions](review/unit-1.-introduction-1/1.1-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.1.5-supplementary-attributions.md) — no-title-match
- [1.2 Case Law: Introduction to Reading & Studying Cases](review/unit-1.-introduction-1/1.2-case-law-introduction-to-reading-and-studying-cases/README.md) — no-title-match
- [1.2.1 How to Read a Case](review/unit-1.-introduction-1/1.2-case-law-introduction-to-reading-and-studying-cases/1.2.1-how-to-read-a-case.md) — different-review
- [1.2.2 How to Brief a Case](review/unit-1.-introduction-1/1.2-case-law-introduction-to-reading-and-studying-cases/1.2.2-how-to-brief-a-case.md) — no-title-match
- [1.2.3 Examples: Case & Case Brief (with Explanatory Annotations)](review/unit-1.-introduction-1/1.2-case-law-introduction-to-reading-and-studying-cases/1.2.3-examples-case-and-case-brief-with-explanatory-annotations/README.md) — no-title-match
- [1.2.3.1 Case: Florida v. Jardines (Annotated)](review/unit-1.-introduction-1/1.2-case-law-introduction-to-reading-and-studying-cases/1.2.3-examples-case-and-case-brief-with-explanatory-annotations/1.2.3.1-case-florida-v.-jardines-annotated.md) — no-title-match
- [1.2.3.2 Case Brief: Florida v. Jardines (Annotated)](review/unit-1.-introduction-1/1.2-case-law-introduction-to-reading-and-studying-cases/1.2.3-examples-case-and-case-brief-with-explanatory-annotations/1.2.3.2-case-brief-florida-v.-jardines-annotated.md) — no-title-match
- [1.3 Brief Introduction to the Law & the American Legal System](review/unit-1.-introduction-1/1.3-brief-introduction-to-the-law-and-the-american-legal-system/README.md) — no-title-match — originally hidden
- [1.3.1 The Dual Court System](review/unit-1.-introduction-1/1.3-brief-introduction-to-the-law-and-the-american-legal-system/1.3.1-the-dual-court-system.md) — no-title-match — originally hidden
- [1.3.2 Sources & Classifications of Law](review/unit-1.-introduction-1/1.3-brief-introduction-to-the-law-and-the-american-legal-system/1.3.2-sources-and-classifications-of-law.md) — no-title-match — originally hidden
- [1.4 Foundations of the Bioethics-Law Relationship](review/unit-1.-introduction-1/1.4-foundations-of-the-bioethics-law-relationship/README.md) — no-title-match — originally hidden
- [1.4.1 Canterbury v. Spence](review/unit-1.-introduction-1/1.4-foundations-of-the-bioethics-law-relationship/1.4.1-canterbury-v.-spence.md) — no-title-match — originally hidden
- [1.4.2 K.A.C. v. Benson](review/unit-1.-introduction-1/1.4-foundations-of-the-bioethics-law-relationship/1.4.2-k.a.c.-v.-benson.md) — no-title-match — originally hidden
- [1.5 Summation](review/unit-1.-introduction-1/1.5-summation.md) — no-title-match — originally hidden
- [UNIT 2. The Principle of Autonomy](review/unit-2.-the-principle-of-autonomy/README.md) — no-title-match — originally hidden
- [Edit - Unit Overview](review/unit-2.-the-principle-of-autonomy/edit-unit-overview.md) — no-title-match — originally hidden
- [Unit Overview](review/unit-2.-the-principle-of-autonomy/unit-overview.md) — no-title-match — originally hidden
- [Edit Arato v. Avedon](review/unit-2.-the-principle-of-autonomy/edit-arato-v.-avedon.md) — no-title-match — originally hidden
- [Edit Truman v. Thomas](review/unit-2.-the-principle-of-autonomy/edit-truman-v.-thomas.md) — no-title-match — originally hidden
- [Edit McGeshick v. Choucair](review/unit-2.-the-principle-of-autonomy/edit-mcgeshick-v.-choucair.md) — no-title-match — originally hidden
- [Edit Johnson v. Kokemoor](review/unit-2.-the-principle-of-autonomy/edit-johnson-v.-kokemoor.md) — no-title-match — originally hidden
- [Informed consent: The nurse's dilemma](review/unit-2.-the-principle-of-autonomy/informed-consent-the-nurses-dilemma.md) — no-title-match — originally hidden
- [[possible reading option]](review/unit-2.-the-principle-of-autonomy/possible-reading-option.md) — no-title-match — originally hidden
- [Summation](review/unit-2.-the-principle-of-autonomy/summation.md) — no-title-match — originally hidden
- [UNIT 3. The Principle of Autonomy: Law at the End Life](review/unit-3.-the-principle-of-autonomy-law-at-the-end-life/README.md) — no-title-match
- [Unit Overview](review/unit-3.-the-principle-of-autonomy-law-at-the-end-life/unit-overview.md) — no-title-match
- [In re Welfare of Bowman](review/unit-3.-the-principle-of-autonomy-law-at-the-end-life/in-re-welfare-of-bowman.md) — no-title-match
- [In re T.A.C.P.](review/unit-3.-the-principle-of-autonomy-law-at-the-end-life/in-re-t.a.c.p..md) — no-title-match
- [Bouvia v. Superior Court](review/unit-3.-the-principle-of-autonomy-law-at-the-end-life/bouvia-v.-superior-court.md) — no-title-match
- [McKay v. Bergstedt](review/unit-3.-the-principle-of-autonomy-law-at-the-end-life/mckay-v.-bergstedt.md) — no-title-match
- [In re Dubreuil](review/unit-3.-the-principle-of-autonomy-law-at-the-end-life/in-re-dubreuil.md) — no-title-match
- [Summation](review/unit-3.-the-principle-of-autonomy-law-at-the-end-life/summation.md) — no-title-match
- [Suggested Reading (Voluntary)](review/unit-3.-the-principle-of-autonomy-law-at-the-end-life/suggested-reading-voluntary.md) — no-title-match
- [UNIT 4. Hastening Death: Assisted Suicide and Euthanasia](review/unit-4.-hastening-death-assisted-suicide-and-euthanasia/README.md) — no-title-match
- [Unit Overview](review/unit-4.-hastening-death-assisted-suicide-and-euthanasia/unit-overview.md) — no-title-match
- [Cruzan v. Director, Missouri Dept. of Health](review/unit-4.-hastening-death-assisted-suicide-and-euthanasia/cruzan-v.-director-missouri-dept.-of-health/README.md) — no-title-match
- [Plurality Opinion](review/unit-4.-hastening-death-assisted-suicide-and-euthanasia/cruzan-v.-director-missouri-dept.-of-health/plurality-opinion.md) — no-title-match
- [Concurring Opinion (O'Connor)](review/unit-4.-hastening-death-assisted-suicide-and-euthanasia/cruzan-v.-director-missouri-dept.-of-health/concurring-opinion-oconnor.md) — no-title-match
- [Concurring Opinion (Scalia)](review/unit-4.-hastening-death-assisted-suicide-and-euthanasia/cruzan-v.-director-missouri-dept.-of-health/concurring-opinion-scalia.md) — no-title-match
- [Dissenting Opinion (Brennan, joined by Marshall, Blackmun)](review/unit-4.-hastening-death-assisted-suicide-and-euthanasia/cruzan-v.-director-missouri-dept.-of-health/dissenting-opinion-brennan-joined-by-marshall-blackmun.md) — no-title-match
- [Dissenting Opinion (Stevens)](review/unit-4.-hastening-death-assisted-suicide-and-euthanasia/cruzan-v.-director-missouri-dept.-of-health/dissenting-opinion-stevens.md) — no-title-match
- [EDIT: Compassion in Dying v. Washington](review/unit-4.-hastening-death-assisted-suicide-and-euthanasia/edit-compassion-in-dying-v.-washington.md) — no-title-match — originally hidden
- [Washington v. Glucksberg](review/unit-4.-hastening-death-assisted-suicide-and-euthanasia/washington-v.-glucksberg.md) — no-title-match
- [Michigan v. Kevorkian](review/unit-4.-hastening-death-assisted-suicide-and-euthanasia/michigan-v.-kevorkian.md) — no-title-match
- [The Empirical Slippery Slope from Voluntary to Non-Voluntary Euthanasia](review/unit-4.-hastening-death-assisted-suicide-and-euthanasia/the-empirical-slippery-slope-from-voluntary-to-non-voluntary-euthanasia.md) — no-title-match
- [Summation](review/unit-4.-hastening-death-assisted-suicide-and-euthanasia/summation.md) — no-title-match — originally hidden
- [UNIT 5. Deciding for Others: Autonomy or Beneficence?](review/unit-5.-deciding-for-others-autonomy-or-beneficence/README.md) — no-title-match
- [Unit Overview](review/unit-5.-deciding-for-others-autonomy-or-beneficence/unit-overview.md) — no-title-match
- [Lane v. Candura](review/unit-5.-deciding-for-others-autonomy-or-beneficence/lane-v.-candura.md) — no-title-match
- [In re Sampson](review/unit-5.-deciding-for-others-autonomy-or-beneficence/in-re-sampson.md) — no-title-match
- [Green Appeals I & II](review/unit-5.-deciding-for-others-autonomy-or-beneficence/green-appeals-i-and-ii.md) — no-title-match
- [Hart v. Brown](review/unit-5.-deciding-for-others-autonomy-or-beneficence/hart-v.-brown.md) — no-title-match
- [Summation](review/unit-5.-deciding-for-others-autonomy-or-beneficence/summation.md) — no-title-match
- [UNIT 6. The Body as Commodity](review/unit-6.-the-body-as-commodity/README.md) — no-title-match
- [Unit Overview](review/unit-6.-the-body-as-commodity/unit-overview.md) — no-title-match
- [Moore v. Regents of Univ. of California](review/unit-6.-the-body-as-commodity/moore-v.-regents-of-univ.-of-california.md) — no-title-match
- [Hecht v. Superior Court of Los Angeles County](review/unit-6.-the-body-as-commodity/hecht-v.-superior-court-of-los-angeles-county.md) — no-title-match
- [McFall v. Shimp](review/unit-6.-the-body-as-commodity/mcfall-v.-shimp.md) — no-title-match
- [State v. Powell](review/unit-6.-the-body-as-commodity/state-v.-powell.md) — no-title-match
- [Summation](review/unit-6.-the-body-as-commodity/summation.md) — no-title-match — originally hidden
- [UNIT 7](review/unit-7/README.md) — no-title-match — originally hidden
- [Unit Overview](review/unit-7/unit-overview.md) — no-title-match — originally hidden
- [Page 1](review/page-1.md) — different-review