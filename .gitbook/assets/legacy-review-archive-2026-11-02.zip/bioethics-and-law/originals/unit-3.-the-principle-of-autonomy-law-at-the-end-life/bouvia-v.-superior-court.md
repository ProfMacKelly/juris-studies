# Bouvia v. Superior Court

{% hint style="info" %}
Note: This case focuses on (1) the right to refuse/discontinue medical treatment provided without the patient's consent and (2) the nature of interests in denying a patient's right to choose.
{% endhint %}

179 Cal.App.3d 1127 (1986)&#x20;

Court of Appeals of California

**Elizabeth Bouvia** \
**v.** \
**The Superior Court of Los Angeles County;**\
**Harry Glenchur et al.**<br>

\[...]

## \[Majority]

BEACH, J.

Petitioner, Elizabeth Bouvia, a patient in a public hospital, seeks the removal from her body of a [nasogastric tube](#user-content-fn-1)[^1] inserted and maintained against her will and without her consent by physicians who so placed it for the purpose of keeping her alive through involuntary forced feeding.

Petitioner has here filed a petition for [writ of mandamus](https://www.law.cornell.edu/wex/writ_of_mandate_\(mandamus\)) and other extraordinary relief after the trial court denied her a [preliminary injunction](https://www.law.cornell.edu/wex/preliminary_injunction) requiring that the tube be removed and that the hospital and doctors be prohibited from using any other similar procedures. We issued an alternative writ. We have heard oral argument from the parties and now order issuance of a [peremptory writ](https://www.law.cornell.edu/wex/peremptory_writ_of_mandate_\(or_mandamus\)), granting petitioner, Elizabeth Bouvia, the relief for which she prayed.

\[...]

### 2. _Factual Background_

Petitioner is a 28-year-old woman. Since birth she has been afflicted with and suffered from severe cerebral palsy. She is quadriplegic. She is now a patient at a public hospital maintained by one of the [real parties in interest](https://www.law.cornell.edu/wex/real_party_in_interest), the County of Los Angeles. Other parties are physicians, nurses and the medical and support staff employed by the County of Los Angeles. Petitioner's physical handicaps of palsy and quadriplegia have progressed to the point where she is completely bedridden. Except for a few fingers of one hand and some slight head and facial movements, she is immobile. She is physically helpless and wholly unable to care for herself. She is totally dependent upon others for all of her needs. These include feeding, washing, cleaning, toileting, turning, and helping her with elimination and other bodily functions. She cannot stand or sit upright in bed or in a wheelchair. She lies flat in bed and must do so the rest of her life. She suffers also from degenerative and severely crippling arthritis. She is in continual pain. Another tube permanently attached to her chest automatically injects her with periodic doses of morphine which relieves some, but not all of her physical pain and discomfort.

She is intelligent, very mentally competent. She earned a college degree. She was married but her husband has left her. She suffered a miscarriage. She lived with her parents until her father told her that they could no longer care for her. She has stayed intermittently with friends and at public facilities. A search for a permanent place to live where she might receive the constant care which she needs has been unsuccessful. She is without financial means to support herself and, therefore, must accept public assistance for medical and other care.

She has on several occasions expressed the desire to die. In 1983 she sought the right to be cared for in a public hospital in Riverside County while she intentionally "starved herself to death." A court in that county denied her judicial assistance to accomplish that goal. She later abandoned an appeal from that ruling. Thereafter, friends took her to several different facilities, both public and private, arriving finally at her present location. Efforts by the staff of real party in interest County of Los Angeles and its social workers to find her an apartment of her own with publicly paid live-in help or regular visiting nurses to care for her, or some other suitable facility, have proved fruitless.

Petitioner must be spoon fed in order to eat. Her present medical and dietary staff have determined that she is not consuming a sufficient amount of nutrients. Petitioner stops eating when she feels she cannot orally swallow more, without nausea and vomiting. As she cannot now retain solids, she is fed soft liquid-like food. Because of her previously announced resolve to starve herself, the medical staff feared her weight loss might reach a life-threatening level. Her weight since admission to real parties' facility seems to hover between 65 and 70 pounds. Accordingly, they inserted the subject tube against her will and contrary to her express written instructions.[\[2\]](https://scholar.google.com/scholar_case?case=9832890082603826987\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50#\[2])

Petitioner's counsel argue that her weight loss was not such as to be life threatening and therefore the tube is unnecessary. However, the trial court found to the contrary as a matter of fact, a finding which we must accept. Nonetheless, the point is immaterial, for, as we will explain, a patient has the right to refuse any medical treatment or medical service, even when such treatment is labelled "furnishing nourishment and hydration." This right exists even if its exercise creates a "life threatening condition."

### 3. _The Right to Refuse Medical Treatment._

(1) "\[A] person of adult years and in sound mind has the right, in the exercise of control over his own body, to determine whether or not to submit to lawful medical treatment." [_Cobbs_ v. _Grant_ (1972)](https://scholar.google.com/scholar_case?case=9007336518867928085\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50) \[...][^2]. It follows that such a patient has the right to refuse _any_ medical treatment, even that which may save or prolong her life. [_Barber_ v. _Superior Court_ (1983) ](https://scholar.google.com/scholar_case?case=14346556346268892374\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)\[...][^3]; [_Bartling_ v. _Superior Court_ (1984) ](https://scholar.google.com/scholar_case?case=18391762142037301809\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)\[...][^4]. In our view the foregoing authorities are dispositive of the case at bench. Nonetheless, the county and its medical staff contend that for reasons unique to this case Elizabeth Bouvia may not exercise the right available to others. Accordingly, we again briefly discuss the rule in the light of real parties' contentions.

The right to refuse medical treatment is basic and fundamental. It is recognized as a part of the right of privacy protected by both the state and federal constitutions. Cal. Const., art. I, § 1; [_Griswold_ v. _Connecticut_ (1965) ](https://scholar.google.com/scholar_case?case=12276922145000050979\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)\[...][^5]. Its exercise requires no one's approval. It is not merely one vote subject to being overridden by medical opinion.

In [_Barber_ v. _Superior Court, supra_](https://scholar.google.com/scholar_case?case=14346556346268892374\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50) \[...][^6],   we considered this same issue although in a different context. Writing on behalf of this division, Justice Compton thoroughly analyzed and reviewed the issue of withdrawal of life-support systems beginning with the seminal case of the [_Matter of Quinlan_ (1976)](https://scholar.google.com/scholar_case?case=12643283625542054584\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50) \[...][^7],   and continuing on to the then recent enactment of the California Natural Death Act \[...][^8].&#x20;

(2) His opinion clearly and repeatedly stresses the fundamental underpinning of its conclusion, i.e., the patient's right to decide: at [page 1015](https://scholar.google.com/scholar_case?case=14346556346268892374\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50#p1015), "In this state a clearly recognized legal right to control one's own medical treatment predated the Natural Death Act. A long line of cases, approved by the Supreme Court in [_Cobbs_ v. _Grant_ (1972) 8 Cal.3d 229](https://scholar.google.com/scholar_case?case=9007336518867928085\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50) ... have held that where a doctor performs treatment in the absence of an informed consent, there is an actionable battery. The obvious corollary to this principle is that _a competent adult patient has the legal right to refuse medical treatment_" (italics added); at [page 1019](https://scholar.google.com/scholar_case?case=14346556346268892374\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50#p1019), "\[T]he _patient's interests and desires are the key_ ingredients of the decision-making process" (italics added); at [page 1020](https://scholar.google.com/scholar_case?case=14346556346268892374\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50#p1020), "Given the general standards for determining when there is a duty to provide medical treatment of debatable value, the question still remains as to who should make these vital decisions. Clearly, the medical diagnoses and prognoses must be determined by the treating and consulting physicians under the generally accepted standards of medical practice in the community and, _whenever possible, the patient himself should then be the ultimate decisionmaker_" (italics added); at [page 1021](https://scholar.google.com/scholar_case?case=14346556346268892374\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50#p1021), "The authorities are in agreement that any surrogate, court appointed or otherwise, ought to be guided in his or her decisions first by his knowledge of _the patient's own desires_ and feelings, to the extent that they were expressed before the patient became incompetent." (Italics added.)

[_Bartling_ v. _Superior Court_](https://scholar.google.com/scholar_case?case=18391762142037301809\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50) \[...][^9], was factually much like the case at bench. Although not totally identical in all respects, the issue there centered on the same question here present: i.e., "May the patient refuse even life continuing treatment?" Justice Hastings, writing for another division of this court, explained: "In this case we are called upon to decide whether a competent adult patient, with serious illnesses which are probably incurable but have not been diagnosed as terminal, has the right, over the objection of his physicians and the hospital, to have life-support equipment disconnected despite the fact that withdrawal of such devices will surely hasten his death." \[...][^10]&#x20;

> (1) Mr. Bartling's illnesses were serious but not terminal, and had not been diagnosed as such; (2) although Mr. Bartling was attached to a respirator to facilitate breathing, he was not in a vegetative state and was not comatose; and (3) Mr. Bartling was competent in the legal sense. \[...] The court below concluded that as long as there was some potential for restoring Mr. Bartling to a \`cognitive, sapient life,' it would not be appropriate to issue an injunction in this case. \[...] (3) We conclude that the trial court was incorrect when it held that the right to have life-support equipment disconnected was limited to comatose, terminally ill patients, or representatives acting on their behalf.&#x20;

\[...][^11] The description of Mr. Bartling's condition fits that of Elizabeth Bouvia. The holding of that case applies here and compels real parties to respect her decision even though she is not "terminally" ill. The trilogy of _Cobbs_ v. _Grant_ \[...][^12], _Barber_ v. _Superior Court_ \[...][^13], and _Bartling_ v. _Superior Court_ \[...][^9], with their thorough explanation and discussion, are authority enough and in reality provide a complete answer to the position and assertions of real parties' medical personnel.

But if additional persuasion be needed, there is ample. As indicated by the discussion in _Bartling_ and _Barber,_ substantial and respectable authority throughout the country recognize the right which petitioner seeks to exercise. Indeed, it is neither radical nor startlingly new. It is a basic and constitutionally predicated right. More than 70 years ago, Judge Benjamin Cardozo observed: "Every human being of adult years and sound mind has a right to determine what shall be done with his own body...." [_Schloendorff_ v. _Society of New York Hospital_ (1914) ](https://scholar.google.com/scholar_case?about=14853986379334093714\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)\[...][^14].

[_Matter of Spring_ (1980) ](https://scholar.google.com/scholar_case?case=9134781363504382517\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)\[...][^15], [_Lane_ v. _Candura_ (Mass. App. 1978) ](https://scholar.google.com/scholar_case?case=12758396049872879027\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)\[...][^16], [_Matter of Quackenbush_ (1978) ](https://scholar.google.com/scholar_case?case=8089034255677560166\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)\[...][^17], [_Matter of Conroy_ (1985)](https://scholar.google.com/scholar_case?case=2290154573715145215\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50) \[...[^18]], \[etc.][^19], are but a few examples of the decisions that have upheld a patient's right to refuse medical treatment even at risk to his health or his very life.

(4) Further recognition that this right is paramount to even medical recommendation is evidenced by several declarations of public and professional policy which were noted in both the _Barber_ and _Bartling_ cases.

For example, addressing one part of the problem, California passed the "Natural Death Act," Health and Safety Code \[...][^20]. Although addressed to terminally ill patients, the significance of this legislation is its expression as state policy "that adult persons have the fundamental right to control the decisions relating to the rendering of their own medical care...." Health & Saf. Code, § 7186. Section 7188 provides the method whereby an adult person may execute a directive for the withholding or withdrawal of life-sustaining procedures. Recognition of the right of other persons who may not be terminally ill and may wish to give other forms of direction concerning their medical care is expressed in section 7193:&#x20;

> Nothing in this chapter shall impair or supersede any legal right or legal responsibility which any person may have to effect the withholding or withdrawal of life-sustaining procedures in any lawful manner. In such respect the provisions of this chapter are cumulative.

(5) Moreover, as the _Bartling_ decision holds, there is no practical or logical reason to limit the exercise of this right to "terminal" patients. The right to refuse treatment does not need the sanction or approval by any legislative act, directing how and when it shall be exercised.

(6) In large measure the courts have sought to protect and insulate medical providers from criminal and tort liability. E.g., [_Barber_ v. _Superior Court_ ](https://scholar.google.com/scholar_case?case=14346556346268892374\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)\[...][^21]. The California Natural Death Act also illustrates this approach. Nonetheless, as indicated, it too recognizes, even if inferentially, the existence of the right, even in a nonterminal patient, which overrides the concern for protecting the medical profession.

(7) This right is again reflected in the statute concerning execution of a power of attorney for health care (Civ. Code, § 2500), which states in pertinent part:&#x20;

> NOTWITHSTANDING THIS DOCUMENT, YOU HAVE THE RIGHT TO MAKE MEDICAL AND OTHER HEALTH CARE DECISIONS FOR YOURSELF SO LONG AS YOU CAN GIVE INFORMED CONSENT WITH RESPECT TO THE PARTICULAR DECISION. IN ADDITION, NO TREATMENT MAY BE GIVEN TO YOU OVER YOUR OBJECTION AT THE TIME....

Title 22 of the California Administrative Code provides guidelines for health facilities. Section 70707 directs that hospitals and medical staff\[] shall adopt and post a written policy on patients' rights which shall include the right to\[:]

> (5) Receive as much information about any proposed treatment or procedure as the patient may need in order to give informed consent or to refuse this course of treatment ... (6) Participate actively in decisions regarding medical care. To the extent permitted by law, this includes the right to refuse treatment.

&#x20;(8) A recent Presidential Commission for the Study of Ethical Problems in Medicine and Biomedical and Behavioral Research concluded in part: "The voluntary choice of a competent and informed patient should determine whether or not life-sustaining therapy will be undertaken, just as such choices provide the basis for other decisions about medical treatment. Health care institutions and professionals should try to enhance patients' abilities to make decisions on their own behalf and to promote understanding of the available treatment options.... Health care professionals serve patients best by maintaining a presumption in favor of sustaining life, while recognizing that competent patients are entitled to choose to forego any treatments, including those that sustain life." [_Deciding to Forego Life-Sustaining Treatment_](https://repository.library.georgetown.edu/handle/10822/559344)_,_ at pp. 3, 5 (U.S. GPO 1983) \[...][^22].

<mark style="background-color:yellow;">On December 11, 1985, the Los Angeles County Bar Association, and on January 6, 1986, the Los Angeles County Medical</mark> Association recognized as general principles for decision making the conclusions as expressly stated in the cases of _Barber_ and _Bartling_ and endorsed the conclusion of the [Presidential Commission cited above](https://repository.library.georgetown.edu/handle/10822/559344).&#x20;

The American Hospital Association (AHA) Policy and Statement of Patients' Choices of Treatment Options, approved by the American Hospital Association in February of 1985 discusses the value of a collaborative relationship between the patient and the physician and states in pertinent part: "Whenever possible, however, the authority to determine the course of treatment, if any, should rest with the patient" and "the right to choose treatment includes the right to refuse a specific treatment _or all treatment._ ..."

Again, this statement reflects the fact that the controlling decision belongs to a competent, informed patient. It also contains a discussion of how that consent should be documented, and the desirability of a cooperative effort. Of course, none of the problems of incapacity due to age, unconsciousness, mental disease or disability mentioned in the policy statement affect the case before us.

Significant also is the statement adopted on March 15, 1986, by the Council on Ethical and Judicial Affairs of the American Medical Association. It is entitled "Withholding or Withdrawing Life Prolonging Medical Treatment."&#x20;

(9) In pertinent part, it declares:&#x20;

> The social commitment of the physician is to sustain life and relieve suffering. Where the performance of one duty conflicts with the other, the choice of the patient, or his family or legal representative if the patient is incompetent to act in his own behalf, should prevail. \[...] Life prolonging medical treatment includes medication and artificially or technologically supplied respiration, nutrition or hydration. In treating a terminally ill or irreversibly comatose patient, the physician should determine whether the benefits of treatment outweigh its burdens. At all times, the dignity of the patient should be maintained.

We do not believe that all of the foregoing case law and statements of policy and statutory recognition are mere lip service to a fictitious right. As noted in _Bartling_ "We do not doubt the sincerity of \[the hospital and medical personnel's] moral and ethical beliefs, or their sincere belief in the position they have taken in this case.&#x20;

(10) However, if the right of the patient to self-determination as to his own medical treatment is to have any meaning at all, it must be paramount to the interests of the patient's hospital and doctors.... The right of a competent adult patient to refuse medical treatment is a constitutionally guaranteed right which must not be abridged." \[...]

It is indisputable that petitioner is mentally competent. She is not comatose. She is quite intelligent, alert, and understands the risks involved.

### 4. _The Claimed Exceptions to the Patient's Right to Choose Are Inapplicable._

As in _Bartling_ the real parties in interest, a county hospital, its physicians and administrators, urge that the interests of the state should prevail over the rights of Elizabeth Bouvia to refuse treatment. Advanced by real parties under this argument are the state's interests in (1) preserving life, (2) preventing suicide, (3) protecting innocent third parties, and (4) maintaining the ethical standards of the medical profession, including the right of physicians to effectively render necessary and appropriate medical service and to refuse treatment to an uncooperative and disruptive patient. Included, whether as part of the above or as separate and additional arguments, are what real parties assert as distinctive facts not present in other cases, i.e., (1) petitioner is a patient in a public facility, thereby making the state a party to the result of her conduct, (2) she is not comatose, nor incurably, nor terminally ill, nor in a vegetative state, all conditions which have justified the termination of life-support system in other instances, (3) she has asked for medical treatment, therefore, she cannot accept a part of it while cutting off the part that would be effective, and (4) she is, in truth, trying to starve herself to death and the state will not be a party to a suicide.

Nearly all of these arguments are answered by the discussion and reasoning in the _Bartling_ and _Barber_ cases. Nonetheless, we address ourselves briefly to some of the asserted factual differences between Mr. Bartling or patients in the other cited cases and Mrs. Bouvia. We conclude they are insufficient to deny her the right to refuse medical treatment afforded others.

(11) At bench the trial court concluded that with sufficient feeding petitioner could live an additional 15 to 20 years; therefore, the preservation of petitioner's life for that period outweighed her right to decide. In so holding the trial court mistakenly attached undue importance to the _amount of time_ possibly available to petitioner, and failed to give equal weight and consideration for the _quality_ of that life; an equal, if not more significant, consideration.

All decisions permitting cessation of medical treatment or life-support procedures to some degree hastened the arrival of death. In part, at least, this was permitted because the quality of life during the time remaining in those cases had been terribly diminished. In Elizabeth Bouvia's view, the quality of her life has been diminished to the point of hopelessness, uselessness, unenjoyability and frustration. She, as the patient, lying helplessly in bed, unable to care for herself, may consider her existence meaningless. She cannot be faulted for so concluding. If her right to choose may not be exercised because there remains to her, in the opinion of a court, a physician or some committee, a certain arbitrary number of years, months, or days, her right will have lost its value and meaning.

Who shall say what the minimum amount of available life must be? Does it matter if it be 15 to 20 years, 15 to 20 months, or 15 to 20 days, if such life has been physically destroyed and its quality, dignity and purpose gone? As in all matters lines must be drawn at some point, somewhere, but that decision must ultimately belong to the one whose life is in issue.

(12) Here Elizabeth Bouvia's decision to forego medical treatment or life-support through a mechanical means belongs to her. It is not a medical decision for her physicians to make. Neither is it a legal question whose soundness is to be resolved by lawyers or judges. It is not a conditional right subject to approval by ethics committees or courts of law. It is a moral and philosophical decision that, being a competent adult, is her's alone.

(13) Adapting the language of [_Satz_ v. _Perlmutter_](https://scholar.google.com/scholar_case?case=5715334553857679425\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50) \[...][^23], "It is all very convenient to insist on continuing \[Elizabeth Bouvia's] life so that there can be no question of foul play, no resulting civil liability and no possible trespass on medical ethics. However, it is quite another matter to do so at the patient's sole expense and against \[her] competent will, thus inflicting never ending physical torture on \[her] body until the inevitable, but artificially suspended, moment of death. Such a course of conduct invades the patient's constitutional right of privacy, removes \[her] freedom of choice and invades \[her] right to self-determine." \[...][^24]

Here, if force fed, petitioner faces 15 to 20 years of a painful existence, endurable only by the constant administrations of morphine. Her condition is irreversible. There is no cure for her palsy or arthritis. Petitioner would have to be fed, cleaned, turned, bedded, toileted by others for 15 to 20 years! Although alert, bright, sensitive, perhaps even brave and feisty, she must lie immobile, unable to exist except through physical acts of others. Her mind and spirit may be free to take great flights but she herself is imprisoned and must lie physically helpless subject to the ignominy, embarrassment, humiliation and dehumanizing aspects created by her helplessness. We do not believe it is the policy of this state that all and every life must be preserved against the will of the sufferer. It is incongruous, if not monstrous, for medical practitioners to assert their right to preserve a life that someone else must live, or, more accurately, endure, for "15 to 20 years." We cannot conceive it to be the policy of this state to inflict such an ordeal upon anyone.

(14) It is, therefore, immaterial that the removal of the nasogastric tube will hasten or cause Bouvia's eventual death. Being competent she has the right to live out the remainder of her natural life in dignity and peace. It is precisely the aim and purpose of the many decisions upholding the withdrawal of life-support systems to accord and provide as large a measure of dignity, respect and comfort as possible to every patient for the remainder of his days, whatever be their number. This goal is not to hasten death, though its earlier arrival may be an expected and understood likelihood.

Real parties assert that what petitioner really wants is to "commit suicide" by starvation at their facility. The trial court in its statement of decision said: "It is fairly clear from the evidence and the court cannot close its eyes to the fact that \[petitioner] during her stay in defendant hospital, and for some time prior thereto, has formed an intent to die. She has voiced this desire to a member of the staff of defendant hospital. She claims, however, she does not wish to commit suicide. On the evidence, this is but a semantic distinction. The reasonable inference to be drawn from the evidence is that \[petitioner] in \[the] defendant facility has purposefully engaged in a selective rejection of medical treatment and nutritional intake to accomplish her objective and accept only treatment which gives her some degree of comfort pending her demise. Stated another way, \[petitioner's] refusal of medical treatment and nutritional intake is motivated not by a bona fide exercise of her right of privacy but by a desire to terminate her life.... \[...] Here \[petitioner] wishes to pursue her objective to die by the use of public facilities with staff standing by to furnish her medical treatment to which she consents and to refrain from that which she refuses."

(15) Overlooking the fact that a desire to terminate one's life is probably the ultimate exercise of one's right to privacy, we find no substantial evidence to support the court's conclusion. Even if petitioner had the specific intent to commit suicide in 1983, while at Riverside, she did not carry out that plan. Then she apparently had the ability, without artificial aids, to consume sufficient nutrients to sustain herself; now she does not. That is to say, the trial court here made the following express finding, "Plaintiff, when she chooses, can orally ingest food by masticating \`finger food' _though additional nutritional intake is required intravenously and by nasogastric tube._ ..." (Italics added.) As a consequence of her changed condition, it is clear she has now merely resigned herself to accept an earlier death, if necessary, rather than live by feedings forced upon her by means of a nasogastric tube. Her decision to allow nature to take its course is not equivalent to an election to commit suicide with real parties aiding and abetting therein. \[...][^25]

Moreover, the trial court seriously erred by basing its decision on the "motives" behind Elizabeth Bouvia's decision to exercise her rights. If a right exists, it matters not what "motivates" its exercise. We find nothing in the law to suggest the right to refuse medical treatment may be exercised only if the patient's _motives_ meet someone else's approval. It certainly is not illegal or immoral to prefer a natural, albeit sooner, death than a drugged life attached to a mechanical device.

(16) It is not necessary to here define or dwell at length upon what constitutes suicide. Our Supreme Court dealt with the matter in the case of [_In re Joseph G._ (1983)](https://scholar.google.com/scholar_case?case=13400715017943289813\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50) \[...][^26], wherein, declaring that the state has an interest in preserving and recognizing the sanctity of life, it observed that it is a crime to aid in suicide. But it is significant that the instances and the means there discussed all involved affirmative, assertive, proximate, direct conduct such as furnishing a gun, poison, knife, or other instrumentality or usable means by which another could physically and immediately inflict some death-producing injury upon himself. Such situations are far different than the mere presence of a doctor during the exercise of his patient's constitutional rights.

This is the teaching of _Bartling_ and _Barber._ No criminal or civil liability attaches to honoring a competent, informed patient's refusal of medical service.

(17) We do not purport to establish what will constitute proper medical practice in all other cases or even other aspects of the care to be provided petitioner. We hold only that her right to refuse medical treatment, even of the life-sustaining variety, entitles her to the immediate removal of the nasogastric tube that has been involuntarily inserted into her body. The hospital and medical staff are still free to perform a substantial if not the greater part of their duty, i.e., that of trying to alleviate Bouvia's pain and suffering.

Petitioner is without means to go to a private hospital and, apparently, real parties' hospital as a public facility was required to accept her. Having done so it may not deny her relief from pain and suffering merely because she has chosen to exercise her fundamental right to protect what little privacy remains to her.

(18) Personal dignity is a part of one's right of privacy. Such a right of bodily privacy led the United States Supreme Court to hold that it shocked its conscience to learn that a state, even temporarily, had put a tube into the stomach of a criminal defendant to recover swallowed narcotics. [_Rochin_ v. _California_ (1952)](https://scholar.google.com/scholar_case?case=13189177772806165249\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50) \[...][^27].Petitioner asks for no greater consideration.

IT IS ORDERED:

Let a peremptory writ of mandate issue commanding the Los Angeles Superior Court immediately \[enter an] order granting Elizabeth Bouvia's request for a preliminary injunction, and the relief prayed for therein; in particular to make an order (1) directing real parties in interest forthwith to remove the nasogastric tube from petitioner, Elizabeth Bouvia's body, and (2) prohibiting any and all of the real parties in interest from replacing or aiding in replacing said tube or any other or similar device in or on petitioner without her consent. \[...]

## \[Concurrence]

Roth, P.J., and Compton, J., concurred.

COMPTON, J.

Although I have concurred in the very well reasoned and superbly crafted opinion of my colleague Justice Beach, I feel compelled to write separately and reflect on what I consider to be one of the real tragedies of this case, which is that Elizabeth Bouvia has had to go to such ends to obtain relief from her suffering.

Fate has dealt this young woman a terrible hand. Can anyone blame her if she wants to fold her cards and say "I am out"? Yet medical personnel who have had charge of her case have attempted to force Elizabeth to continue in the game. In their efforts they have been abetted by two different trial courts.

This is not to say that those members of the medical profession and those courts were not well motivated. In each instance the persons involved have expressed a concern for the sanctity of life and a desire to avoid any conduct that could be characterized as aiding in a suicide. Undoubtedly, those persons were, in no small way, influenced by the presence in our law of Penal Code section 401, which imposes penal sanctions on persons who aid and abet in a suicide.

In my opinion, as I shall point out, the application of that statute to circumstances such as are present here is archaic and inhumane.

I have no doubt that Elizabeth Bouvia wants to die; and if she had the full use of even one hand, could probably find a way to end her life — in a word — commit suicide. In order to seek the assistance which she needs in ending her life by the only means she sees available — starvation — she has had to stultify her position before this court by disavowing her desire to end her life in such a fashion and proclaiming that she will eat all that she can physically tolerate. Even the majority opinion here must necessarily "dance" around the issue.

Elizabeth apparently has made a conscious and informed choice that she prefers death to continued existence in her helpless and, to her, intolerable condition. I believe she has an absolute right to effectuate that decision. This state and the medical profession, instead of frustrating her desire, should be attempting to relieve her suffering by permitting and in fact assisting her to die with ease and dignity. The fact that she is forced to suffer the ordeal of self-starvation to achieve her objective is in itself inhumane.

The right to die is an integral part of our right to control our own destinies so long as the rights of others are not affected. That right should, in my opinion, include the ability to enlist assistance from others, including the medical profession, in making death as painless and quick as possible.

That ability should not be hampered by the state's threat to impose penal sanctions on those who might be disposed to lend assistance.

The medical profession, freed of the threat of governmental or legal reprisal, would, I am sure, have no difficulty in accommodating an individual in Elizabeth's situation.

The Hippocratic Oath reads in pertinent part: "... I will follow that method of treatment which, according to my ability and judgment, I consider for the benefit of my patients.... I will give no deadly medicine to anyone if asked...." Surely, adherence to that oath would yet admit of a reasonable balancing between the doctor's obligation to alleviate suffering and his obligation to preserve life, remembering that the term "life" has itself recently undergone substantial redefinition.

It is also worth noting that the original oath also contained the phrase "... I will not give to a woman an instrument to produce abortion...." Obviously, the profession has already accommodated a deviation from that part of the oath.

Whatever choice Elizabeth Bouvia may ultimately make, I can only hope that her courage, persistence and example will cause our society to deal realistically with the plight of those unfortunate individuals to whom death beckons as a welcome respite from suffering.

If there is ever a time when we ought to be able to get the "government off our backs" it is when we face death — either by choice or otherwise.

\[...]

***

Tags: autonomy, informed consent, self-determination, feeding tube, artificial nutrition, artificial hydration, withdrawal of treatment, right to die, right to refuse treatment, right to refuse medical treatment, sound mind, competence, quality of life, life support, privacy

***

<details>

<summary><mark style="color:red;"><strong>Attributions and Licensing</strong></mark></summary>

Editing to the [original](https://scholar.google.com/scholar_case?case=9832890082603826987\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50), excluding any original footnotes (hyperlinked or otherwise), by Matthew L. Mac Kelly. Judicial decisions are not subject to copyright protection and are in the public domain. _See Georgia v. Public.Resource.Org, Inc_., [140 S.Ct. 1498](https://scholar.google.com/scholar_case?case=8288711378870515248\&q=Georgia+et+al.+v.+Public.Resource.Org,+Inc.\&hl=en\&as_sdt=6,50) (2020). This page is in the public domain.

</details>

[^1]: Nasogastric tubes are tubes inserted through the nose to pass food and medication into the stomach. See [here ](https://medlineplus.gov/ency/patientinstructions/000182.htm)and [here](https://www.ncbi.nlm.nih.gov/books/NBK556063/).

[^2]: [8 Cal.3d 229, 242 \[104 Cal. Rptr. 505, 502 P.2d 1\]](https://scholar.google.com/scholar_case?case=9007336518867928085\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50#p242)

[^3]: [147 Cal. App.3d 1006 \[195 Cal. Rptr. 484\]](https://scholar.google.com/scholar_case?case=14346556346268892374\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^4]: [163 Cal. App.3d 186 \[209 Cal. Rptr. 220\]](https://scholar.google.com/scholar_case?case=18391762142037301809\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^5]: [381 U.S. 479, 484 \[14 L.Ed.2d 510, 514-515, 85 S.Ct. 1678\]](https://scholar.google.com/scholar_case?case=12276922145000050979\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50); [_Bartling_ v. _Superior Court, supra,_ 163 Cal. App.3d 186](https://scholar.google.com/scholar_case?case=18391762142037301809\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^6]: [147 Cal. App.3d 1006](https://scholar.google.com/scholar_case?case=14346556346268892374\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^7]: [70 N.J. 10 \[355 A.2d 647\],](https://scholar.google.com/scholar_case?case=12643283625542054584\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50) cert. den. [429 U.S. 922 \[50 L.Ed.2d 289, 97 S.Ct. 319\]](https://scholar.google.com/scholar_case?case=15689426437417288822\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^8]: Health & Saf. Code, §§ 7185-7195

[^9]: [_supra,_ 163 Cal. App.3d 186](https://scholar.google.com/scholar_case?case=18391762142037301809\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^10]: _Id_., at p. 189.

[^11]: _Id_., at p. 193.

[^12]: [_supra,_ 8 Cal.3d 229](https://scholar.google.com/scholar_case?case=9007336518867928085\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^13]: [_supra,_ 147 Cal. App.3d 1006](https://scholar.google.com/scholar_case?case=14346556346268892374\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^14]: [211 N.Y. 125 \[105 N.E. 92, 93\]](https://scholar.google.com/scholar_case?about=14853986379334093714\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^15]: [380 Mass. 629 \[405 N.E.2d 115\]](https://scholar.google.com/scholar_case?case=9134781363504382517\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^16]: [6 Mass. App. 377 \[376 N.E.2d 1232\]](https://scholar.google.com/scholar_case?case=12758396049872879027\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^17]: [156 N.J. Super. 282 \[383 A.2d 785\]](https://scholar.google.com/scholar_case?case=8089034255677560166\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^18]: [98 N.J. 321 \[486 A.2d 1209\]](https://scholar.google.com/scholar_case?case=2290154573715145215\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^19]: [_Satz_ v. _Perlmutter_ (Fla. 1980)](https://scholar.google.com/scholar_case?case=16955207479377222497\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50); [_In re Osborne_ (D.C.App. 1972)](https://scholar.google.com/scholar_case?case=2425528146410299885\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50);  [_Supt. of Belchertown_ v. _Saikewicz_ (1977) ](https://scholar.google.com/scholar_case?case=2165107287898894579\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)&#x20;

[^20]: section 7185 et seq.&#x20;

[^21]: [_supra,_ 147 Cal. App.3d 1106](https://scholar.google.com/scholar_case?case=14346556346268892374\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^22]: Report of the President's Commission for the Study of Ethical Problems in Medicine and Biomedical and Behavioral Research.

[^23]: [_supra,_ 362 So.2d 160](https://scholar.google.com/scholar_case?case=5715334553857679425\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^24]: [_Satz_ v. _Perlmutter, supra,_ at p. 164](https://scholar.google.com/scholar_case?case=5715334553857679425\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50).

[^25]: [_Bartling_ v. _Sup. Court_](https://scholar.google.com/scholar_case?case=18391762142037301809\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50); [_Lane_ v. _Candura_](https://scholar.google.com/scholar_case?case=12758396049872879027\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50).

[^26]: [ 34 Cal.3d 429 \[194 Cal. Rptr. 163, 667 P.2d 1176, 40 A.L.R.4th 690\]](https://scholar.google.com/scholar_case?case=13400715017943289813\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50)

[^27]: [ 342 U.S. 165 \[96 L.Ed. 183, 72 S.Ct. 205\]](https://scholar.google.com/scholar_case?case=13189177772806165249\&q=179+Cal.App.3d+1127\&hl=en\&as_sdt=6,50).)&#x20;
