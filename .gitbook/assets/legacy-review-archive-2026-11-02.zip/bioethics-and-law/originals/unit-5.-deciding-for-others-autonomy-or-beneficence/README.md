# UNIT 5. Deciding for Others: Autonomy or Beneficence?

## Sections

[Unit Overview](unit-5.-deciding-for-others-autonomy-or-beneficence/unit-overview)

[_Lane v. Candura_](unit-5.-deciding-for-others-autonomy-or-beneficence/lane-v.-candura)

[_In re Sampson_](unit-5.-deciding-for-others-autonomy-or-beneficence/in-re-sampson)

[_Green Appeals I_ & _II_](unit-5.-deciding-for-others-autonomy-or-beneficence/green-appeals-i-and-ii)

[_Hart v. Brown_](unit-5.-deciding-for-others-autonomy-or-beneficence/hart-v.-brown)

[Summation](unit-5.-deciding-for-others-autonomy-or-beneficence/summation)
