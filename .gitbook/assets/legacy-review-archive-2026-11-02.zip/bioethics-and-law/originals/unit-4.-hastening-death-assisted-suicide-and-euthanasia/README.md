# UNIT 4. Hastening Death: Assisted Suicide and Euthanasia

## Sections

[Unit Overview](unit-4.-hastening-death-assisted-suicide-and-euthanasia/unit-overview)

[_Cruzan v. Director, Missouri Dept. of Health_](unit-4.-hastening-death-assisted-suicide-and-euthanasia/cruzan-v.-director-missouri-dept.-of-health)

[_Washington v. Glucksberg_](unit-4.-hastening-death-assisted-suicide-and-euthanasia/washington-v.-glucksberg)

[_Michigan v. Kevorkian_](unit-4.-hastening-death-assisted-suicide-and-euthanasia/michigan-v.-kevorkian)

[The Empirical Slippery Slope from Voluntary to Non-Voluntary Euthanasia](unit-4.-hastening-death-assisted-suicide-and-euthanasia/the-empirical-slippery-slope-from-voluntary-to-non-voluntary-euthanasia)
