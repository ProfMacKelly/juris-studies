> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Law Sourcebook](https://profmackelly.gitbook.io/criminal-law-sourcebook/) · Snapshot: 2026-11-02 · Original path: `readme`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-law/1.0) · [Candidate 2](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-law/the-legal-system-in-the-united-states)

---

# The Legal System in the United States

Presently, this repository merely stores files for an open source undergraduate criminal law textbook, with material sourced from my Libretexts site. I am converting these into markdown and developing them further.
