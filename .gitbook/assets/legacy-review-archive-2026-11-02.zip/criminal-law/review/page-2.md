> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Law Sourcebook](https://profmackelly.gitbook.io/criminal-law-sourcebook/page-2) · Snapshot: 2026-11-02 · Original path: `page-2`

---

# Page 2

