> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Law Sourcebook](https://profmackelly.gitbook.io/criminal-law-sourcebook/quiz) · Snapshot: 2026-11-02 · Original path: `quiz`

---

# quiz



{% embed url="https://docs.google.com/forms/d/e/1FAIpQLSe0mZE5uscArEtGGpwvYa1GhV4wduZLX8_2niwIGn7AHbUHjg/viewform?usp=publish-editor" %}
