# Criminal Law Sourcebook — Legacy Review Archive

> REVIEW ARCHIVE. Juris Studies is the main version. These snapshots are retained for editorial comparison, not as the approved teaching version.

Snapshot date: 2026-11-02. Source space: `T0wDylvHqeWCn2aRzrOa`. Source revision: `2gAuSKq3ihnvVOBGVHf3`.

Legacy site: https://profmackelly.gitbook.io/criminal-law-sourcebook/

The originals/ folder contains the exact Markdown returned by the pinned GitBook revision. These are API Markdown snapshots, not byte-for-byte exports of repository files. The review/ folder contains the same text with resolvable legacy-relative links made absolute and a source/review notice added. Footnotes, attributions and conflict text remain present. Media stays linked to the existing public source URLs; binary media is not bundled.

pages.csv lists all retained readings, original visibility, the comparison classification and possible Juris Studies counterparts. Candidate counterparts are aids for human review. No title match does not prove a topic is missing or unique.

## Readings

- [The Legal System in the United States](review/README.md) — different-review — originally hidden
- [Page 1](review/page-1.md) — different-review
- [Page 2](review/page-2.md) — no-title-match
- [quiz](review/quiz.md) — no-title-match
- [Microsoft Forms](review/microsoft-forms.md) — no-title-match