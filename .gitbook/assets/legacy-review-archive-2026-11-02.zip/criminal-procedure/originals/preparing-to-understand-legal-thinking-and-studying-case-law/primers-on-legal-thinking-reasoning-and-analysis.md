# Primers on Legal Thinking, Reasoning & Analysis

### Contents

{% content-ref url="primers-on-legal-thinking-reasoning-and-analysis/introduction-to-deductive-rule-based-reasoning" %}
[introduction-to-deductive-rule-based-reasoning](primers-on-legal-thinking-reasoning-and-analysis/introduction-to-deductive-rule-based-reasoning)
{% endcontent-ref %}

{% content-ref url="primers-on-legal-thinking-reasoning-and-analysis/introduction-to-analogical-reasoning-a-type-of-inductive-reasoning" %}
[introduction-to-analogical-reasoning-a-type-of-inductive-reasoning](primers-on-legal-thinking-reasoning-and-analysis/introduction-to-analogical-reasoning-a-type-of-inductive-reasoning)
{% endcontent-ref %}

{% content-ref url="primers-on-legal-thinking-reasoning-and-analysis/is-a-hot-dog-a-sandwich" %}
[is-a-hot-dog-a-sandwich](primers-on-legal-thinking-reasoning-and-analysis/is-a-hot-dog-a-sandwich)
{% endcontent-ref %}

{% content-ref url="primers-on-legal-thinking-reasoning-and-analysis/avoid-bald-assertions" %}
[avoid-bald-assertions](primers-on-legal-thinking-reasoning-and-analysis/avoid-bald-assertions)
{% endcontent-ref %}
