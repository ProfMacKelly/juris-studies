# Introduction to Reading & Briefing Cases

### Contents

{% content-ref url="introduction-to-reading-and-briefing-cases/how-to-read-a-case" %}
[how-to-read-a-case](introduction-to-reading-and-briefing-cases/how-to-read-a-case)
{% endcontent-ref %}

{% content-ref url="introduction-to-reading-and-briefing-cases/case-briefing-tutorials" %}
[case-briefing-tutorials](introduction-to-reading-and-briefing-cases/case-briefing-tutorials)
{% endcontent-ref %}

{% content-ref url="introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs" %}
[annotated-cases-and-annotated-examples-of-case-briefs](introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs)
{% endcontent-ref %}

{% content-ref url="introduction-to-reading-and-briefing-cases/exercise-brief-the-case" %}
[exercise-brief-the-case](introduction-to-reading-and-briefing-cases/exercise-brief-the-case)
{% endcontent-ref %}
