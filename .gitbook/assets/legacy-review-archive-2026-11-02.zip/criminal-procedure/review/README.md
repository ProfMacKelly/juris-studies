> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/) · Snapshot: 2026-11-02 · Original path: `readme`

---

# Criminal Procedure Sourcebook

:construction\_site: This book is under construction. :construction:

***

_Criminal Procedure Sourcebook_ is an [open educational resource](#user-content-fn-1)[^1], focusing on the balance between the public interest in controlling, investigating, and prosecuting criminal conduct and the private interest of individuals in protecting their reasonable expectation of privacy and protecting against arbitrary government deprivations of liberty and property.

This book [openly licensed](#user-content-fn-2)[^2] and free to be reused, redistributed, [adapted, and/or remixed](https://help.oercommons.org/support/solutions/articles/42000046860-remix-a-resource). It includes both content that was authored by Matthew L. Mac Kelly and adapted, remixed, and/or incorporated from other creators in compliance with copyright and licensing regulations and practices.  Attributions and licensing information is identified on each page.

\~ _Matt Mac Kelly, JD, EdD_

***

## Contents

{% stepper %}
{% step %}
{% content-ref url="https://profmackelly.gitbook.io/criminal-procedure/front-matter" %}
[front-matter](https://profmackelly.gitbook.io/criminal-procedure/front-matter)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law" %}
[preparing-to-understand-legal-thinking-and-studying-case-law](https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="readme-1" %}
[readme-1](readme-1)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="https://profmackelly.gitbook.io/criminal-procedure/2.-overview-of-probable-cause-and-reasonable-suspicion" %}
[2.-overview-of-probable-cause-and-reasonable-suspicion](https://profmackelly.gitbook.io/criminal-procedure/2.-overview-of-probable-cause-and-reasonable-suspicion)
{% endcontent-ref %}
{% endstep %}
{% endstepper %}

[^1]: Free educational material that is openly licensed to enable reuse and redistribution by users ([Elder, 2019](https://iastate.pressbooks.pub/oerstarterkit/chapter/introduction/)).

[^2]: See the Front Matter for more information.
