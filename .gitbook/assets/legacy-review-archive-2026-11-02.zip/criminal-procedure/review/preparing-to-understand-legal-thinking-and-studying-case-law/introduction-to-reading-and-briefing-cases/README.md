> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases) · Snapshot: 2026-11-02 · Original path: `preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/primers/reading-briefing/intro-reading-briefing)

---

# Introduction to Reading & Briefing Cases

### Contents

{% content-ref url="introduction-to-reading-and-briefing-cases/how-to-read-a-case" %}
[how-to-read-a-case](introduction-to-reading-and-briefing-cases/how-to-read-a-case)
{% endcontent-ref %}

{% content-ref url="introduction-to-reading-and-briefing-cases/case-briefing-tutorials" %}
[case-briefing-tutorials](introduction-to-reading-and-briefing-cases/case-briefing-tutorials)
{% endcontent-ref %}

{% content-ref url="introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs" %}
[annotated-cases-and-annotated-examples-of-case-briefs](introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs)
{% endcontent-ref %}

{% content-ref url="introduction-to-reading-and-briefing-cases/exercise-brief-the-case" %}
[exercise-brief-the-case](introduction-to-reading-and-briefing-cases/exercise-brief-the-case)
{% endcontent-ref %}
