> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law) · Snapshot: 2026-11-02 · Original path: `preparing-to-understand-legal-thinking-and-studying-case-law`

---

# Preparing to Understand Legal Thinking and Studying Case Law

Put simply, legal reasoning skills are inherently part of criminal justice, public service, and public policy professions. Legal reasoning skills improve the ability to (1) spot and distinguish between relevant and irrelevant facts and evidence in a particular set of circumstances, and (2) develop the ability to communicate thoughts and arguments clearly and persuasively. And while these skills are important for criminal justice and many other professionals, they are just as translatable and applicable to everyday life.

***

### Contents

{% content-ref url="preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis" %}
[primers-on-legal-thinking-reasoning-and-analysis](preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis)
{% endcontent-ref %}

{% content-ref url="preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases" %}
[introduction-to-reading-and-briefing-cases](preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases)
{% endcontent-ref %}
