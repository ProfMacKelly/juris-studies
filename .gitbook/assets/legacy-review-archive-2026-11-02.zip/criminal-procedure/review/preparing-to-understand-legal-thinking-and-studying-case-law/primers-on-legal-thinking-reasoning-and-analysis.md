> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis) · Snapshot: 2026-11-02 · Original path: `preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis`

---

# Primers on Legal Thinking, Reasoning & Analysis

### Contents

{% content-ref url="https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/introduction-to-deductive-rule-based-reasoning" %}
[introduction-to-deductive-rule-based-reasoning](https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/introduction-to-deductive-rule-based-reasoning)
{% endcontent-ref %}

{% content-ref url="https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/introduction-to-analogical-reasoning-a-type-of-inductive-reasoning" %}
[introduction-to-analogical-reasoning-a-type-of-inductive-reasoning](https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/introduction-to-analogical-reasoning-a-type-of-inductive-reasoning)
{% endcontent-ref %}

{% content-ref url="https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/is-a-hot-dog-a-sandwich" %}
[is-a-hot-dog-a-sandwich](https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/is-a-hot-dog-a-sandwich)
{% endcontent-ref %}

{% content-ref url="https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/avoid-bald-assertions" %}
[avoid-bald-assertions](https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/avoid-bald-assertions)
{% endcontent-ref %}
