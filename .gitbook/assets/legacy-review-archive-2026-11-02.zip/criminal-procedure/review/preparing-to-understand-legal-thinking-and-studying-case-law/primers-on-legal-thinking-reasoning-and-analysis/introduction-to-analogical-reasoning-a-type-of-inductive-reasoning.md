> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/introduction-to-analogical-reasoning-a-type-of-inductive-reasoning) · Snapshot: 2026-11-02 · Original path: `preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/introduction-to-analogical-reasoning-a-type-of-inductive-reasoning`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/primers/reasoning/analogical)

---

# Introduction to Analogical Reasoning—A Type of Inductive Reasoning

## Introduction to Inductive Reasoning in Legal Thinking

Another vital reasoning method necessary for someone to evaluate the legal significance of particular facts and circumstances is inductive reasoning. Although there are various types of inductive reasoning, the most common in legal analysis is **analogical reasoning** (also known as **case-based reasoning**), also known as _arguing from analogy_ _and from distinction_ (i.e., distinguishing between cases)_._ Arguments are made by finding similarities and differences between the given factual circumstances and **previous cases** (i.e., [precedent](https://www.law.cornell.edu/wex/precedent)).\*[^1] One explanation of analogical reasoning is that "an analogy is simply a comparison, and an argument from analogy is an argument from comparison."\*[^2] In the legal context, a basic argument from analogy would be something like this: "Case A—an earlier case—is similar to Case B—the case we are deciding now—so Case B should be decided in the same way that Case A was decided."

{% hint style="info" %}
Note: Arguments by analogy are never conclusive, but they can be a compellingly persuasive tool.\*[^3]
{% endhint %}

Another good explanation is this:

> The basic pattern of legal reasoning is reasoning by example. It is reasoning from case to case. It is a three-step process described by the **doctrine of precedent** in which a proposition \[premise] descriptive of the first case is made into a rule of law and then applied to a next similar situation. The steps are these: similarity is seen between cases; next the rule of law inherent in the first case is announced; then the rule is made applicable to the second case.\*[^4]

{% hint style="info" %}
In essence, the **doctrine of precedent** is another term for the doctrine of _stare decisis_, which generally requires courts to "apply the law in the same manner to cases with the same facts," although exceptions exist.\*[^5]&#x20;
{% endhint %}

Contrasted with arguing based on similar cases, arguing by distinction focuses on the differences between two cases that are significant enough to diminish the applicability of a particular precedent.\*[^6] Here is an example of an argument by distinction, and the failure of law enforcement officers to understand the distinction. The U.S. Supreme Court, on multiple occasions, has declared the following rules:

1. A person's reasonable expectation of privacy in their property is highest with their home. The expectation of privacy extends beyond the home's physical structure; it starts at the home's curtilage, which is an area surrounding the home that is commonly associated with family activities of daily living. A protected "zone" is called the "[zone of privacy](#user-content-fn-7)[^7]." In other words, this is the area in which a person's expectation of privacy is reasonable.
2. A person's zone of privacy regarding their car (specifically when the car is in public and mobile) is smaller than with their home. With a car, the zone of privacy starts at the physical boundary of the car itself.
3. Conducting investigative activity within the [zone of privacy](#user-content-fn-8)[^8] constitutes a search.
4. Probable cause is required to obtain a warrant, and a warrant is necessary to search within someone's zone of privacy, unless an exception to the warrant requirement applies.
5. Generally, conducting a dog sniff (for drugs) constitutes investigative activity.
6. Generally, conducting a dog sniff around the exterior of a car does not constitute a search that requires probable cause (as long as the car is legally stopped and does not unreasonably extend the length of the stop). Thus, subject to the nature of the stop, a dog sniff around the exterior of the car does not require a warrant.

In [_Florida v._ _Jardines_](#user-content-fn-9)[^9], along with a drug-sniffing dog, police walked up the suspect's front walkway and onto the porch of Joelis Jardine's home. This was based solely on an unverified anonymous tip. After sniffing around this area, the dog indicated the presence of drugs, police obtained a search warrant, and seized marijuana being grown in the house. Based on the premise that a dog sniff does not constitute a search, law enforcement assumed that it was justified.&#x20;

In part, the government supported the "dog sniff is not a search" argument by analogizing it to other Supreme Court decisions. _However_, those decisions involved facts wherein law enforcement did not conduct the dog sniff within the subject's zone of privacy. For instance, in [_U.S. v. Place_](https://scholar.google.com/scholar_case?case=5031844227599510007\&hl=en\&as_sdt=6,50), during a legal detention at an airport, a dog detected that drugs were inside the subject's luggage (without opening the subject's luggage). In [_Illinois v. Caballes_](https://scholar.google.com/scholar_case?case=10622335546539670066\&hl=en\&as_sdt=6,50), police conducted a dog sniff around the exterior of the subject's car. In both cases, the Court held that law enforce had not intruded into the zone of privacy.

_**But**_ in this case, the Court held that the _Place_ and _Caballes_ cases were not analogous. This case is distinct because the [investigative activity](#user-content-fn-10)[^10] occurred within the home's curtilage (i.e., within the zone of privacy); thus, the activity constituted a search. Without an exception to the warrant requirement, the activity was unconstitutional.

Another distinction between the _Jardines_ case and previous cases is that an officer merely approaching the front door in the manner homeowners would reasonably expect of strangers and mail/package couriers does not constitute a search. _**But**_ here, bringing the dog to conduct investigatory activity that a typical homeowner would otherwise find intrusive became unreasonably invasive of the homeowner's privacy interests. Therefore, because the circumstances were different enough to change the "variables" in the zone of privacy analysis, _Place_ and _Caballes_ could not apply.

As you can see, the facts of _Jardines_ included circumstances that were analogous to precedent (dog sniffs), but the distinctions from those cases (the location of the investigative activity with respect to the zone of privacy) outweighed the fact that all these cases involved dog sniffs. This is the crux of how the analogical reasoning process works.

***

<details>

<summary>License</summary>

This page © 2025 by Mathew L. Mac Kelly is licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/?ref=chooser-v1), except where otherwise noted. <img src="https://2693790834-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F6Bqz3QmhzbBYM9Y3OuYd%2Fuploads%2FlL5l9osHpBZhsUFGEOLC%2Fimage.png?alt=media&#x26;token=7c0c7504-00cb-4eb7-889e-4196d971b97e" alt="" data-size="line"><br>

</details>

[^1]: See Peter N. Swisher, _Teaching Legal Reasoning in Law School_. [7 L. LIB. J. 534](https://scholarship.richmond.edu/law-faculty-publications/10/), 537 (1981).

[^2]: Peter N. Swisher. _Teaching Legal Reasoning in Law School_. [7 L. LIB. J. 534](https://scholarship.richmond.edu/law-faculty-publications/10/), 537 (1981) (quoting[ J. Hospers, _An Introduction to Philosophical Analysis,_ 476](https://archive.org/details/introductiontoph0000hosp_a6r3/page/476/) (1967/1970).

[^3]: Swisher. _Teaching Legal Reasoning in Law School_. [7 L. LIB. J. 534](https://scholarship.richmond.edu/law-faculty-publications/10/), 537 (1981); Ruggero J. Aldisert, Stephen Clowney, & Jeremy D. Peterson, _Logic for Law Students: How to Think Like a Lawyer_. [69 U. PITT. L. REV. 1](https://doi.org/10.5195/lawreview.2007.117), 13 (2007).

[^4]: Swisher, above, at 537 (quoting E. Levi, , _An Introduction to Legal Reasoning,_ 1-2, n. 11 (1949) (emphasis added)).

[^5]: [Wex Legal Encyclopedia](https://www.law.cornell.edu/wex/precedent)

[^6]: Swisher, above, at 537-538.

[^7]: _See Payton v. New York_, [445 U.S. 573, 589-590](https://scholar.google.com/scholar_case?case=14936388408511643149\&q=%22fourth+amendment%22+%2B+%22search%22+%2B+%22zone+of+privacy%22\&hl=en\&as_sdt=3,50#p589) (1980); _United States v. Miller_, [425 U.S. 435, 440](https://scholar.google.com/scholar_case?case=15052729295643479698\&q=%22fourth+amendment%22+%2B+%22search%22+%2B+%22zone+of+privacy%22\&hl=en\&as_sdt=3,50#p440) (1976); _Rakas v. Illinois_, [439 U.S. 128, 160-161](https://scholar.google.com/scholar_case?case=5960557864369784818\&q=%22fourth+amendment%22+%2B+%22search%22+%2B+%22zone+of+privacy%22\&hl=en\&as_sdt=3,50#p160) (1978);&#x20;

[^8]: (i.e., the areas where someone's expectation of privacy is reasonable)

[^9]: [569 U.S. 1](https://scholar.google.com/scholar_case?case=11257938519868562913\&hl=en\&as_sdt=6,50) (2013).

[^10]: 
