> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/front-matter) · Snapshot: 2026-11-02 · Original path: `front-matter`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-procedure/front-matter) · [Candidate 2](https://profmackelly.gitbook.io/learn/sourcebooks/cj-liability/front-matter) · [Candidate 3](https://profmackelly.gitbook.io/learn/sourcebooks/business-law-i/front-matter)

---

# Front Matter

## About This Book

### What Is This Book?

_Criminal Procedure Sourcebook_ is an interactive [open educational resource](#user-content-fn-1)[^1] (OER). Open textbooks are complete textbooks that have been funded, published, and licensed to be freely used, adapted, and distributed. As an open resource, this may be used and reused freely with no direct cost to the user.

Except where otherwise noted, the content in this book is licensed with [Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)](https://creativecommons.org/licenses/by-nc-sa/4.0/), which allows it to be adapted, remixed, and shared under the same license with attribution. Instructors and students may be interested in rearranging and otherwise adapting or transforming the content into other formats. If so, please include the appropriate attribution under the Creative Commons license. More information about this license is available [here](https://creativecommons.org/licenses/by-nc-sa/4.0/).

Although it is openly licensed free to be reused and redistributed, readers should note that the contents are tailored to serve undergraduate students enrolled in JPP 3010 at Concordia University Wisconsin. This sourcebook includes both content that (a) I authored, (b) I [adapted or remixed](https://help.oercommons.org/support/solutions/articles/42000046860-remix-a-resource), and/or (c) incorporated from other creators in compliance with copyright and licensing regulations and practices. \~ _Matt Mac Kelly, JD, EdD_

### Authorship, Adaptations, and Licensing Information

_Criminal Procedure Sourcebook_ includes content (a) created by Matthew L. Mac Kelly and (b) [edited, mixed, or otherwise adapted](https://rmit.pressbooks.pub/oercapabilitytoolkit/chapter/4-1-adapting-and-remixing-oer/) by Matthew L. Mac Kelly from other creators' works in compliance with copyright and licensing laws and appropriate attribution standards and practices. The use of any other content referenced in or integrated into this book complies with copyright and licensing laws and appropriate attribution standards and practices.

{% hint style="success" %}
:clap:Special thanks to:

* [Anne M Alexander](https://law.missouri.edu/directory/anne-alexander/) and [Ben Trachtenberg](https://law.missouri.edu/directory/ben-trachtenberg/) for [_Criminal Procedure: A Free Law School Casebook 2e_](https://biz.libretexts.org/Bookshelves/Criminal_Law/Criminal_Procedure%3A_A_Free_Law_School_Casebook_2e_\(Alexander_and_Trachtenberg\))_._
* [Christopher E. Smith](http://www.chrissmithjdphd.com/), [Anne M Alexander](https://law.missouri.edu/directory/anne-alexander/), and [Ben Trachtenberg](https://law.missouri.edu/directory/ben-trachtenberg/) for [_Criminal Procedure - Undergraduate Edition_](https://workforce.libretexts.org/Workbench/Criminal_Procedure_-_Undergraduate_Edition_\(Smith\)).
* [Larry Alvarez](https://www.canyons.edu/directory/larry-alvarez.php) for [_Principles and Procedures of the Justice System_](https://workforce.libretexts.org/Bookshelves/Corrections/Principles_and_Procedures_of_the_Justice_System_\(Alvarez\))_._

Substantial portions of their work have been edited, mixed, or otherwise adapted and incorporated into this book within the terms of their works' licenses.
{% endhint %}

### **Judicial Opinions**

Except as otherwise noted, [judicial opinions](#user-content-fn-2)[^2] used in this work have been edited by Matthew L. Mac Kelly. Editing and elisions of text are for length, readability, and clarity purposes. Some elisions of an opinion's original text are identified by bracketed ellipses (e.g., \[...]). Edited judicial opinions in this work are in the public domain. As government documents, judicial opinions and annotations thereto are not subject to copyright protection and are in the public domain. _See Georgia v. Public.Resource.Org, Inc_., [140 S.Ct. 1498](https://scholar.google.com/scholar_case?case=8288711378870515248\&q=Georgia+et+al.+v.+Public.Resource.Org,+Inc.\&hl=en\&as_sdt=6,50) (2020).

## How to Use This Book

### Table of Contents

Use the table of contents, usually located on the left side panel, to browse through units, chapters, and/or sections.&#x20;

### Reading Content

Click on any unit, chapter, and/or section to view its content. Scroll down to read the entire page.

{% hint style="info" %}
<mark style="color:red;">**Pages with multiple headings/subsections have their own table of contents on the right side of the page.**</mark> (For example, see the right side of this screen.) The table on the right might not appear on smaller screens, such as phones and small tablets.
{% endhint %}

### Interactive Elements

Engage with any interactive elements such as links, annotations, [expandable widgets,](#user-content-fn-3)[^3] videos, and other embedded content that may be included in the sourcebook. This can help you better understand the content, and you can receive additional insights. Make sure to spend adequate time on these interactive features to fully benefit from the sourcebook.

<details>

<summary><mark style="color:red;"><strong>How Annotations Work in This Sourcebook</strong></mark></summary>

The sourcebook's text includes many annotations, which are indicated by text with a dotted underline like this: [This text is annotated.](#user-content-fn-4)[^4] To read the annotation, hover (mouse) over the underlined text. A bubble will appear and display the annotation. (If the bubble does not appear when hovering, then click/tap it.)  These annotations provide additional context and information while also decluttering the main reading area.&#x20;

Also, many references and citations to original source content are located in these annotations, instead of traditional footnotes or endnotes.

</details>

### **Search Functionality**

**Search and Quick Find**

To find specific topics or keywords within the sourcebook, use the **Search** bar, usually located in the top-right corner of each page.

{% hint style="info" %}
<mark style="color:red;">**Click the link to learn more about using GitBook's**</mark> [<mark style="color:blue;">**Search & Quick find**</mark>**&#x20;**<mark style="color:red;">**tool**</mark>](https://docs.gitbook.com/content-editor/searching-your-content/quick-find)<mark style="color:red;">.</mark>&#x20;
{% endhint %}

### Day/Night Mode

At the bottom of the page, usually in the lower-right side, you may toggle between day and night displays, depending on your viewing preferences.

<figure><img src="https://2693790834-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F6Bqz3QmhzbBYM9Y3OuYd%2Fuploads%2FmfFwzWbp8pDtxu7Kw7Pw%2Fday-night.jpeg?alt=media&#x26;token=73061f58-8bb7-4762-91f3-d35fa9196dc6" alt=""><figcaption><p>Toggle screen display between day and night</p></figcaption></figure>

## Legal Notice

{% hint style="danger" %}
_**This book contains legal information intended for educational purposes only and should not be construed as legal advice; please consult a qualified legal professional before making legal decisions.**_
{% endhint %}

***

<details>

<summary>License</summary>

This page is marked with [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/?ref=chooser-v1). No copyright or license is claimed for the content on this page other than those claimed and reserved by [GitBook](https://www.gitbook.com/?utm_source=content\&utm_medium=trademark\&utm_campaign=NkEGS7hzeqa35sMXQZ4X).&#x20;

</details>

[^1]: Free educational material that is openly licensed to enable reuse and redistribution by users ([Elder, 2019](https://iastate.pressbooks.pub/oerstarterkit/chapter/introduction/)).

[^2]: Written statements that explain a court’s [decision](https://www.law.cornell.edu/wex/decision) in a [case](https://www.law.cornell.edu/wex/case) ([Wex Legal Dictionary and Encyclopedia](https://www.law.cornell.edu/wex/opinion)).

[^3]: Such as this: [**How Annotations Work in This Sourcebook**](#how-annotations-work-in-this-sourcebook), below. Click the carrot (**>**) on the left side of the widget to expand and reveal its contents.

[^4]: This is the annotation.
