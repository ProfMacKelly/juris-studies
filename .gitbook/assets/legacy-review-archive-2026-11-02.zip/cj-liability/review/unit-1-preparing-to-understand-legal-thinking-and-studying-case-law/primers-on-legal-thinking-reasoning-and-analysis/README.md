> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Justice Liability Law: A Sourcebook](https://profmackelly.gitbook.io/cj-liability/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis) · Snapshot: 2026-11-02 · Original path: `preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis`

---

# Primers on Legal Thinking, Reasoning & Analysis



{% stepper %}
{% step %}
{% content-ref url="primers-on-legal-thinking-reasoning-and-analysis/introduction-to-deductive-rule-based-reasoning" %}
[introduction-to-deductive-rule-based-reasoning](primers-on-legal-thinking-reasoning-and-analysis/introduction-to-deductive-rule-based-reasoning)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="primers-on-legal-thinking-reasoning-and-analysis/introduction-to-analogical-reasoning-a-type-of-inductive-reasoning" %}
[introduction-to-analogical-reasoning-a-type-of-inductive-reasoning](primers-on-legal-thinking-reasoning-and-analysis/introduction-to-analogical-reasoning-a-type-of-inductive-reasoning)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="primers-on-legal-thinking-reasoning-and-analysis/is-a-hot-dog-a-sandwich" %}
[is-a-hot-dog-a-sandwich](primers-on-legal-thinking-reasoning-and-analysis/is-a-hot-dog-a-sandwich)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="primers-on-legal-thinking-reasoning-and-analysis/avoid-bald-assertions" %}
[avoid-bald-assertions](primers-on-legal-thinking-reasoning-and-analysis/avoid-bald-assertions)
{% endcontent-ref %}
{% endstep %}
{% endstepper %}
