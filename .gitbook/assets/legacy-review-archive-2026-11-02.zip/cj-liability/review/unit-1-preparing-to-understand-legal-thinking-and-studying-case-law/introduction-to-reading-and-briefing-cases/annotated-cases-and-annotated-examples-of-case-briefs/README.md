> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Justice Liability Law: A Sourcebook](https://profmackelly.gitbook.io/cj-liability/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs) · Snapshot: 2026-11-02 · Original path: `preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/primers/reading-briefing/annotated-cases-briefs)

---

# Annotated Cases & Annotated Examples of Case Briefs

In this section:

* Read and compare three cases with the example case briefs, and&#x20;
* Examine the explanatory/instructional annotations provided within the example case briefs.

Here are the three examples:

<table data-view="cards"><thead><tr><th></th><th></th><th></th><th data-hidden data-card-target data-type="content-ref"></th></tr></thead><tbody><tr><td>Example 1: <a href="annotated-cases-and-annotated-examples-of-case-briefs/example-1-florida-v.-jardines"><em><mark style="color:blue;"><strong>Florida v. Jardines</strong></mark></em></a></td><td></td><td></td><td><a href="broken-reference">Broken link</a></td></tr><tr><td>Example 2: <a href="annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park"><em><mark style="color:blue;"><strong>Mills v. City of Overland Park</strong></mark></em></a></td><td></td><td></td><td><a href="annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park">example-2-mills-v.-city-of-overland-park</a></td></tr><tr><td>Example 3: <a href="annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs"><em><mark style="color:blue;"><strong>Malley v. Briggs</strong></mark></em></a></td><td></td><td></td><td></td></tr></tbody></table>
