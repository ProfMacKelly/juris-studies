> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Justice Liability Law: A Sourcebook](https://profmackelly.gitbook.io/cj-liability/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/how-to-read-a-case) · Snapshot: 2026-11-02 · Original path: `preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/how-to-read-a-case`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/primers/reading-briefing/how-to-read-a-case)

---

# How to Read a Case

Reading and watching all the content below is highly recommended, even though multiple readings and videos are about the same topic. People have differing approaches and strategies, and some may connect with you more than others.

## Articles

* [_How to Read a Case_](https://files.gitbook.com/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FIidgz8oVybO8YdnFwIF5%2Fuploads%2FziqT9lu99WcGTUNAuC6A%2Fhow-to-read-a-case.pdf?alt=media\&token=b6af12bd-5a6a-4dce-8509-db06700afb4b) by Julie Novkov\*[^1]
* [_How to Read a Legal Opinion_](https://www.law.berkeley.edu/wp-content/uploads/2015/07/How-to-Read-A-Legal-Opinion.pdf) by Orin S. Kerr

## Videos

{% embed url="https://www.youtube.com/watch?t=90s&v=etnZUvE-MJk" %}

{% embed url="https://youtu.be/9wEwonPBC18?list=PLLxxzZq76ixxzh8blnZdQBUj5NVg8oB_9" %}



[^1]: Also downloadable from [The Wayback Machine](http://www.lawprofessor.org/resources/pdf/how-to-read-a-case.pdf).
