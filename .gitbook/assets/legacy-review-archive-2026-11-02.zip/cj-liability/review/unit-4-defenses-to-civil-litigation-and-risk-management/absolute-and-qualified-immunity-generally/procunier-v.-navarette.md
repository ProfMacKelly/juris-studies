> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Justice Liability Law: A Sourcebook](https://profmackelly.gitbook.io/cj-liability/defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/procunier-v.-navarette) · Snapshot: 2026-11-02 · Original path: `defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/procunier-v.-navarette`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/cj-liability/unit-4-defenses-to-civil-litigation-and-risk-management/good-faith-defense/procunier-v.-navarette)

---

# Procunier v. Navarette

\[Note: Edited from the [<mark style="color:blue;">original</mark>](https://cite.case.law/us/434/555/).]

***

434 U.S. 555 (1978)

Supreme Court of the United States

**Procunier, Corrections Director, et al.**\
**v.**\
**Navarette**

Mr. Justice White delivered the opinion of the Court.

Respondent Navarette, an inmate of Soledad Prison in California when the events revealed here occurred, filed his second amended complaint on January 19, 1974, charging six prison officials with various types of conduct allegedly violative of his constitutional rights and of 42 U.. S. C. §§ 1983 and 1985.[1](https://cite.case.law/us/434/555/#footnote_1_1) Three of the defendants were subordinate officials at Soledad;[2](https://cite.case.law/us/434/555/#footnote_1_2) three were supervisory officials: the director of the State Department of Corrections and the warden and assistant warden of Soledad. The first three of nine claims for relief alleged wrongful interference with Navarette's outgoing mail. The first claim charged that the three subordinate officers, who were in charge of mail handling, had failed to mail various items of correspondence during the 15 months that respondent was incarcerated at Soledad, from September 1, 1971, to December 11, 1972. These items, described in 13 numbered paragraphs, included letters to legal assistance groups, law students, the news media, and inmates in other state prisons, as well as personal friends. Some of these items had been returned to Navarette, some the defendants had refused to send by registered mail as Navarette had requested, and, it was alleged, none of the items had ever reached the intended recipient. This “interference” or “confiscation” was asserted to have been in “knowing disregard” of the applicable statewide prisoner mail regulations[3](https://cite.case.law/us/434/555/#footnote_1_3) and of Navarette's “constitutional rights,” including his rights to free speech and due process as guaranteed by the First, Fifth, and Fourteenth Amendments to the United States Constitution. The three supervisory officers were alleged to have knowingly condoned this conduct and to have conspired with their subordinates for forbidden ends.

The second claim for relief alleged wrongful failure to mail the same items of correspondence and asserted that the “interference or confiscation” had been conducted with “bad faith disregard” for Navarette’s rights. The third claim posed the same failures to mail but claimed that the “interference” or “confiscation” had occurred because the three subordinate officers had “negligently and inadvertently” misapplied the prison mail regulations and because the supervisory officers had “negligently]” failed to provide sufficient training and direction to their subordinates, all assertedly in violation of Navarette’s constitutional rights.

\[The District Court] granted summary judgment for petitioners on the first three claims and dismissed the remaining claims for failure to state a federal claim.[4](https://cite.case.law/us/434/555/#footnote_1_4) The Court of Appeals reversed as to the first three claims. \[...]

We granted certiorari, and the question before us is whether the Court of Appeals correctly reversed the District Court’s judgment with respect to Navarette’s ... claim for relief alleging negligent interference with a claimed constitutional right.[6](https://cite.case.law/us/434/555/#footnote_1_6)

\[In the District Court], petitioners argued that on the record before the court they were immune from liability for damages under § 1983 and hence were entitled to judgment as a matter of law. The claim was not that they shared the absolute immunity accorded judges and prosecutors but that they were entitled to \[qualified immunity]. \[...] The Court of Appeals appeared to agree that petitioners were entitled to the claimed degree of immunity but held that they were nevertheless not entitled to ... judgment because in the court’s view there were issues of fact to be resolved \[at trial].

Although the Court has recognized that in enacting § 1983 Congress must have intended to expose state officials to damages liability in some circumstances, the section has been consistently construed as not intending wholesale revocation of the common-law immunity afforded government officials. Legislators, judges, and prosecutors have been held absolutely immune from liability for damages under § 1983. \[...] Only a qualified immunity from damages is available to a state Governor, a president of a state university, and officers and members of a state National Guard. \[...] The same is true of local school board members, ... of the superintendent of a state hospital, ... and of policemen. \[...]

We agree with petitioners that as prison officials and officers, they were not absolutely immune from liability in this § 1983 damages suit and could rely only on the qualified immunity described in _Scheuer_ v. _Rhodes,_ \[which stated]:

> “\[I]n varying scope, a qualified immunity is available to officers of the executive branch of government, the variation being dependent upon the scope of discretion and responsibilities of the office and all the circumstances as they reasonably appeared at the time of the action on which liability is sought to be based. It is the existence of reasonable grounds for the belief formed at the time and in light of all the circumstances, coupled with good-faith belief, that affords a basis for qualified immunity of executive officers for acts performed in the course of official conduct.” [416 U.S., at 247-248](https://cite.case.law/us/416/232/).

We further held in _Wood_ v. _Strickland,_ that “if the work of the schools is to go forward,” there must be a degree of immunity so that “public school officials understand that action taken in the good-faith fulfillment of their responsibilities and within the bounds of reason under all the circumstances will not be punished and that they need not exercise their discretion with undue timidity.” [420 U.S., at 321](https://cite.case.law/us/420/308/). This degree of immunity would be unavailable, however, if the official “knew or reasonably should have known that the action he took within his sphere of official responsibility would violate the constitutional rights of the student affected, or if he took the action with the malicious intention to cause a deprivation of constitutional rights or other injury to the student.” [_Id.,_ ](https://cite.case.law/us/420/308/)[at 322](https://cite.case.law/us/420/308/). The official cannot be expected to predict the future course of constitutional law, ... but he will not be shielded from liability if he acts “with such disregard of the \[plaintiff's] clearly established constitutional rights that his action cannot reasonably be characterized as being in good faith.” [420 U.S., at 322](https://cite.case.law/us/420/308/).

Under the first part of the _Wood_ v. _Strickland_ rule, the immunity defense would be unavailing to petitioners if the constitutional right allegedly infringed by them was clearly established at the time of their challenged conduct, if they knew or should have known of that right, and if they knew or should have known that their conduct violated the constitutional norm. Petitioners claim that in 1971 and 1972 when the conduct involved in this case took place there was no established First Amendment right protecting the mailing privileges of state prisoners and that hence there was no such federal right about which they should have known. We are in essential agreement with petitioners in this respect and also agree that they were entitled to judgment as a matter of law.

\[...]&#x20;

Whether the state of the law is evaluated by reference to the opinions of this Court, of the Courts of Appeals, or of the local District Court, there was no “clearly established” First and Fourteenth Amendment right with respect to the correspondence of convicted prisoners in 1971-1972.[12](https://cite.case.law/us/434/555/#footnote_1_12) As a matter of law, therefore, there was no basis for rejecting the immunity defense on the ground that petitioners knew or should have known that their alleged conduct violated a constitutional right. Because they could not reasonably have been expected to be aware of a constitutional right that had not yet been declared, petitioners did not act with such disregard for the established law that their conduct “cannot reasonably be characterized as being in good faith.” _Wood_ v. _Strickland,_ [420 U.S., at 322](https://cite.case.law/us/420/308/).[13](https://cite.case.law/us/434/555/#footnote_1_13)

Neither should petitioners’ immunity defense be overruled under the second branch of the _Wood_ v. _Strickland_ standard, which would authorize liability where the official has acted with “malicious intention” to deprive the plaintiff of a constitutional right or to cause him “other injury.” This part of the rule speaks of “intentional injury,” contemplating that the actor intends the consequences of his conduct. \[...] The third claim for relief with which we are concerned here, however, charges negligent conduct, which normally implies that although the actor has subjected the plaintiff to unreasonable risk, he did not intend the harm or injury that in fact resulted. \[...] Claims 1 _and_ 2 of the complaint alleged intentional and bad-faith conduct in disregard of Navarette’s constitutional rights; but claim 3, as the court below understood it and as the parties have treated it, was limited to negligence. The prison officers were charged with negligent and inadvertent interference with the mail and the supervisory personnel with negligent failure to provide proper training. To the extent that a malicious intent to harm is a ground for denying immunity, that consideration is clearly not implicated by the negligence claim now before us.[14](https://cite.case.law/us/434/555/#footnote_1_14)

We accordingly conclude that the District Court was correct in entering ... judgment for petitioners on the third claim of relief and that the Court of Appeals erred .... The judgment of the Court of Appeals is

_Reversed._

**Footnotes**

[1](https://cite.case.law/us/434/555/#ref_footnote_1_1)

Section 1983 provides:

“Every person who, under color of any statute, ordinance, regulation, custom, or usage, of any State or Territory, subjects, or causes to be subjected, any citizen of the United States or other person within the jurisdiction thereof to the deprivation of any rights, privileges, or immunities secured by the Constitution and laws, shall be liable to the party injured in an action at law, suit in equity, or other proper proceeding for redress.”

Section 1985 proscribes certain conspiracies interfering with civil rights.

[2](https://cite.case.law/us/434/555/#ref_footnote_1_2)

The named subordinate officials were two correctional counselors at Soledad and a member of the prison staff in charge of handling incoming and outgoing prisoner mail. The complaint also referred to unnamed defendants Does I through IV.

[3](https://cite.case.law/us/434/555/#ref_footnote_1_3)

Regulations promulgated January 5, 1970, permitted each inmate to send letters to 10 persons on an approved correspondence list plus other special-purpose letters as authorized. Director’s Rule (“D.”) 2403. Except with permission of the institutional head, correspondence with other inmates was prohibited. D.2402 (13). The inmate was also advised:

“You may not send or receive letters that pertain to criminal activity; are lewd, obscene, or defamatory; contain prison gossip or discussion of other inmates; or are otherwise inappropriate.” D. 2402 (8).

The regulations assured confidentiality for correspondence with state and federal officials and also stated:

“Nothing in these rules shall deprive you of correspondence with your attorney, or with the courts having jurisdiction over matters of legitimate concern to you.” D.2402 (10).

These regulations controlled prisoner correspondence until August 10, 1972, and were in effect at the time that all but one of respondent’s letters were posted. Subsequent regulations expanded inmate correspondence rights.

[4](https://cite.case.law/us/434/555/#ref_footnote_1_4)

Claims 4, 5, and 6 concerned the termination of a law student visitation program in which respondent had participated and the removal of respondent from the post of prison librarian. Claims 7, 8, and 9 realleged the substance of claims 1 through 6 and sought to hold the supervisory officials hable upon a theory of vicarious rather than personal liability. All nine claims also claimed a conspiracy in violation of [42 U. S. C. § 1985](https://cite.case.law/citations/?q=42%20U.S.C.%20%C2%A7%201985).

[5](https://cite.case.law/us/434/555/#ref_footnote_1_5)

The Court of Appeals also reversed the ruling of the District Court with respect to the 4th, 5th, and 6th claims on the theory that “\[t]he termination or denial of prison privileges because of a prisoner’s legal activities on his own behalf or those of other inmates is an impermissible interference with his or her constitutional right of access to the courts.” [536 F. 2d, at 280](https://cite.case.law/f2d/536/277/). Since this issue is not related to the question on which we granted certiorari, we express no view on the resolution of these claims by the court below.

The Court of Appeals affirmed the District Court’s dismissal of the claims based on vicarious liability (claims 7, 8, and 9) and also affirmed its dismissal of all claims predicated on [42 U. S. C. § 1985](https://cite.case.law/citations/?q=42%20U.S.C.%20%C2%A7%201985). [536 F. 2d, at 282](https://cite.case.law/f2d/536/277/). Neither of these issues is raised here.

[6](https://cite.case.law/us/434/555/#ref_footnote_1_6)

The questions presented in the petition for certiorari were:

“1. Whether negligent failure to mail certain of a prisoner’s outgoing letters states a cause of action under section 1983 ?

_“2._ Whether removal of a prisoner as a prison law librarian and termination of a law student-inmate visitation program in which he participated states a cause of action under the Civil Rights Act for either [\*560](https://cite.case.law/us/434/555/#p560)knowingly or negligently interfering with the prisoner’s right of access to the courts?

“3. Whether deliberate refusal to mail certain of a prisoner’s correspondence in 1971-1972 prior to _Procunier_ v. _Martinez,_ [416 U. S. 396](https://cite.case.law/us/416/396/) (1974), and refusal to send certain correspondence by registered mail states a cause of action for violation of his First Amendment right to free expression?”

Our order granting the petition was limited to Question No. 1. In their submissions on the merits, the parties deal with this issue as subsuming the questions whether at the time of the occurrence of the relevant events the Federal Constitution had been construed to protect Navarette’s mailing privileges and whether petitioners knew or should have known that their alleged conduct violated Navarette’s constitutional rights. Since consideration of these issues is essential to analysis of the Court of Appeals’ reversal of summary judgment on claim 3 of the complaint, we shall also treat these questions as subsidiary issues “fairly comprised” by the question presented. This Court’s Rule 23.1 (c). In any event, our power to decide is not limited by the precise terms of the question presented. _Blonder-Tongue Laboratories, Inc._ v. _University Foundation,_ [402 U. S. 313](https://cite.case.law/us/402/313/), 320 n. 6 (1971).

[7](https://cite.case.law/us/434/555/#ref_footnote_1_7)

The Courts of Appeals have generally accorded prison and jail administrators performing discretionary functions a qualified immunity from monetary liability under § 1983. _E. g., Knell_ v. _Bensinger,_ [522 F. 2d 720](https://cite.case.law/f2d/522/720/) (CA7 1975); _Hoitt_ v. _Vitek,_ [497 F. 2d 598](https://cite.case.law/f2d/497/598/#p601), 601 (CA1 1974); _Dewell_ v. _Lawson,_ [489 F. 2d 877](https://cite.case.law/f2d/489/877/) (CA10 1974); _Anderson_ v. _Nosser,_ [438 F. 2d 183](https://cite.case.law/f2d/438/183/) (CA5 1971), modified on rehearing, [456 F. 2d 835](https://cite.case.law/f2d/456/835/) (1972); see _Bryan_ v. _Jones,_ [530 F. 2d 1210](https://cite.case.law/f2d/530/1210/) (CA5), cert. denied, [429 U. S. 865](https://cite.case.law/us/429/865/) (1976).

[8](https://cite.case.law/us/434/555/#ref_footnote_1_8)

416 U. S., at 406, citing _McCloskey_ v. _Maryland,_ [337 F. 2d 72](https://cite.case.law/f2d/337/72/) (CA4 1964); Lee v. _Tahash,_ [352 F. 2d 970](https://cite.case.law/f2d/352/970/) (CA8 1965); _Knupnick_ v. _Crouse,_ [366 F. 2d 851](https://cite.case.law/f2d/366/851/) (CA10 1966); _Pope_ v. _Daggett,_ [350 F. 2d 296](https://cite.case.law/f2d/350/296/) (CA10 1965).

[9](https://cite.case.law/us/434/555/#ref_footnote_1_9)

416 U. S., at 406-407, citing, _inter alia, Sostre_ v. _McGinnis,_ [442 F. 2d 178](https://cite.case.law/f2d/442/178/#p199), 199 (CA2 1971) (censorship of personal correspondence must have support “in any rational and constitutionally acceptable concept of a prison system”); _Jackson_ v. _Godwin,_ [400 F. 2d 529](https://cite.case.law/f2d/400/529/) (CA5 1968) (censorship of prisoner mail must be supported by a compelling state interest); _Wilkinson_ v. _Skinner,_ [462 F. 2d 670](https://cite.case.law/f2d/462/670/#p672), 672-673 (CA2 1972) (requiring a “clear and present danger”).

[10](https://cite.case.law/us/434/555/#ref_footnote_1_10)

The jurisdictional statement filed by Procunier stated that “the vast majority of reported cases held that restrictions on the extent and character of prisoners’ correspondence and examination and censorship thereof are inherent incidents in the conduct of penal institutions,” but noted that in the federal courts there were “widely diverging views regarding the scope and propriety of federal intervention in matters of internal prison regulation,” particularly with respect to inmate mail. Jurisdictional Statement filed in _Procunier_ v. _Martinez,_ O. T. 1973, No. 72-1465, p. 9.

[11](https://cite.case.law/us/434/555/#ref_footnote_1_11)

In _Hyland_ v. _Procunier,_ the District Court enjoined correctional officials from requiring a parolee to obtain advance permission for speeches to public gatherings. The opinion did not discuss the rights of prisoners. _Gilmore_ v. _Lynch_ concerned regulations limiting prisoner access to. legal materials and mutual legal assistance. The decision rested on the prisoners’ right to reasonable access to the courts. _Northern_ v. _Nelson_ upheld an inmate’s right to receive a newspaper which was “necessary for effective exercise of plaintiff’s right to practice the Muslim religion.” [315 F. Supp., at 688](https://cite.case.law/f-supp/315/687/). _Payne_ v. _Whitmore_ affirmed the inmates’ First Amendment right to receive newspapers and magazines. The theory of the decision was that “prison rules must bear a reasonable relationship to valid prison goals, and rules which infringe upon particularly important rights will require a proportionately stronger justification.” [325 F. Supp., at 1193](https://cite.case.law/f-supp/325/1191/). It contained no discussion concerning either the importance of prisoner correspondence [\*565](https://cite.case.law/us/434/555/#p565)rights or the type of correspondence rules which would be reasonable. Toward the end of the relevant period, in May 1972, _Brenneman_ v. _Madigan_ held that pretrial detainees had a First Amendment right in their correspondence. The court recognized, however, that “\[p] re-trial detainees do not stand on the same footing as convicted inmates.” [343 F. Supp., at 142](https://cite.case.law/f-supp/343/128/).

[12](https://cite.case.law/us/434/555/#ref_footnote_1_12)

Although some of the items of correspondence with which respondent claims interference concerned legal matters or were addressed to lawyers, respondent is foreclosed from asserting any claim with respect to mail interference based on infringement of his right of access to the courts because such a claim was dismissed with prejudice in an earlier phase of this case. Order of Feb. 9, 1973, No. C-72-1954 SW (ND Cal.). In his Points and Authorities Against Motion to Dismiss filed in connection with the present complaint on April 17, 1974, respondent stated that “\[t]he claim against mail interference does not purport to allege denial of access to the courts,” and explained that “\[i]n ruling on defendants’ previous Motion to Dismiss, in February, 1973, this Court dismissed plaintiff’s claim against mail interference insofar as it alleged denial of access to the courts.” Record 171.

[13](https://cite.case.law/us/434/555/#ref_footnote_1_13)

There is thus no occasion to address this case on the assumption that Navarette’s mailing privileges were protected by a constitutional rule of which petitioners could reasonably have been expected to be aware in 1971 and 1972 and to inquire whether petitioners knew or should have known that their conduct was in violation of that constitutional proscription.

[14](https://cite.case.law/us/434/555/#ref_footnote_1_14)

Because of the disposition of this case on immunity grounds, we do not address petitioners’ other submissions: that § 1983 does not afford a remedy for negligent deprivation of constitutional rights and that state prisoners have no First and Fourteenth Amendment rights in their outgoing mail.
