> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Justice Liability Law: A Sourcebook](https://profmackelly.gitbook.io/cj-liability/defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/cleavinger-v.-saxner) · Snapshot: 2026-11-02 · Original path: `defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/cleavinger-v.-saxner`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/cj-liability/unit-4-defenses-to-civil-litigation-and-risk-management/immunity-absolute-and-qualified/cleavinger-v.-saxner)

---

# Cleavinger v. Saxner

\[Note: Edited from the [<mark style="color:blue;">original</mark>](https://www.courtlistener.com/opinion/111547/cleavinger-v-saxner/).]

***

474 U.S. 193 (1985)

Supreme Court of United States

**Cleavinger et al.**\
**v.**\
**Saxner et al.**

Justice Blackmun delivered the opinion of the Court.

This case presents the issue whether members of a federal prison’s Institution Discipline Committee, who hear cases in which inmates are charged with rules infractions, are entitled to absolute, as distinguished from qualified, immunity from personal damages liability for actions violative of the United States Constitution.

**I**

\[Respondent federal prison inmates were found guilty by the prison's Discipline Committee, composed of petitioner prison officials, of encouraging other inmates to engage in a work stoppage and of other charges, and were ordered to be placed in administrative detention and to forfeit a specified number of days of "good time." On appeals to the Warden and the Regional Director of the Bureau of Prisons, respondents were ordered released from administrative detention and all material relevant to the incident in question was ordered expunged from their records. They were later paroled and released. But in the meantime, they brought suit in Federal District Court against petitioners, alleging a violation of various federal constitutional rights and seeking declaratory and injunctive relief and damages. After initially dismissing the complaint on the ground that petitioners were entitled to absolute immunity from liability, the District Court, on reconsideration, reinstated the suit. The case was tried to a jury, which found that petitioners had violated respondents' Fifth Amendment due process rights, and awarded damages. The Court of Appeals affirmed, rejecting petitioners' claim for absolute immunity.]

**II**

**A.**&#x20;

This Court has observed: Few doctrines were more solidly established at common law than the immunity of judges from liability for damages for acts committed within their judicial jurisdiction.” _Pierson_ v. _Ray,_ [386 U. S. 547](https://cite.case.law/us/386/547/#p553), 553-554 (1967). The Court specifically has pronounced and followed this doctrine of the common law for more than a century. In _Bradley_ v. _Fisher,_ [13 Wall. 335](https://cite.case.law/us/80/335/) (1872), it ruled that a federal judge may not be held accountable in damages for a judicial act taken within his court’s jurisdiction. Such immunity applies “however erroneous the act may have been, and however injurious in its consequences it may have proved to the plaintiff.” [_Id.,_ ](https://cite.case.law/us/80/335/)[at 347](https://cite.case.law/us/80/335/). \[...] In _Pierson_ v. _Ray,_ the Court held that absolute immunity shielded a municipal judge who was sued for damages under [42 U. S. C. § 1983](https://cite.case.law/citations/?q=42%20U.S.C.%20%C2%A7%201983) by clergymen who alleged that he had convicted them unconstitutionally for a peaceful protest against racial segregation. The Court stressed that such immunity was essential to protect the integrity of the judicial process. [386 U. S., at 554](https://cite.case.law/us/386/547/#p553).&#x20;

With this judicial immunity firmly established, the Court has extended absolute immunity to certain others who perform functions closely associated with the judicial process. The federal hearing examiner and administrative law judge have been afforded absolute immunity. “There can be little doubt that the role of the modern federal hearing examiner or administrative law judge ... is ‘functionally comparable’ to that of a judge.” _Butz_ v. _Economou,_ [438 U. S. 478](https://cite.case.law/us/438/478/#p513), 513 (1978). Full immunity also has been given to federal and state prosecutors. \[...] The same is true for witnesses, including police officers, who testify in judicial proceedings. Witnesses are “integral parts of the judicial process” and, accordingly, are shielded by absolute immunity. \[...] And the Court has noted the adoption in this country of the principle of immunity for grand jurors. See _Imbler_ v. _Pachtman,_ [424 U. S., at 423, n. 20](https://cite.case.law/us/424/409/#p424). \[...]

Although this Court has not decided whether state parole officials enjoy absolute immunity as a matter of federal law, \[...] federal appellate courts have so held.&#x20;

**B.**&#x20;

The Court has extended absolute immunity to the President when damages liability is predicated on his official act. _Nixon_ v. _Fitzgerald,_ [457 U. S. 731](https://cite.case.law/us/457/731/#p744), 744-758 (1982). \[...] “For executive officials in general, however, our cases make plain that qualified immunity represents the norm.” [_Ibid._](https://cite.case.law/us/457/800/#p807) \[...]

**C.**&#x20;

The Court has said that “in general our cases have followed a ‘functional’ approach to immunity law.”  “\[0]ur cases clearly indicate that immunity analysis rests on functional categories, not on the status of the defendant.” _Briscoe_ v. _LaHue,_ [460 U. S., at 342](https://cite.case.law/us/460/325/#p335). Absolute immunity flows not from rank or title or “location within the Government,” but from the nature of the responsibilities of the individual official. And in \[[_Butz_ v. _Economou_](#user-content-fn-1)[^1]] the Court mentioned the following factors, among others, as characteristic of the judicial process and to be considered in determining absolute as contrasted with qualified immunity: (a) the need to assure that the individual can perform his functions without harassment or intimidation; (b) the presence of safeguards that reduce the need for private damages actions as a means of controlling unconstitutional conduct; (c) insulation from political influence; (d) the importance of precedent; (e) the adversary nature of the process; and (f) the correctability of error on appeal. [_Id.,_ ](https://cite.case.law/us/438/478/#p513)[at 512](https://cite.case.law/us/438/478/#p513)

III

We turn to the application of these principles to the facts of the present case. Judge Cudahy of the Court of Appeals ... stressed the _Butz_ factors and was persuaded by what he felt were the absence of procedural safeguards, the rare and exceptional character of absolute immunity, and the need for such immunity only when public policy requires it.&#x20;

Petitioners, in response, and seemingly in order to negate the significance of certain of the specified factors, point out that grand jury proceedings possess few procedural safeguards that are associated with court proceedings, and are largely immune from any type of judicial review. \[...] Petitioners also observe that prosecutorial decisionmaking is not subject to the formalities of trials; instead, the prosecutor exercises broad and generally unreviewable discretion. Yet grand jurors and prosecutors enjoy absolute immunity. Petitioners finally argue that the Court’s cases teach that absolute immunity shields an official if (a) the official performs an adjudicatory function comparable to that of a judge, (b) the function is of sufficient public importance, and (c) the proper performance of that function would be subverted if the official were subjected to individual suit for damages. Brief for Petitioners 21.

When we evaluate the claim of immunity for the committee members, we bear in mind that immunity status is for the benefit of the public as well as for the individual concerned. \[...]  The committee members, in a sense, do perform an adjudicatory function in that they determine whether the accused inmate is guilty or innocent of the charge leveled against him; in that they hear testimony and receive documentary evidence; in that they evaluate credibility and weigh evidence; and in that they render a decision. We recognize, too, the presence of some societal importance in this dispute-resolution function. The administration of a prison is a difficult undertaking at best, for it concerns persons many of whom have demonstrated a proclivity for antisocial, criminal, and violent conduct. \[...]  We also acknowledge that many inmates do not refrain from harassment and intimidation. The number of nonmeritorious prisoners’ cases that come to this Court’s notice is evidence of this. Tension between prison officials and inmates has been described as “unremitting.” \[...]  “Retaliation is much more than a theoretical possibility.” \[...]  And we do not underestimate the fact, stressed by petitioners, that committee members usually are persons of modest means and, if they are suable and unprotected, perhaps would be disinclined to serve on a discipline committee. \[...]&#x20;

We conclude, nonetheless, that these concerns, to the extent they are well grounded, are overstated in the context of constitutional violations. We do not perceive the discipline committee’s function as a “classic” adjudicatory one, as petitioners would describe it. Surely, the members of the committee, unlike a federal or state judge, are not “independent”; to say that they are is to ignore reality. They are not professional hearing officers, as are administrative law judges. They are, instead, prison officials, albeit no longer of the rank and file, temporarily diverted from their usual duties. \[...] They are employees of the Bureau of Prisons and they are the direct subordinates of the warden who reviews their decision. They work with the fellow employee who lodges the charge against the inmate upon whom they sit in judgment. The credibility determination they make often is one between a co-worker and an inmate. They thus are under obvious pressure to resolve a disciplinary dispute in favor of the institution and their fellow employee. \[...]  It is the old situational problem of the relationship between the keeper and the kept, a relationship that hardly is conducive to a truly adjudicatory performance.

Neither do we equate this discipline committee membership to service upon a traditional parole board. The board is a “neutral and detached” hearing body. \[...] The parole board member has been described as an impartial professional serving essentially “as an arm of the sentencing judge."[^2] \[...]  And in the penalty context, the parole board is constitutionally required to provide greater due process protection than is the institution discipline committee.\[...]&#x20;

We relate this committee membership, instead, to the school board service the Court had under consideration in _Wood_ v. _Strickland,_ [420 U. S. 308](https://cite.case.law/us/420/308/) (1975). The school board members were to function as “adjudicators in the school disciplinary process,” and they were to “judge whether there have been violations of school regulations and, if so, the appropriate sanctions for the violations.” [Id., at 319](https://cite.case.law/us/420/308/). Despite the board’s adjudicative function of that extent, the Court concluded that the board members were to be protected by only qualified immunity. After noting the suggestion of the presence of a deterrence-from-service factor, the Court concluded that “absolute immunity would not be justified since it would not sufficiently increase the ability of school officials to exercise their discretion in a forthright manner to warrant the absence of a remedy for students subjected to intentional or otherwise inexcusable deprivations.” \[...]&#x20;

That observation and conclusion are equally applicable here. It is true, of course, that the “prisoner and the schoolchild stand in wholly different circumstances, separated by the harsh facts of criminal conviction and incarceration.” _Ingraham_ v. _Wright,_ [430 U. S. 651](https://cite.case.law/us/430/651/#p669), 669 (1977). But in _Ingraham_ it was also said that even if schoolchildren and their parents do not have a prisoner’s motive or proclivity to institute harassing lawsuits, they have “little need for the protection of the Eighth Amendment,” for “the openness of the public school and its supervision by the community afford significant safeguards against the kinds of abuses from which the Eighth Amendment protects the prisoner.” [_Id.,_ ](https://cite.case.law/us/430/651/#p669)[at 670](https://cite.case.law/us/430/651/#p669). If qualified immunity is sufficient for the schoolroom, it should be more than sufficient for the jailhouse where the door is closed, not open, and where there is little, if any, protection by way of community observation.&#x20;

\[...]

\[The] line between absolute immunity and qualified immunity often is not an easy one to perceive and structure. That determination in this case, however, is not difficult, and we readily conclude that these committee members fall on the qualified-immunity side of the line.

Under the Bureau’s disciplinary policy in effect at the time of respondents’ hearings, few of the procedural safeguards contained in the Administrative Procedure Act under consideration in _Butz_ were present. The prisoner was to be afforded neither a lawyer nor an independent nonstaff representative. There was no right to compel the attendance of witnesses or to cross-examine. There was no right to discovery. There was no cognizable burden of proof. No verbatim transcript was afforded. Information presented often was hearsay or self-serving. The committee members were not truly independent. In sum, the members had no identification with the judicial process of the kind and depth that has occasioned absolute immunity.

Qualified immunity, however, is available to these committee members. That, we conclude, is the proper point at which to effect the balance between the opposing considerations. This less-than-absolute protection is not of small consequence. As the Court noted in _Butz,_ \[...] insubstantial lawsuits can be recognized and be quickly disposed of, and firm application of the Federal Rules of Civil Procedure “will ensure that federal officials are not harassed by frivolous lawsuits.” \[...] All the committee members need to do is to follow the clear and simple constitutional requirements of [_Wolff_ v. _McDonnell_](https://cite.case.law/us/418/539/#p562) \[...]; they then should have no reason to fear substantial harassment and liability.&#x20;

Qualified immunity has been widely imposed on executive officials who possess greater responsibilities. \[...] “\[I]t is not unfair to hold liable the official who knows or should know he is acting outside the law, and . . . insisting on an awareness of clearly established constitutional limits will not unduly interfere with the exercise of official judgment.” \[...]&#x20;

It is the business of prison officials, of course, to maintain order within their institutions. But this fact does not support a claim that every step taken to protect constitutional rights of prisoners will lead to a breakdown in institutional discipline and security. Routine and automatic arguments to this effect have been made before and have been rejected by this Court. \[...]&#x20;

We likewise are not impressed with the argument that anything less than absolute immunity will result in a flood of litigation and in substantial procedural burdens and expense for committee members. This argument, too, has been made before. \[...] Our experience teaches us that the vast majority of prisoner cases are resolved on the complaint alone. Of those prisoners whose complaints survive initial dismissal, few attempt discovery and fewer still actually obtain it. \[...]  And any expense of litigation largely is alleviated by the fact that a Government official who finds himself as a defendant in litigation of this kind is often represented, as in this case, by Government counsel. If the problem becomes acute, the Government has alternatives available to it: it might decide to indemnify the defendant official; Congress could make the claim a subject for the Federal Tort Claims Act; and Congress could even consider putting in place administrative law judges to preside at prison committee hearings.

The judgment of the Court of Appeals is affirmed.

_It is so ordered._

**Footnotes**

[1](https://cite.case.law/us/474/193/#ref_footnote_1_1) This activity apparently resulted in a visit to the Terre Haute facility by an Assistant Surgeon General and in a lawsuit concerning the last of the four hospital deaths. See _Green_ v. _Carlson,_ [581 F. 2d 669](https://cite.case.law/f2d/581/669/) (CA7 1978), aff’d, [446 U. S. 14](https://cite.case.law/us/446/14/) (1980).

[2](https://cite.case.law/us/474/193/#ref_footnote_1_2) The Policy Statement did not provide for cross-examination, representation by a lawyer, verbatim record of the proceeding, or nonagency or judicial review. Neither did it specify the standard of proof or the standard of punishment.

[3](https://cite.case.law/us/474/193/#ref_footnote_1_3) The Solicitor General advises us, see Brief for Petitioners 3, n. 4, that a committee of this kind at the Terre Haute facility usually was composed of three members. By regulation, the chairman and one other member must be of department-head level, or higher. See [28 CFR § 541.16](https://cite.case.law/citations/?q=28%20C.F.R.%20%C2%A7%20541.16)(b) [\*196](https://cite.case.law/us/474/193/#p196)(1985). The reporting officer, investigating officer, and any person who was a witness to the incident or played a significant part in having the charge referred, may not be a member of the committee except “where virtually every staff member in the institution witnessed the incident in whole or in part.” [_Ibid._](https://cite.case.law/citations/?q=28%20C.F.R.%20%C2%A7%20541.16)

[4](https://cite.case.law/us/474/193/#ref_footnote_1_4) Judgment was entered in favor of the defendant Warden and the defendant administrative supervisor. Respondents did not contest this aspect of the judgment on appeal.

[5](https://cite.case.law/us/474/193/#ref_footnote_1_5) The sole question raised by petitioners in this Court is whether, as committee members, they were entitled to absolute immunity. Petitioners state that they have not challenged — although they do not concede— the ruling that they violated “clearly established constitutional rights” of respondents. See Brief for Petitioners 7, n. 8.

[^1]: [438 U. S., at 511](https://cite.case.law/us/438/478/#p513)

[^2]: Internal quotations omitted.
