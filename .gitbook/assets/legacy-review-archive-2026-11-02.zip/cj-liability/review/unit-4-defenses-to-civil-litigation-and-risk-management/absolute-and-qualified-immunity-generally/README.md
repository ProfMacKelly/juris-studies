> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Justice Liability Law: A Sourcebook](https://profmackelly.gitbook.io/cj-liability/defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally) · Snapshot: 2026-11-02 · Original path: `defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally`

---

# Absolute and Qualified Immunity, Generally

