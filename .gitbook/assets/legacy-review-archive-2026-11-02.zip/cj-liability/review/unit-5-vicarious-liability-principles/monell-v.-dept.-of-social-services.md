> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Justice Liability Law: A Sourcebook](https://profmackelly.gitbook.io/cj-liability/vicarious-liability-principles/monell-v.-dept.-of-social-services) · Snapshot: 2026-11-02 · Original path: `vicarious-liability-principles/monell-v.-dept.-of-social-services`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/cj-liability/unit-5-vicarious-liability-principles/monell-v.-dept.-of-social-services)

---

# Monell v. Dept. of Social Services

\[Note: Edited from the [<mark style="color:blue;">original</mark>](https://www.courtlistener.com/opinion/109881/monell-v-new-york-city-dept-of-social-servs/).]

***

436 U.S. 658 (1978)

Supreme Court of the United States

**Monell et al.**\
**v.**\
**Department of Social Services of**\
**the City of New York et al.**

MR. JUSTICE BRENNAN delivered the opinion of the Court.

Petitioners, a class of female employees of the Department of Social Services and of the Board of Education of the city of New York, commenced this action under 42 U.S. C. § 1983 in July 1971.\[1] The gravamen of the complaint was that the  Board and the Department had as a matter of official policy compelled pregnant employees to take unpaid leaves of absence before such leaves were required for medical reasons.\[2] ... The suit sought injunctive relief and backpay for periods of unlawful forced leave. Named as defendants in the action were the Department and its Commissioner, the Board and its Chancellor, and the city of New York and its Mayor. In each case, the individual defendants were sued solely in their official capacities.\[3]

The \[District] court \[concluded] that the acts complained of were unconstitutional ... . Nonetheless plaintiffs' prayers for backpay were denied because any such damages would come ultimately from the city of New York and, therefore, to hold otherwise would be to "circumven\[t]" the immunity conferred on municipalities by [_Monroe_ v. _Pape_](#user-content-fn-1)[^1].&#x20;

On appeal, petitioners \[argued] that the Board of Education\[4] was not a "municipality" within the meaning of _Monroe_ v. _Pape, ..._ and that, in any event, the District Court had erred in barring a damages award against the individual defendants. The Court of Appeals for the Second Circuit rejected both contentions. The court first held that the Board of Education was not a "person" under § 1983 because "it performs a vital governmental function . . ., and, significantly, while it has the right to determine how the funds appropriated to it shall be spent . . ., it has no final say in deciding what its appropriations shall be."\[\*][^2] The individual defendants, however, were "persons" under § 1983, even when sued solely in their official capacities.\[\*][^3]  Yet, because a damages award would "have to be paid by a city that was held not to be amenable to such an action in _Monroe_ v. _Pape,_" a damages action against officials sued in their official capacities could not proceed. ...

We granted certiorari in this case ... to consider

> "Whether local governmental officials and/or local independent school boards are \`persons' within the meaning of 42 U.S. C. § 1983 when equitable relief in the nature of back pay is sought against them in their official capacities?" ...

Although ... we have decided the merits of over a score of cases brought under § 1983 in which the principal defendant was a school board\[5], \[we have previously stated that] the question presented here was open and would be decided "another day." That other day has come and we now overrule _Monroe_ v. _Pape, supra,_ insofar as it holds that local governments are wholly immune from suit under § 1983.\[7]

## I

In _Monroe_ v. _Pape,_ we held that "Congress did not undertake to bring municipal corporations within the ambit of \[§ 1983]."\*[^4]  The sole basis for this conclusion was an inference drawn from Congress' rejection of the "Sherman amendment" to the bill which became the Civil Rights Act of 1871, 17 Stat. 13, the precursor of § 1983. ...&#x20;

A fresh analysis ... shows, however, that _Monroe_ incorrectly equated the "obligation" of which Representative Poland spoke with "civil liability."

{% hint style="info" %}
Note: I have removed an extensive portion of this section of the Court's decision to help streamline your reading. That said it is recommended that you review [this brief background of the Civil Rights Act of 1871](https://www.encyclopedia.com/social-sciences-and-law/law/law/ku-klux-klan-act) (also known at the time as the **Ku Klux Klan Act**), the Sherman amendment (referenced above), and their relationship to § 1983.
{% endhint %}

\[...]

## II

Our analysis of the legislative history of the Civil Rights Act of 1871 compels the conclusion that Congress _did_ intend municipalities and other local government units to be included among those persons to whom § 1983 applies.\[54] Local governing bodies,\[55] therefore, can be sued directly under § 1983 for monetary, declaratory, or injunctive relief where, as here, the action that is alleged to be unconstitutional implements or executes a policy statement, ordinance, regulation, or decision officially adopted and promulgated by that body's officers. Moreover, although the touchstone of the § 1983 action against a government body is an allegation that official policy is responsible for a deprivation of rights protected by the Constitution, local governments, like every other § 1983 "person," by the very terms of the statute, may be sued for constitutional deprivations visited pursuant to governmental "custom" even though such a custom has not received formal approval through the body's official decisionmaking channels. As Mr. Justice Harlan, writing for the Court, said in _Adickes_ v. _S. H. Kress & Co._[_\*_](#user-content-fn-5)[^5]: "Congress included customs and usages \[in § 1983] because of the persistent and widespread discriminatory practices of state officials . . . . Although not authorized by written law, such practices of state officials could well be so permanent and well settled as to constitute a \`custom or usage' with the force of law."\[56]

On the other hand, the language of § 1983, read against the background of the same legislative history, compels the conclusion that Congress did not intend municipalities to be held liable unless action pursuant to official municipal policy of some nature caused a constitutional tort. In particular, we conclude that a municipality cannot be held liable _solely_ because it employs a tortfeasor—or, in other words, a municipality cannot be held liable under § 1983 on a _respondeat superior_ theory.

We begin with the language of § 1983 as originally passed:

> "\[_A_]_ny person who,_ under color of any law, statute, ordinance, regulation, custom, or usage of any State, _shall subject, or cause to be subjected,_ any person . . . to the deprivation of any rights, privileges, or immunities secured by the Constitution of the United States, shall, any such law, statute, ordinance, regulation, custom, or usage of the State to the contrary notwithstanding, be liable to the party injured in any action at law, suit in equity, or other proper proceeding for redress . . . ." 17 Stat. 13 (emphasis added).

The italicized language plainly imposes liability on a government that, under color of some official policy, "causes" an employee to violate another's constitutional rights. At the same time, that language cannot be easily read to impose liability vicariously on governing bodies solely on the basis of the existence of an employer-employee relationship with a tortfeasor. Indeed, the fact that Congress did specifically provide that A's tort became B's liability if B "caused" A to subject another to a tort suggests that Congress did not intend § 1983 liability to attach where such causation was absent.\[57]\*[^6]&#x20;

Equally important, creation of a federal law of _respondeat superior_ would have raised all the constitutional problems associated with the obligation to keep the peace, an obligation Congress chose not to impose because it thought imposition of such an obligation unconstitutional. To this day, there is disagreement about the basis for imposing liability on an employer for the torts of an employee when the sole nexus between the employer and the tort is the fact of the employer-employee relationship. ... Nonetheless, two justifications tend to stand out. First is the common-sense notion that no matter how blameless an employer appears to be in an individual case, accidents might nonetheless be reduced if employers had to bear the cost of accidents. ... Second is the argument that the cost of accidents should be spread to the community as a whole on an insurance theory. ...

The first justification is of the same sort that was offered for statutes like the Sherman amendment: "The obligation to make compensation for injury resulting from riot is, by arbitrary enactment of statutes, affirmatory law, and the reason of passing the statute is to secure a more perfect police regulation." ... This justification was obviously insufficient to sustain the amendment against perceived constitutional difficulties and there is no reason to suppose that a more general liability imposed for a similar reason would have been thought less constitutionally objectionable. The second justification was similarly put forward as a justification for the Sherman amendment: "we do not look upon \[the Sherman amendment] as a punishment. . . . It is a mutual insurance." _..._ Again, this justification was insufficient to sustain the amendment.

We conclude, therefore, that a local government may not be sued under § 1983 for an injury inflicted solely by its employees or agents. Instead, it is when execution of a government's policy or custom, whether made by its lawmakers or by those whose edicts or acts may fairly be said to represent official policy, inflicts the injury that the government as an entity is responsible under § 1983. Since this case unquestionably involves official policy as the moving force of the constitutional violation found by the District Court, ... we must reverse the judgment below. \[W]e ... do not address ... the full contours of municipal liability under § 1983 may be. We have attempted only to sketch so much of the § 1983 cause of action against a local government as is apparent from the history of the 1871 Act and our prior cases, and we expressly leave further development of this action to another day.

## III

Although we have stated that _stare decisis_ has more force in statutory analysis than in constitutional adjudication because, in the former situation, Congress can correct our mistakes through legislation, ... we have never applied _stare decisis_ mechanically to prohibit overruling our earlier decisions determining the meaning of statutes. ... Nor is this a case where we should "place on the shoulders of Congress the burden of the Court's own error." _..._

First, _Monroe_ v. _Pape,_ insofar as it completely immunizes municipalities from suit under § 1983, was a departure from prior practice. ... Moreover, the constitutional defect that led to the rejection of the Sherman amendment would not have distinguished between municipalities and school boards, each of which is an instrumentality of state administration. ... For this reason, our cases—decided both before and after _Monroe_— holding school boards liable in § 1983 actions are inconsistent with _Monroe_\[.] ...

Second, the principle of blanket immunity established in _Monroe_ cannot be cabined short of school boards. Yet such an extension would itself be inconsistent with recent expressions of congressional intent. In the wake of our decisions, Congress not only has shown no hostility to federal-court decisions against school boards, but it has indeed rejected efforts to strip the federal courts of jurisdiction over school boards.\[62] Moreover, recognizing that school boards are often defendants in school desegregation suits, which have almost without exception been § 1983 suits, Congress has twice passed legislation authorizing grants to school boards to assist them in complying with federal-court decrees.\[63] Finally, in regard to the Civil Rights Attorney's Fees Awards Act of 1976, ... which allows prevailing parties (in the discretion of the court) in § 1983 suits to obtain attorney's fees from the losing parties, the Senate stated:

> "\[D]efendants in these cases are often State or local _bodies_ or State or local officials. In such cases it is intended that the attorneys' fees, like other items of costs, will be collected either directly from the official, _in his official capacity,_ from funds of his agency or under his control, or _from the State or local government (whether or not the agency or government is a named party)."_ ...

Far from showing that Congress has relied on _Monroe,_ therefore, events since 1961 show that Congress has refused to extend the benefits of _Monroe_ to school boards and has attempted to allow awards of attorney's fees against local governments\[.] &#x20;

Third, municipalities can assert no reliance claim which can support an absolute immunity. As Mr. Justice Frankfurter said in _Monroe,_ "\[t]his is not an area of commercial law in which, presumably, individuals may have arranged their affairs in reliance on the expected stability of decision."\*[^7] Indeed, municipalities simply cannot "arrange their affairs" on an assumption that they can violate constitutional rights indefinitely since injunctive suits against local officials under § 1983 would prohibit any such arrangement. And it scarcely need be mentioned that nothing in _Monroe_ encourages municipalities to violate constitutional rights or even suggests that such violations are anything other than completely wrong.

Finally, even under the most stringent test for the propriety of overruling a statutory decision proposed by Mr. Justice Harlan in _Monroe_\[65]—"that it appear beyond doubt from the legislative history of the 1871 statute that _\[Monroe]_ misapprehended the meaning of the \[section],"... —the overruling of _Monroe_ insofar as it holds that local governments are not "persons" who may be defendants in § 1983 suits is clearly proper. It is simply beyond doubt that, under the 1871 Congress' view of the law, were § 1983 liability unconstitutional as to local governments, it would have been equally unconstitutional as to state officers. Yet everyone—proponents and opponents alike—knew § 1983 would be applied to state officers and nonetheless stated that § 1983 was constitutional. ... And, moreover, there can be no doubt that § 1 of the Civil Rights Act was intended to provide a remedy, to be broadly construed, against all forms of official violation of federally protected rights. Therefore, absent a clear statement in the legislative history supporting the conclusion that § 1 was not to apply to the official acts of a municipal corporation—which simply is not present—there is no justification for excluding municipalities from the "persons" covered by § 1.

For the reasons stated above, therefore, we hold that _stare decisis_ does not bar our overruling of _Monroe_ insofar as it is inconsistent with Parts I and II of this opinion.\[66]

## IV

Since the question whether local government bodies should be afforded some form of official immunity was not presented as a question to be decided on this petition ..., we express no views on the scope of any municipal immunity beyond holding that municipal bodies sued under § 1983 cannot be entitled to an absolute immunity, lest our decision that such bodies are subject to suit under § 1983 "be drained of meaning\[.]"\*[^8]&#x20;

## V

For the reasons stated above, the judgment of the Court of Appeals is

_Reversed._

\[...]

## Footnotes

\[1] The complaint was amended on September 14, 1972, to allege a claim under Title VII of the Civil Rights Act of 1964, 78 Stat. 253, as amended, 42 U.S. C. § 2000e et seq. (1970 ed. and Supp. V). The District Court held that the 1972 amendments to Title VII did not apply retroactively to discrimination suffered prior to those amendments even when an action challenging such prior discrimination was pending on the date of the amendments. [394 F. Supp. 853](https://www.courtlistener.com/opinion/1415269/monell-v-department-of-soc-servs-of-city-of-ny/), 856 (SDNY 1975). This holding was affirmed on appeal. [532 F.2d 259](https://www.courtlistener.com/opinion/334135/12-fair-emplpraccas-836-11-empl-prac-dec-p-10755-jane-monell-v/), 261-262 (CA2 1976). Although petitioners sought certiorari on the Title VII issue as well as the § 1983 claim, we restricted our grant of certiorari to the latter issue. 429 U.S. 1071.

\[2] The plaintiffs alleged that New York had a citywide policy of forcing women to take maternity leave after the fifth month of pregnancy unless a city physician and the head of an employee's agency allowed up to an additional two months of work. Amended Complaint ¶ 28, App. 13-14. The defendants did not deny this, but stated that this policy had been changed after suit was instituted. Answer ¶ 13, App. 32-33. The plaintiffs further alleged that the Board had a policy of requiring women to take maternity leave after the seventh month of pregnancy unless that month fell in the last month of the school year, in which case the teacher could remain through the end of the school term. Amended Complaint ¶¶ 39, 42, 45, App. 18-19, 21. This allegation was denied. Answer ¶¶ 18, 22, App. 35, 37.

\[3] Amended Complaint ¶ 24, App. 11-12.

\[4] Petitioners conceded that the Department of Social Services enjoys the same status as New York City for _Monroe_ purposes. See [532 F.2d, at 263](https://www.courtlistener.com/opinion/334135/12-fair-emplpraccas-836-11-empl-prac-dec-p-10755-jane-monell-v/).

\[5] _Milliken_ v. _Bradley,_ [433 U.S. 267 ](https://www.courtlistener.com/opinion/109723/milliken-v-bradley/)(1977); _Dayton Board of Education_ v. _Brinkman,_ [433 U.S. 406 ](https://www.courtlistener.com/opinion/109728/dayton-bd-of-ed-v-brinkman/)(1977); _Vorchheimer_ v. _School District of Philadelphia,_ [430 U.S. 703 ](https://www.courtlistener.com/opinion/109636/vorchheimer-v-school-dist-of-philadelphia/)(1977); _East Carroll Parish School Board_ v. _Marshall,_ [424 U.S. 636 ](https://www.courtlistener.com/opinion/109397/east-carroll-parish-school-bd-v-marshall/)(1976); _Milliken_ v. _Bradley,_ [418 U.S. 717 ](https://www.courtlistener.com/opinion/109102/milliken-v-bradley/)(1974); _Bradley_ v. _Richmond School Board,_ [416 U.S. 696 ](https://www.courtlistener.com/opinion/109027/bradley-v-school-bd-of-richmond/)(1974); _Cleveland Board of Education_ v. _LaFleur,_ [414 U.S. 632 ](https://www.courtlistener.com/opinion/108913/cleveland-bd-of-ed-v-lafleur/)(1974); _Keyes_ v. _School District No. 1, Denver, Colo.,_ [413 U.S. 189 ](https://www.courtlistener.com/opinion/108844/keyes-v-school-dist-no-1-denver/)(1973); _San Antonio School District_ v. _Rodriguez,_ [411 U.S. 1 ](https://www.courtlistener.com/opinion/108751/san-antonio-independent-school-dist-v-rodriguez/)(1973); _Swann_ v. _Charlotte-Mecklenburg Board of Education,_ [402 U.S. 1 ](https://www.courtlistener.com/opinion/108316/swann-v-charlotte-mecklenburg-bd-of-ed/)(1971); _Northcross_ v. _Memphis Board of Education,_ [397 U.S. 232 ](https://www.courtlistener.com/opinion/108094/northcross-v-board-of-ed-of-memphis-city-schools/)(1970); _Carter_ v. _West Feliciana Parish School Board,_ 396 U.S. 226 (1969); _Alexander_ v. _Holmes County Board of Education,_ [396 U.S. 19 ](https://www.courtlistener.com/opinion/107993/alexander-v-holmes-county-bd-of-ed/)(1969); _Kramer_ v. _Union Free School District,_ [395 U.S. 621 ](https://www.courtlistener.com/opinion/107971/kramer-v-union-free-school-dist-no-15/)(1969); _Tinker_ v. _Des Moines Independent School District,_ [393 U.S. 503 ](https://www.courtlistener.com/opinion/107841/tinker-v-des-moines-independent-community-school-dist/)(1969); _Monroe_ v. _Board of Comm'rs,_ [391 U.S. 450 ](https://www.courtlistener.com/opinion/107707/monroe-v-board-of-commrs-of-jackson/)(1968); _Raney_ v. _Board of Education,_ [391 U.S. 443 ](https://www.courtlistener.com/opinion/107706/raney-v-board-of-ed-of-gould-school-dist/)(1968); _Green_ v. _New Kent County School Board,_ [391 U.S. 430 ](https://www.courtlistener.com/opinion/107705/green-v-county-school-board/)(1968); _Abington School District_ v. _Schempp,_ [374 U.S. 203 ](https://www.courtlistener.com/opinion/106658/abington-school-dist-v-schempp/)(1963); _Goss_ v. _Board of Education,_ [373 U.S. 683 ](https://www.courtlistener.com/opinion/106630/goss-v-board-of-ed-of-knoxville/)(1963); _McNeese_ v. _Board of Education,_ [373 U.S. 668 ](https://www.courtlistener.com/opinion/106629/mcneese-v-board-of-ed-for-community-unit-school-dist-187/)(1963); _Orleans Parish School Board_ v. _Bush,_ [365 U.S. 569 ](https://www.courtlistener.com/opinion/106194/orleans-parish-school-bd-v-bush/)(1961); _Brown_ v. _Board of Education,_ [347 U.S. 483 ](https://www.courtlistener.com/opinion/105221/brown-v-board-of-education/)(1954).

\[6] _Cleveland Board of Education_ v. [_LaFleur, supra_](https://www.courtlistener.com/opinion/108913/cleveland-bd-of-ed-v-lafleur/)_,_ at 636; App. in _Keyes_ v. _School District No. 1, Denver, Colo.,_ O. T. 1972, No. 71-507, p. 4a; App. in _Swann_ v. _Charlotte-Mecklenburg Board of Education,_ O. T. 1970, No. 281, p. 465a; Pet. for Cert. in _Northcross_ v. _Memphis Board of Education,_ O. T. 1969, No. 1136, p. 3; _Tinker_ v. _Des Moines Independent School District, supra,_ at 504; _McNeese_ v. _Board of Education, supra,_ at 671.

\[7] However, we do uphold _Monroe_ v. _Pape_ insofar as it holds that the doctrine of _respondeat superior_ is not a basis for rendering municipalities liable under § 1983 for the constitutional torts of their employees. See Part II, _infra._

\[8] We expressly declined to consider "policy considerations" for or against municipal liability. See 365 U.S., at 191.

\[9] Mr. Justice Douglas, the author of _Monroe,_ has suggested that the municipal exclusion might more properly rest on a theory that Congress sought to prevent the financial ruin that civil rights liability might impose on municipalities. See _City of Kenosha_ v. _Bruno,_ [412 U.S. 507](https://www.courtlistener.com/opinion/108813/kenosha-v-bruno/), 517-520 (1973). However, this view has never been shared by the Court, see _Monroe_ v. _Pape,_ 365 U. S., at 190; _Moor_ v. _County of Alameda,_ [411 U.S. 693](https://www.courtlistener.com/opinion/108782/moor-v-county-of-alameda/), 708 (1973), and the debates do not support this position.

\[10] Globe 522.

\[11] Briefly, § 2 created certain federal crimes in addition to those defined in § 2 of the 1866 Civil Rights Act, 14 Stat. 27, each aimed primarily at the Ku Klux Klan. Section 3 provided that the President could send the militia into any State wracked with Klan violence. Finally, § 4 provided for suspension of the writ of habeas corpus in enumerated circumstances, again primarily those thought to obtain where Klan violence was rampant. See Cong. Globe, 42d Cong., 1st Sess., App. 335-336 (1871) (hereinafter Globe App.).

\[12] Globe 709.

\[13] See _id.,_ at 663, quoted in Appendix to this opinion, _infra,_ at 702-703.

\[14] _Ibid._ An action for recovery of damages was to be in the federal courts and denominated as a suit against the county, city, or parish in which the damage had occurred. _Ibid._ Execution of the judgment was not to run against the property of the government unit, however, but against the private property of any inhabitant. _Ibid._

\[15] See Globe 749 and 755, quoted in Appendix to this opinion, _infra,_ at 703-704.

\[16] "Let the people of property in the southern States understand that if they will not make the hue and cry and take the necessary steps to put down lawless violence in those States their property will be holden responsible, and the effect will be most wholesome." Globe 761.

Senator Sherman was apparently unconcerned that the conference committee substitute, unlike the original amendment, did not place liability for riot damage directly on the property of the well-to-do, but instead placed it on the local government. Presumably he assumed that taxes would be levied against the property of the inhabitants to make the locality whole.

\[17] According to Senator Sherman, the law had originally been adopted in England immediately after the Norman Conquest and had most recently been promulgated as the law of 7 & 8 Geo. 4, ch. 31 (1827). See Globe 760. During the course of the debates, it appeared that Kentucky, Maryland, Massachusetts, and New York had similar laws. See _id.,_ at 751 (Rep. Shellabarger); _id.,_ at 762 (Sen. Stevenson); _id.,_ at 771 (Sen. Thurman); _id.,_ at 792 (Rep. Butler). Such a municipal liability was apparently common throughout New England. See _id.,_ at 761 (Sen. Sherman).

\[18] In the Senate, opponents, including a number of Senators who had voted for § 1 of the bill, criticized the Sherman amendment as an imperfect and impolitic rendering of the state statutes. Moreover, as drafted, the conference substitute could be construed to protect rights that were not protected by the Constitution. A complete critique was given by Senator Thurman. See Globe 770-772.

\[19] See 365 U.S., at 190, quoted _supra,_ at 664.

\[20] See Globe 804, quoted in Appendix to this opinion, _infra,_ at 704.

\[21] See Globe 758 (Sen. Trumbull); _id.,_ at 772 (Sen. Thurman); _id.,_ at 791 (Rep. Willard). The Supreme Court of Indiana had so held in giving effect to the Civil Rights Act of 1866. See _Smith_ v. _Moody,_ 26 Ind. 299 (1866) (following _Coryell_), one of three State Supreme Court cases referred to in Globe App. 68 (Rep. Shellabarger). Moreover, § 2 of the 1871 Act as passed, unlike § 1, prosecuted persons who violated federal rights whether or not that violation was under color of official authority, apparently on the theory that Ku Klux Klan violence was infringing the right of protection defined by _Coryell._ Nonetheless, opponents argued that municipalities were not generally charged by the States with keeping the peace and hence did not have police forces, so that the duty to afford protection ought not devolve on the municipality, but on whatever agency of state government was charged by the State with keeping the peace. See _infra,_ at 673, and n. 30. In addition, they argued that Congress could not constitutionally add to the duties of municipalities. See _infra,_ at 673-678.

\[22] U. S. Const., Art. IV, § 2, cl. 2:

"A Person charged in any State with Treason, Felony, or other Crime, who shall flee from Justice, and be found in another State, shall on Demand of the executive Authority of the State from which he fled, be delivered up, to be removed to the State having Jurisdiction of the Crime."

\[23] _Id.,_ cl. 3:

"No Person held to Service or Labour in one State, under the Laws thereof, escaping into another, shall, in Consequence of any Law or Regulation therein, be discharged from such Service or Labour, but shall be delivered up on Claim of the Party to whom such Service or Labour may be due."

\[24] _Id.,_ cl. 1.

\[25] See Globe 751. See also _id.,_ at 760 (Sen. Sherman) ("If a State may . . . pass a law making a county . . . responsible for a riot in order to deter such crime, then we may pass the same remedies . . .").

\[26] _Id.,_ at 751; see n. 17, _supra._

\[27] Globe 751 (emphasis added). Compare this statement with Representative Poland's remark upon which our holding in _Monroe_ was based. See _supra,_ at 664.

\[28] See, _e. g., Gelpcke_ v. _Dubuque,_ [1 Wall. 175 ](https://www.courtlistener.com/opinion/87567/gelpcke-v-dubuque/)(1864); _Von Hoffman v. City of Quincy,_ [4 Wall. 535 ](https://www.courtlistener.com/opinion/87795/von-hoffman-v-city-of-quincy/)(1867); _Riggs_ v. _Johnson County,_ [6 Wall. 166 ](https://www.courtlistener.com/opinion/87903/riggs-v-johnson-county/)(1868); _Weber_ v. _Lee County,_ [6 Wall. 210 ](https://www.courtlistener.com/opinion/87904/weber-v-lee-county/)(1868); _Supervisors v. Rogers,_ [7 Wall. 175 ](https://www.courtlistener.com/opinion/87995/supervisors-v-rogers/)(1869); _Benbow_ v. _Iowa City,_ [7 Wall. 313 ](https://www.courtlistener.com/opinion/88010/benbow-v-iowa-city/)(1869); _Supervisors_ v. _Durant,_ [9 Wall. 415 ](https://www.courtlistener.com/opinion/88174/supervisors-v-durant/)(1870). See generally 6 C. Fairman, History of the Supreme Court of the United States: Reconstruction and Reunion, 1864-1888, ohs. 17-18 (1971).

\[29] See Globe 751-752.

\[30] Others taking a view similar to Representative Blair's included: Representative Willard, see _id.,_ at 791; Representative Poland, see _id.,_ at 794; Representative Burchard, see _id.,_ at 795; Representative Farnsworth, see _id.,_ at 799. Representative Willard also took a somewhat different position: He thought that the Constitution would not allow the Federal Government to dictate the manner in which a State fulfilled its obligation of protection. That is, he thought it a matter of state discretion whether it delegated the peacekeeping power to a municipal or county corporation, to a sheriff, etc. He did not doubt, however, that the Federal Government could impose on the _States_ the obligation imposed by the Sherman amendment, and presumably he would have enforced the amendment against a municipal corporation to which the peacekeeping obligation had been delegated. See _id.,_ at 791.

Opponents of the Sherman amendment in the Senate agreed with Blair that Congress had no power to pass the Sherman amendment because it fell outside limits on national power implicit in the federal structure of the Constitution and recognized in, _e. g., Collector_ v. _Day,_ [11 Wall. 113 ](https://www.courtlistener.com/opinion/88308/collector-v-day/)(1871). However, the Senate opponents focused not on the amendment's attempt to obligate municipalities to keep the peace, but on the lien created by the amendment, which ran against _all_ money and property of a defendant municipality, including property held for public purposes, such as jails or courthouses. Opponents argued that such a lien once entered would have the effect of making it impossible for the municipality to function, since no one would trade with it. See, _e. g.,_ Globe 762 (Sen. Stevenson); _id.,_ at 763 (Sen. Casserly). Moreover, everyone knew that sound policy prevented execution against public property since this, too, was needed if local government was to survive. See, _e. g., ibid._ See also _Meriwether_ v. _Garrett,_ [102 U.S. 472](https://www.courtlistener.com/opinion/90262/meriwether-v-garrett/), 501, 513 (1880) (recognizing principle that public property of a municipality was not subject to execution); 2 J. Dillon, The Law of Municipal Corporations §§ 445-446 (1873 ed.) (same).

Although the arguments of the Senate opponents appear to be a correct analysis of then-controlling constitutional and common-law principles, their arguments are not relevant to an analysis of the constitutionality of § 1 of the Civil Rights Act since any judgment under that section, as in any civil suit in the federal courts in 1871, would have been enforced pursuant to _state_ laws under the Process Acts of 1792 and 1828. See Act of May 8, 1792, ch. 36, 1 Stat. 275; Act of May 19, 1828, 4 Stat. 278.

\[31] See n. 30, _supra._

\[32] In addition to the cases discussed in the text, see _Lane County_ v. _Oregon,_ [7 Wall. 71](https://www.courtlistener.com/opinion/87985/lane-county-v-oregon/), 77, 81 (1869), in which the Court held that the federal Legal Tender Acts should not be construed to require the States to accept taxes tendered in United States notes since this might interfere with a legitimate state activity.

\[33] Mr. Chief Justice Taney agreed:

"The state officers mentioned in the law \[of 1793] are not bound to execute the duties imposed upon them by Congress, unless they choose to do so, or are required to do so by a law of the state; and the state legislature has the power, if it thinks proper, to prohibit them. The act of 1793, therefore, must depend altogether for its execution upon the officers of the United States named in it." [16 Pet., at 630 ](https://www.courtlistener.com/opinion/86231/prigg-v-pennsylvania/)(concurring in part).

\[34] See _supra,_ at 670, and n. 21.

\[35] "_Be it enacted_ . . . That whenever the executive authority of any state in the Union . . . shall demand any person as a fugitive from justice . . . and shall moreover produce the copy of an indictment found . . . charging the person so demanded, with having committed treason, felony or other crime, certified as authentic by the governor or chief magistrate of the state . . . from whence the person so charged fled, it shall be the duty of the executive authority of the state or territory to which such person shall have fled, to cause him or her to be arrested and secured . . . and to cause the fugitive to be delivered to such agent \[of the demanding State] when he shall appear . . . ." 1 Stat. 302.

\[36] "The Supreme Court of the United States has decided repeatedly that Congress can impose no duty on a State officer." Globe 799 (Rep. Farnsworth). See also _id.,_ at 788-789 (Rep. Kerr).

\[37] See, _e. g., id.,_ at 764 (Sen. Davis); _ibid._ (Sen. Casserly); _id.,_ at 772 (Sen. Thurman) (reciting logic of _Day_); _id.,_ at 777 (Sen. Frelinghuysen); _id.,_ at 788-789 (Rep. Kerr) (reciting logic of _Day); id.,_ at 793 (Rep. Poland); _id.,_ at 799 (Rep. Farnsworth) (also reciting logic of _Day_).

\[38] _Warren_ v. _Paul,_ 22 Ind. 276 (1864); _Jones_ v. _Estate of Keep,_ 19 Wis. 369 (1865); _Fifield_ v. _Close,_ 15 Mich. 505 (1867); _Union Bank_ v. _Hill,_ 43 Tenn. 325 (1866); _Smith_ v. _Short,_ 40 Ala. 385 (1867).

\[39] See Globe 764 (Sen. Davis); _ibid._ (Sen. Casserly). See also T. Cooley, Constitutional Limitations \*483-\*484 (1871 ed.).

\[40] See cases cited in n. 28, _supra._ Since this Court granted unquestionably "positive" relief in Contract Clause cases, it appears that the distinction between the Sherman amendment and those cases was not that the former created a positive obligation whereas the latter imposed only a negative restraint. Instead, the distinction must have been that a violation of the Constitution was the predicate for "positive" relief in the Contract Clause cases, whereas the Sherman amendment imposed damages without regard to whether a local government was in any way at fault for the breach of the peace for which it was to be held for damages. See _supra,_ at 668. While no one stated this distinction expressly during the debates, the inference is strong that Congressmen in 1871 would have drawn this distinction since it explains why Representatives Poland, Burchard, and Willard, see _supra,_ at 680, could oppose the amendment while at the same time saying that the Federal Government might impose damages on a local government that had defaulted in a state-imposed duty to keep the peace, and it also explains why everyone agreed that a state or municipal officer could constitutionally be held liable under § 1 for violations of the Constitution. See _infra,_ at 682-683.

\[41] See, _e. g.,_ Globe 334 (Rep. Hoar); _id.,_ at 365 (Rep. Arthur); _id.,_ at 367-368 (Rep. Sheldon); _id.,_ at 385 (Rep. Lewis); Globe App. 217 (Sen. Thurman). In addition, officers were included among those who could be sued under the second conference substitute for the Sherman amendment. See Globe 805 (exchange between Rep. Willard and Rep. Shellabarger). There were no constitutional objections to the second report.

\[42] See _id.,_ at 795 (Rep. Blair); _id.,_ at 788 (Rep. Kerr); _id.,_ at 795 (Rep. Burchard); _id.,_ at 799 (Rep. Farnsworth).

\[43] "\[W]e cannot command a State officer to do any duty whatever, as such; and I ask . . . the difference between that and commanding a municipality. . . ." _Id.,_ at 795.

\[44] See Globe App. 216-217, quoted in n. 45, _infra._ In 1880, moreover, when the question of the limits of the _Prigg_ principle was squarely presented in _Ex parte Virginia,_ [100 U.S. 339](https://www.courtlistener.com/opinion/90041/ex-parte-virginia/), this Court held that _Dennison_ and _Day_ and the principle of federalism for which they stand did not prohibit federal enforcement of § 5 of the Fourteenth Amendment through suits directed to state officers. See [100 U.S., at 345-348](https://www.courtlistener.com/opinion/90041/ex-parte-virginia/).

\[45] Representative Bingham, the author of § 1 of the Fourteenth Amendment, for example, declared the bill's purpose to be "the enforcement . . . of the Constitution on behalf of every individual citizen of the Republic . . . to the extent of the rights guarantied to him by the Constitution." Globe App. 81. He continued:

"The States never had the right, though they had the power, to inflict wrongs upon free citizens by a denial of the full protection of the laws . . . . \[And] the States did deny to citizens the equal protection of the laws, they did deny the rights of citizens under the Constitution, and except to the extent of the express limitations upon the States, as I have shown, the citizen had no remedy. . . . They took property without compensation, and he had no remedy. They restricted the freedom of the press, and he had no remedy. They restricted the freedom of speech, and he had no remedy. They restricted the rights of conscience, and he had no remedy.. . . Who dare say, now that the Constitution has been amended, that the nation cannot by law provide against all such abuses and denials of right as these in the States and by States, or combinations of persons?" _Id.,_ at 85.

Representative Perry, commenting on Congress' action in passing the civil rights bill also stated:

"Now, by our action on this bill we have asserted as fully as we can assert the mischief intended to be remedied. We have asserted as clearly as we can assert our belief that it is the duty of Congress to redress that mischief. We have also asserted as fully as we can assert the constitutional right of Congress to legislate." Globe 800.

See also _id.,_ at 376 (Rep. Lowe); _id.,_ at 428-429 (Rep. Beatty); _id.,_ at 448 (Rep. Butler); _id.,_ at 475-477 (Rep. Dawes); _id.,_ at 578-579 (Sen. Trumbull); _id.,_ at 609 (Sen. Pool); Globe App. 182 (Rep. Mercur).

Other supporters were quite clear that § 1 of the Act extended a remedy not only where a State had passed an unconstitutional statute, but also where officers of the State were deliberately indifferent to the rights of black citizens:

"But the chief complaint is ... \[that] by a systematic maladministration of \[state law], or a neglect or refusal to enforce their provisions, a portion of the people are denied equal protection under them. Whenever such a state of facts is clearly made out, I believe \[§ 5 of the Fourteenth Amendment] empowers Congress to step in and provide for doing justice to those persons who are thus denied equal protection." _Id.,_ at 153 (Rep. Garfield). See also _Monroe_ v. _Pape,_ 365 U. S., at 171-187.

Importantly for our inquiry, even the opponents of § 1 agreed that it was constitutional and, further, that it swept very broadly. Thus, Senator Thurman, who gave the most exhaustive critique of § 1, said:

"This section relates wholly to civil suits. . . . Its whole effect is to give to the Federal Judiciary that which now does not belong to it&#x97;_&#x61; jurisdiction that may be constitutionally conferred upon it, I grant,_ but that has never yet been conferred upon it. It authorizes any person who is deprived of any right, privilege, or immunity secured to him by the Constitution of the United States, to bring an action against the wrong-doer in the Federal courts, and that without any limit whatsoever as to the amount in controversy. . . .

. . . . .

"_\[T]here is no limitation whatsoever upon the terms that are employed_ \[_in the bill_], _and they are as comprehensive as can be used._" Globe App. 216-217 (emphasis added).

\[46] See 2 J. Story, Commentaries on the Constitution of the United States § 1956 (T. Cooley ed. 1873).

\[47] Indeed the federal courts found no obstacle to awards of damages against municipalities for common-law takings. See _Sumner_ v. _Philadelphia,_ 23 F. Cas. 392 (No. 13,611) (CC ED Pa. 1873) (awarding damages of $2,273.36 and costs of $346.35 against the city of Philadelphia).

\[48] Nonetheless, suits could be brought in federal court if the natural persons who were members of the corporation were of diverse citizenship from the other parties to the litigation. See 5 Cranch, at 91.

\[49] See n. 28, _supra._

\[50] See, _e. g.,_ Globe 777 (Sen. Sherman); _id.,_ at 752 (Rep. Shellabarger) ("\[C]ounties, cities, and corporations of all sorts, after years of judicial conflict, have become thoroughly established to be an individual or person or entity of the personal existence, of which, as a citizen, individual, or inhabitant, the United States Constitution does take note and endow with faculty to sue and be sued in the courts of the United States").

\[51] See _Northwestern Fertilizing Co._ v. _Hyde Park,_ 18 F. Cas. 393, 394 (No. 10,336) (CC ND Ill. 1873); 2 J. Kent, Commentaries on American Law \*278-\*279 (12th O. W. Holmes ed. 1873). See also _United States_ v. _Maurice,_ 2 Brock. 96, 109 (CC Va. 1823) (Marshall, C. J.) ("The United States is a government, and, consequently, a body politic and corporate"); Apps. D and E to Brief for Petitioners in _Monroe_ v. _Pape,_ O. T. 1960, No. 39 (collecting state statutes which, in 1871, defined municipal corporations as bodies politic and corporate).

\[52] The court also noted that there was no discernible reason why persons injured by municipal corporations should not be able to recover. See 18 F. Cas., at 394.

\[53] In considering the effect of the Act of Feb. 25, 1871, in _Monroe,_ however, Mr. Justice Douglas, apparently focusing on the word "may," stated: "\[T]his definition \[of person] is merely an allowable, not a mandatory, one." 365 U.S., at 191. A review of the legislative history of the Dictionary Act shows this conclusion to be incorrect.

There is no express reference in the legislative history to the definition of "person," but Senator Trumbull, the Act's sponsor, discussed the phrase "words importing the masculine gender _may_ be applied to. females," (emphasis added), which immediately precedes the definition of "person," and stated:

"The only object \[of the Act] is to get rid of a great deal of verbosity in our statutes by providing that when the word \`he' is used it _shall_ include females as well as males." Cong. Globe, 41st Cong., 3d Sess., 775 (1871) (emphasis added).

Thus, in Trumbull's view the word "may" meant "shall." Such a mandatory use of the extended meanings of the words defined by the Act is also required for it to perform its intended functionto be a guide to "rules of construction" of Acts of Congress. See _ibid._ (remarks of Sen. Trumbull). Were the defined words "allowable, \[but] not mandatory" constructions, as _Monroe_ suggests, there would be no "rules" at all. Instead, Congress must have intended the definitions of the Act to apply across-the-board except where the Act by its terms called for a deviation from this practice"\[where] the context shows that \[defined] words were to be used in a more limited sense." Certainly this is how the _Northwestern Fertilizing_ court viewed the matter. Since there is nothing in the "context" of § 1 of the Civil Rights Act calling for a restricted interpretation of the word "person," the language of that section should prima facie be construed to include "bodies politic" among the entities that could be sued.

\[54] There is certainly no constitutional impediment to municipal liability. "The Tenth Amendment's reservation of nondelegated powers to the States is not implicated by a federal-court judgment enforcing the express prohibitions of unlawful state conduct enacted by the Fourteenth Amendment." _Milliken_ v. _Bradley,_ [433 U.S. 267](https://www.courtlistener.com/opinion/109723/milliken-v-bradley/), 291 (1977); see _Ex parte Virginia,_ 100 U. S., at 347-348. For this reason, _National League of Cities_ v. _Usery,_ [426 U.S. 833 ](https://www.courtlistener.com/opinion/109499/national-league-of-cities-v-usery/)(1976), is irrelevant to our consideration of this case. Nor is there any basis for concluding that the Eleventh Amendment is a bar to municipal liability. See, _e. g., Fitzpatrick_ v. _Bitzer,_ [427 U.S. 445](https://www.courtlistener.com/opinion/109520/fitzpatrick-v-bitzer/), 456 (1976); _Lincoln County_ v. _Luning,_ [133 U.S. 529](https://www.courtlistener.com/opinion/92688/lincoln-county-v-luning/), 530 (1890). Our holding today is, of course, limited to local government units which are not considered part of the State for Eleventh Amendment purposes.

\[55] Since official-capacity suits generally represent only another way of pleading an action against an entity of which an officer is an agentat least where Eleventh Amendment considerations do not control analysis our holding today that local governments can be sued under § 1983 necessarily decides that local government officials sued in their official capacities are "persons" under § 1983 in those cases in which, as here, a local government would be suable in its own name.

\[56] See also Mr. Justice Frankfurter's statement for the Court in _Nashville, C. & St. L. R. Co._ v. _Browning,_ [310 U.S. 362](https://www.courtlistener.com/opinion/103360/nashville-c-st-lr-co-v-browning/), 369 (1940):

"It would be a narrow conception of jurisprudence to confine the notion of \`laws' to what is found written on the statute books, and to disregard the gloss which life has written upon it. Settled state practice . . . can establish what is state law. The Equal Protection Clause did not write an empty formalism into the Constitution. Deeply embedded traditional ways of carrying out state policy, such as those of which petitioner complains, are often tougher and truer law than the dead words of the written text."

\[57] Support for such a conclusion can be found in the legislative history. As we have indicated, there is virtually no discussion of § 1 of the Civil Rights Act. Again, however, Congress' treatment of the Sherman amendment gives a clue to whether it would have desired to impose _respondeat superior_ liability.

The primary constitutional justification for the Sherman amendment was that it was a necessary and proper remedy for the failure of localities to protect citizens as the Privileges or Immunities Clause of the Fourteenth Amendment required. See _supra,_ at 670-673. And according to Sherman, Shellabarger, and Edmunds, the amendment came into play only when a locality was at fault or had knowingly neglected its duty to provide protection. See Globe 761 (Sen. Sherman); _id.,_ at 756 (Sen. Edmunds); _id.,_ at 751-752 (Rep. Shellabarger). But other proponents of the amendment apparently viewed it as a form of vicarious liability for the unlawful acts of the citizens of the locality. See _id.,_ at 792 (Rep. Butler). And whether intended or not, the amendment as drafted did impose a species of vicarious liability on municipalities since it could be construed to impose liability even if a municipality did not know of an impending or ensuing riot or did not have the wherewithal to do anything about it. Indeed, the amendment held a municipality liable even if it had done everything in its power to curb the riot. See _supra,_ at 668; Globe 761 (Sen. Stevenson); _id.,_ at 771 (Sen. Thurman); _id.,_ at 788 (Rep. Kerr); _id.,_ at 791 (Rep. Willard). While the first conference substitute was rejected principally on constitutional grounds, see _id.,_ at 804 (Rep. Poland), it is plain from the text of the second conference substitutewhich limited liability to those who, having the power to intervene against Ku Klux Klan violence, "neglect\[ed] or refuse\[d] so to do," see Appendix to this opinion, _infra,_ at 704, and which was enacted as § 6 of the 1871 Act and is now codified as 42 U.S. C. § 1986that Congress also rejected those elements of vicarious liability contained in the first conference substitute even while accepting the basic principle that the inhabitants of a community were bound to provide protection against the Ku Klux Klan. Strictly speaking, of course, the fact that Congress refused to impose vicarious liability for the wrongs of a few private citizens does not conclusively establish that it would similarly have refused to impose vicarious liability for the torts of a municipality's employees. Nonetheless, when Congress' rejection of the only form of vicarious liability presented to it is combined with the absence of any language in § 1983 which can easily be construed to create _respondeat superior_ liability, the inference that Congress did not intend to impose such liability is quite strong.

\[58] A third justification, often cited but which on examination is apparently insufficient to justify the doctrine of _respondeat superior,_ see, _e. g.,_ 2 F. Harper & F. James, § 26.3, is that liability follows the right to control the actions of a tortfeasor. By our decision in _Rizzo_ v. _Goode,_ [423 U.S. 362 ](https://www.courtlistener.com/opinion/109349/rizzo-v-goode/)(1976), we would appear to have decided that the mere right to control without any control or direction having been exercised and without any failure to supervise is not enough to support § 1983 liability. See [423 U.S., at 370-371](https://www.courtlistener.com/opinion/109349/rizzo-v-goode/).

\[59] Each case cited by _Monroe,_ see 365 U.S., at 191 n. 50, as consistent with the position that local governments were not § 1983 "persons" reached its conclusion by assuming that state-law immunities overrode the § 1983 cause of action. This has never been the law.

\[60] Although many suits against school boards also include private individuals as parties, the "principal defendant is usually the local board of education or school board." _Milliken_ v. _Bradley,_ 433 U. S., at 292-293 (POWELL, J., concurring in judgment).

\[61] _Moor_ v. _County of Alameda,_ [411 U.S. 693 ](https://www.courtlistener.com/opinion/108782/moor-v-county-of-alameda/)(1973); _City of Kenosha_ v. _Bruno,_ [412 U.S. 507 ](https://www.courtlistener.com/opinion/108813/kenosha-v-bruno/)(1973); _Aldinger_ v. _Howard,_ [427 U.S. 1 ](https://www.courtlistener.com/opinion/109503/aldinger-v-howard/)(1976).

\[62] During the heyday of the furor over busing, both the House and the Senate refused to adopt bills that would have removed from the federal courts jurisdiction

"to make any decision, enter any judgment, or issue any order requiring any _school board_ to make any change in the racial composition of the student body at any public school or in any class at any public school to which students are assigned in conformity with a freedom of choice system, or requiring any _school board_ to transport any students from one public school to another public school or from one place to another place or from one school district to another school district in order to effect a change in the racial composition of the student body at any school or place or in any school district, or denying to any student the right or privilege of attending any public school or class at any public school chosen by the parent of such student in conformity with a freedom of choice system, or requiring any _school board_ to close any school and transfer the students from the closed school to any other school for the purpose of altering the racial composition of the student body at any public school, or precluding any _school board_ from carrying into effect any provision of any contract between it and any member of the faculty of any public school it operates specifying the public school where the member of the faculty is to perform his or her duties under the contract." S. 1737, 93d Cong., 1st Sess., § 1207 (1973) (emphasis added).

Other bills designed either completely to remove the federal courts from the school desegregation controversy, S. 287, 93d Cong., 1st Sess. (1973), or to limit the ability of federal courts to subject school boards to remedial orders in desegregation cases, S. 619, 93d Cong., 1st Sess. (1973); S. 179, 93d Cong., 1st Sess., § 2 (a) (1973); H. R. 13534, 92d Cong., 2d Sess., § 1 (1972), have similarly failed.

\[63] In 1972, spurred by a finding "that the process of eliminating or preventing minority group isolation and improving the quality of education for all children often involves the expenditure of additional funds to which local educational agencies do not have access," 86 Stat. 354, 20 U.S. C. § 1601 (a) (1976 ed.), Congress passed the Emergency School Aid Act. Section 706 (a) (1) (A) (i) of that Act, 20 U.S. C. § 1605 (a) (1) (A) (i) (1976 ed.), authorizes the Assistant Secretary

"to make a grant to, or a contract with, _a local educational agency \[w]hich is implementing a plan . . . which has been undertaken pursuant to a final_ _order issued by a court of the United States_ . . . which requires the desegregation of minority group segregated children or faculty in the elementary and secondary schools of such agency, or otherwise requires the elimination or reduction of minority group isolation in such schools." (Emphasis added.)

A "local educational agency" is defined by 20 U.S. C. § 1619 (8) (1976 ed.) as "a public board of education or other public authority legally constituted within a State for either administrative control or direction of, public elementary or secondary schools in a city, county, township, school district, or other political subdivision of a State, or a federally recognized Indian reservation, or such combination of school districts, or counties as are recognized in a State as an administrative agency for its public elementary or secondary schools, or a combination of local educational agencies . . . ." Congress thus clearly recognized that school boards were often parties to federal school desegregation suits. In § 718 of the Act, 86 Stat. 369, 20 U.S. C. § 1617 (1976 ed.), Congress gave its explicit approval to the institution of federal desegregation suits against school boardspresumably under § 1983. Section 718 provides:

"Upon the entry of a final order _by a court of the United States against a local educational agency_ . . . for discrimination on the basis of race, color, or national origin in violation of . . . the fourteenth amendment to the Constitution of the United States . . . the court . . . may allow the prevailing party, other than the United States, a reasonable attorney's fee as part of the costs." (Emphasis added.)

Two years later in the Equal Educational Opportunities Act of 1974, Congress found that "the implementation of desegregation plans that require extensive student transportation has, in many cases, required _local educational agencies_ to expend large amounts of funds, thereby depleting their financial resources . . . ." 20 U.S. C. § 1702 (a) (3) (1976 ed.). (Emphasis added.) Congress did not respond by declaring that school boards were not subject to suit under § 1983 or any other federal statute, "but simply \[legislated] revised evidentiary standards and remedial priorities to be employed by the courts in deciding such cases." Brief for National Education Assn. et al. as _Amici Curiae_ 15-16. Indeed, Congress expressly reiterated that a cause of action, cognizable in the federal courts, exists for discrimination in the public school context. 20 U.S. C. §§ 1703, 1706, 1708, 1710, 1718 (1976 ed.). The Act assumes that school boards will usually be the defendants in such suits. For example, § 211 of the Act, 88 Stat. 516, as set forth in 20 U.S. C. § 1710 (1976 ed.), provides:

"The Attorney General shall not institute a civil action under section 1706 of this title \[which allows for suit by both private parties and the Attorney General to redress discrimination in public education] before he

"(a) gives to the appropriate educational agency notice of the condition or conditions which, in his judgment, constitute a violation of part 2 \[the prohibitions against discrimination in public education]." Section 219 of the Act, 20 U.S. C. § 1718 (1976 ed.), provides for the termination of court-ordered busing "if the court finds the defendant educational agency has satisfied the requirements of the fifth or fourteenth amendments to the Constitution, whichever is applicable, and will continue to be in compliance with the requirements thereof."

\[64] Whether Congress' attempt is in fact effective is the subject of _Hutto_ v. _Finney,_ O. T. 1977, No. 76-1660, cert. granted, 434 U.S. 901, and therefore we express no view on it here.

\[65] We note, however, that Mr. Justice Harlan's test has not been expressly adopted by this Court. Moreover, that test is based on two factors: _stare decisis_ and "indications of congressional acceptance of this Court's earlier interpretation \[of the statute in question]." 365 U.S., at 192. As we have explained, the second consideration is not present in this case.

\[66] No useful purpose would be served by an attempt at this late date to determine whether _Monroe_ was correct on its facts. Similarly, since this case clearly involves official policy and does not involve _respondeat superior,_ we do not assay a view on how our cases which have relied on that aspect of _Monroe_ that is overruled today&#x97;_&#x4D;oor_ v. _County of Alameda,_ [411 U.S. 693 ](https://www.courtlistener.com/opinion/108782/moor-v-county-of-alameda/)(1973); _City of Kenosha_ v. _Bruno,_ [412 U.S. 507 ](https://www.courtlistener.com/opinion/108813/kenosha-v-bruno/)(1973); and _Aldinger_ v. _Howard,_ [427 U.S. 1 ](https://www.courtlistener.com/opinion/109503/aldinger-v-howard/)(1976)should have been decided on a correct view of § 1983. Nothing we say today affects the conclusion reached in _Moor,_ see 411 U.S., at 703-704, that 42 U.S. C. § 1988 cannot be used to create a federal cause of action where § 1983 does not otherwise provide one, or the conclusion reached in _City of Kenosha,_ see 412 U.S., at 513, that "nothing . . . suggest\[s] that the generic word \`person' in § 1983 was intended to have a bifurcated application to municipal corporations depending on the nature of the relief sought against them."

[^1]: [365 U.S. 167 ](https://www.courtlistener.com/opinion/106170/monroe-v-pape/)(1961)

[^2]: &#x20;[532 F.2d 259](https://www.courtlistener.com/opinion/334135/12-fair-emplpraccas-836-11-empl-prac-dec-p-10755-jane-monell-v/), 263 (1976)

[^3]: [532 F.2d, at 264](https://www.courtlistener.com/opinion/334135/12-fair-emplpraccas-836-11-empl-prac-dec-p-10755-jane-monell-v/)

[^4]: [365 U.S., at 187](https://www.courtlistener.com/opinion/106170/monroe-v-pape/)

[^5]: [398 U.S. 144](https://www.courtlistener.com/opinion/108153/adickes-v-sh-kress-co/), 167-168 (1970)

[^6]: See _Rizzo_ v. _Goode,_ [423 U.S. 362](https://www.courtlistener.com/opinion/109349/rizzo-v-goode/), 370-371 (1976)

[^7]: [365 U.S., at 221-222 ](https://www.courtlistener.com/opinion/106170/monroe-v-pape/)(dissenting in part)

[^8]: _Scheuer_ v. _Rhodes,_ [416 U.S. 232](https://www.courtlistener.com/opinion/109009/scheuer-v-rhodes/), 248 (1974). Cf. _Bivens_ v. _Six Unknown Fed. Narcotics Agents,_ [403 U.S. 388](https://www.courtlistener.com/opinion/108375/bivens-v-six-unknown-fed-narcotics-agents/), 397-398 (1971).
