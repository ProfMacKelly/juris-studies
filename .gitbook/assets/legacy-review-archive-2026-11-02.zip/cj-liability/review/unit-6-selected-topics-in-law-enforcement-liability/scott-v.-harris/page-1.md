> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Justice Liability Law: A Sourcebook](https://profmackelly.gitbook.io/cj-liability/selected-topics-in-law-enforcement-liability/scott-v.-harris/page-1) · Snapshot: 2026-11-02 · Original path: `selected-topics-in-law-enforcement-liability/scott-v.-harris/page-1`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-law/page-1)

---

# Page 1

I'm not agreeing or disagreeing with the outcome with these comments, but I'm not sure that your description of the dissent is entirely representative (i.e., "The dissenting opinion focused more on the fact that Harris was badly injured, becoming paralyzed.)

As the dissent noted, the majority points out that the majority was engaging in some degree of speculation about what Harris would have done had the officers not given chase for such an insignificant offense in the first place (going 73 in a 55 zone).

Also, what did the video actually show? Here's the dissent: " At no point during the chase did respondent pull into the opposite lane other than to pass a car in front of him; he did the latter no more than five times and, on most of those occasions, used his turn signal. On none of these occasions was there a car traveling in the opposite direction. In fact, at one point, when respondent found himself behind a car in his own lane and there were cars traveling in the other direction, he slowed and waited for the cars traveling in the other direction to pass before overtaking the car in front of him while using his turn signal to do so. This is hardly the stuff of Hollywood. To the contrary, the video does not reveal any incidents that could even be remotely characterized as 'close calls.'”

The dissent also observed that the only "innocent bystanders" were cars that were already pulled off the road because of the sirens, and there were no pedestrians, parked cars, sidewalks, or residences visible on the video.

Another point that the dissent made was that appeals courts such as this are not supposed to make factual decisions; the court shouldn't have looked at the video in the first place. This is a factual circumstance that should have been assessed by a jury. And a jury in this case would have been picked from people who would likely be familiar with this stretch of road and would be in a better place to assess the video, not 9 people who know nothing but what's on this dark, grainy video.

At least, these are some consideration to evaluate.

<br>
