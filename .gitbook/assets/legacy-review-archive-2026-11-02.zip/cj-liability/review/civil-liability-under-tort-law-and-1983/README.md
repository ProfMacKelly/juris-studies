> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Justice Liability Law: A Sourcebook](https://profmackelly.gitbook.io/cj-liability/civil-liability-under-tort-law-and-1983) · Snapshot: 2026-11-02 · Original path: `civil-liability-under-tort-law-and-1983`

---

# Civil Liability under Tort Law and § 1983

