# Snippets - Attributions

#### General Attributions & Licensing

<details>

<summary>Attributions and Licensing</summary>

Except where otherwise noted, this page's content is adapted from [Sources and Types of Law](app://obsidian.md/Bookshelves/Civil_Law/Business_Law_I_Essentials_\(OpenStax\)/01:_American_Law_Legal_Reasoning_and_the_Legal_System/1.03:_Sources_and_Types_of_Law) in [_Business Law I Essentials_ ](app://obsidian.md/Bookshelves/Civil_Law/Business_Law_I_Essentials_\(OpenStax\)/01:_American_Law_Legal_Reasoning_and_the_Legal_System/1.03:_Sources_and_Types_of_Law)by Mirande Valbrune and Renee De Assis ([OpenStax](https://openstax.org/), 2019), used under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). This page is licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). <img src="https://files.gitbook.com/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FX7KyXZptCmBnyJBn0ocw%2Fuploads%2FsC0H3i5DKWLdoOKEIY7l%2FCC%20BY%20NC%20SA%20badge.png?alt=media&#x26;token=9d010a86-960f-4d15-9c98-aa8945b9764e" alt="undefined" data-size="line">

Except where otherwise noted, this page's content is adapted from [What is Law and What Functions Does It Serve ](https://pressbooks.pub/introductiontobusinesslaw/chapter/chapter-1/)in [_Fundamentals of Business Law_ ](https://pressbooks.pub/introductiontobusinesslaw/)by Melissa Randall (2020), used under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). This page is licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). <img src="https://files.gitbook.com/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FX7KyXZptCmBnyJBn0ocw%2Fuploads%2FsC0H3i5DKWLdoOKEIY7l%2FCC%20BY%20NC%20SA%20badge.png?alt=media&#x26;token=9d010a86-960f-4d15-9c98-aa8945b9764e" alt="undefined" data-size="line">

The definition of _Term_ is derived or otherwise adapted from the [_Wex Legal Encyclopedia_ ](https://www.law.cornell.edu/wex)by Cornell Law School Legal Information Institute, under [CC BY-NC-SA 2.5](https://creativecommons.org/licenses/by-nc-sa/2.5/). <img src="https://files.gitbook.com/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FX7KyXZptCmBnyJBn0ocw%2Fuploads%2FsC0H3i5DKWLdoOKEIY7l%2FCC%20BY%20NC%20SA%20badge.png?alt=media&#x26;token=9d010a86-960f-4d15-9c98-aa8945b9764e" alt="undefined" data-size="line">

</details>

#### Case Attributions

<details>

<summary>Editorial Notes, Attributions, and Licensing</summary>

This page's content is adapted from the following source(s): [2.5: Chapter 6 - Probable Cause and Reasonable Suspicion](https://biz.libretexts.org/Workbench/Criminal_Procedure/05%3A_The_Fourth_Amendment/5.05%3A_Chapter_6_-_Probable_Cause_and_Reasonable_Suspicion) by [Anne M Alexander](https://law.missouri.edu/directory/anne-alexander/) and [Ben Trachtenberg](https://law.missouri.edu/directory/ben-trachtenberg/), in [_Criminal Procedure: A Free Law School Casebook 2e_](https://biz.libretexts.org/Bookshelves/Criminal_Law/Criminal_Procedure%3A_A_Free_Law_School_Casebook_2e_\(Alexander_and_Trachtenberg\)), used under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Additional modifications and annotations may have been here.

Many of the court's original citations to authorities and other content may have been omitted for length and readability purposes. Many elisions are not identified, particularly string citations and original footnotes when not materially necessary to the subject of the lesson. However, some elisions are identified by bracketed ellipses (e.g., \[...]).

Subject to the following, this page is licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/): Judicial decisions and annotations thereto are not subject to copyright protection and are in the public domain. _See, e.g., Georgia v. Public.Resource.Org, Inc_., [140 S. Ct. 1498](https://scholar.google.com/scholar_case?case=8288711378870515248\&q=Georgia+et+al.+v.+Public.Resource.Org,+Inc.\&hl=en\&as_sdt=6,50) (2020).

</details>

#### Cases (My Edits) & Public Domain

<details>

<summary>Editorial Notes and Licensing</summary>

Editing to the original by Matthew L. Mac Kelly. Many of the court's original citations to authorities and other content may have been omitted for length and readability purposes. Many elisions of text are not identified, particularly string citations and original footnotes when not materially necessary to the purpose of this portion of the sourcebook. However, some elisions are identified by bracketed ellipses (e.g., \[...]).

Judicial decisions and annotations thereto by third parties are not subject to copyright protection and are in the public domain. _See, e.g., Georgia v. Public.Resource.Org, Inc_., [140 S. Ct. 1498](https://scholar.google.com/scholar_case?case=8288711378870515248\&q=Georgia+et+al.+v.+Public.Resource.Org,+Inc.\&hl=en\&as_sdt=6,50) (2020).

Note: Hyperlinks within this case are not original. Some of these hyperlinks (such as cases and footnotes) may direct you to an external publicly accessible display of the case. This is helpful for reference purposes, and no copyright is claimed here over a third party's hyperlinking choices and methodologies, if applicable.

Subject to limitations above, if any, this page is in the public domain.  [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) <img src="broken-reference" alt="" data-size="line">

</details>

#### Public Domain

<details>

<summary>License</summary>

This page is dedicated to the public domain. [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) <img src="broken-reference" alt="" data-size="line">&#x20;

</details>

#### Mine

<details>

<summary>License</summary>

This page by Matthew L. Mac Kelly is licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/?ref=chooser-v1), except where otherwise noted. <img src="broken-reference" alt="" data-size="line">

</details>

***

#### Creative Commons

[Wiki](https://en.wikipedia.org/wiki/Creative_Commons_license)
