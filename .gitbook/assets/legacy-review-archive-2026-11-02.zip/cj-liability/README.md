# Criminal Justice Liability Law: A Sourcebook — Legacy Review Archive

> REVIEW ARCHIVE. Juris Studies is the main version. These snapshots are retained for editorial comparison, not as the approved teaching version.

Snapshot date: 2026-11-02. Source space: `Iidgz8oVybO8YdnFwIF5`. Source revision: `68howmwNqQGyWCUmNP6y`.

Legacy site: https://profmackelly.gitbook.io/cj-liability/

The originals/ folder contains the exact Markdown returned by the pinned GitBook revision. These are API Markdown snapshots, not byte-for-byte exports of repository files. The review/ folder contains the same text with resolvable legacy-relative links made absolute and a source/review notice added. Footnotes, attributions and conflict text remain present. Media stays linked to the existing public source URLs; binary media is not bundled.

pages.csv lists all retained readings, original visibility, the comparison classification and possible Juris Studies counterparts. Candidate counterparts are aids for human review. No title match does not prove a topic is missing or unique.

## Readings

- [This Sourcebook and How to Use It](review/README.md) — no-title-match
- [Your Obligation to Know the Law](review/your-obligation-to-know-the-law.md) — no-title-match
- [Preparing to Understand Legal Thinking and Studying Case Law](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/README.md) — no-title-match
- [Primers on Legal Thinking, Reasoning & Analysis](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/README.md) — no-title-match
- [Introduction to Deductive (Rule-Based) Reasoning](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/introduction-to-deductive-rule-based-reasoning.md) — different-review
- [Introduction to Analogical Reasoning—A Type of Inductive Reasoning](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/introduction-to-analogical-reasoning-a-type-of-inductive-reasoning.md) — different-review
- [Is a Hot Dog a Sandwich?](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/is-a-hot-dog-a-sandwich.md) — different-review
- [Avoid Bald Assertions](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/avoid-bald-assertions.md) — different-review
- [How to Read a Case](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/how-to-read-a-case.md) — different-review
- [Annotated Cases & Annotated Examples of Case Briefs](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/README.md) — different-review
- [Annotated Case: Florida v. Jardines](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-1-florida-v.-jardines/annotated-case-florida-v.-jardines.md) — different-review
- [Annotated Case Brief: Florida v. Jardines](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-1-florida-v.-jardines/annotated-case-brief-florida-v.-jardines.md) — different-review
- [Annotated Case: Mills v. City of Overland Park](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park/annotated-case-mills-v.-city-of-overland-park.md) — different-review
- [Annotated Case Brief: Mills v. City of Overland Park](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park/annotated-case-brief-mills-v.-city-of-overland-park.md) — different-review
- [Annotated Case: Malley v. Briggs](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs/annotated-case-malley-v.-briggs.md) — different-review
- [Annotated Case Brief: Malley v. Briggs](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs/annotated-case-brief-malley-v.-briggs.md) — different-review
- [Model Brief for "Brief the Case" Exercise](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/brief-the-case-exercise/model-brief-for-brief-the-case-exercise.md) — different-review
- [Civil Liability under Tort Law and § 1983](review/civil-liability-under-tort-law-and-1983/README.md) — no-title-match
- [Mills v. City of Overland Park](review/civil-liability-under-tort-law-and-1983/mills-v.-city-of-overland-park.md) — different-review
- [Govea v. City of Norcross](review/civil-liability-under-tort-law-and-1983/govea-v.-city-of-norcross.md) — different-review
- [Strickland v. University of North Carolina](review/civil-liability-under-tort-law-and-1983/strickland-v.-university-of-north-carolina.md) — different-review
- [Defenses to Civil Litigation and Risk Management](review/unit-4-defenses-to-civil-litigation-and-risk-management/README.md) — no-title-match
- [Absolute and Qualified Immunity, Generally](review/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/README.md) — no-title-match
- [Cleavinger v. Saxner](review/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/cleavinger-v.-saxner.md) — different-review
- [Procunier v. Navarette](review/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/procunier-v.-navarette.md) — different-review
- [Anderson v. Creighton](review/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/anderson-v.-creighton.md) — different-review
- [Estate of Cavanaugh v. Andrade](review/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/estate-of-cavanaugh-v.-andrade.md) — different-review
- [Malley v. Briggs](review/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/good-faith-defense/malley-v.-briggs.md) — different-review
- [Daye v. City of Albany](review/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/good-faith-defense/daye-v.-city-of-albany.md) — different-review
- [Monell v. Dept. of Social Services](review/unit-5-vicarious-liability-principles/monell-v.-dept.-of-social-services.md) — different-review
- [Forrest v. Parry](review/unit-5-vicarious-liability-principles/forrest-v.-parry.md) — different-review
- [Clipper v. Takoma Park](review/unit-5-vicarious-liability-principles/clipper-v.-takoma-park.md) — different-review
- [Graham v. Connor](review/unit-6-selected-topics-in-law-enforcement-liability/graham-v.-connor.md) — different-review
- [Wilson v. City of Lafayette](review/unit-6-selected-topics-in-law-enforcement-liability/wilson-v.-city-of-lafayette.md) — different-review
- [Scott v. Harris](review/unit-6-selected-topics-in-law-enforcement-liability/scott-v.-harris/README.md) — different-review
- [Page 1](review/unit-6-selected-topics-in-law-enforcement-liability/scott-v.-harris/page-1.md) — different-review — originally hidden
- [Bonenberger v. Plymouth Township](review/unit-8-other-administrative-liability-issues/bonenberger-v.-plymouth-township.md) — different-review
- [Mys v. Michigan Dept. of State Police](review/unit-8-other-administrative-liability-issues/mys-v.-michigan-dept.-of-state-police.md) — different-review
- [Snippets - Attributions](review/snippets-attributions.md) — no-title-match — originally hidden