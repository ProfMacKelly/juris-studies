# Example 3: Malley v. Briggs

<table data-view="cards"><thead><tr><th></th></tr></thead><tbody><tr><td><a href="example-3-malley-v.-briggs/annotated-case-malley-v.-briggs"><strong>Annotated Case:</strong> <em>Malley v. Briggs</em></a></td></tr><tr><td><a href="example-3-malley-v.-briggs/annotated-case-brief-malley-v.-briggs"><strong>Annotated Case Brief:</strong> <em>Malley v. Briggs</em></a></td></tr></tbody></table>
