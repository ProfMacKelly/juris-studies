# Annotated Cases & Annotated Examples of Case Briefs

In this section:

* Read and compare three cases with the example case briefs, and
* Examine the explanatory/instructional annotations provided within the example case briefs.

Here are the three examples:

<table data-view="cards"><thead><tr><th></th><th></th><th></th><th data-hidden data-card-target data-type="content-ref"></th></tr></thead><tbody><tr><td>Example 1: <a href="https://github.com/ProfMacKelly/Intro-to-Law/blob/main/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-1-flordia-v.-jardines"><em><mark style="color:blue;"><strong>Florida v. Jardines</strong></mark></em></a></td><td></td><td></td><td></td></tr><tr><td>Example 2: <a href="https://github.com/ProfMacKelly/Intro-to-Law/blob/main/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park"><em><mark style="color:blue;"><strong>Mills v. City of Overland Park</strong></mark></em></a></td><td></td><td></td><td></td></tr><tr><td>Example 3: <a href="https://github.com/ProfMacKelly/Intro-to-Law/blob/main/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs"><em><mark style="color:blue;"><strong>Malley v. Briggs</strong></mark></em></a></td><td></td><td></td><td></td></tr></tbody></table>
