# Example 2: Mills v. City of Overland Park

<table data-view="cards"><thead><tr><th></th></tr></thead><tbody><tr><td><a href="example-2-mills-v.-city-of-overland-park/annotated-case-mills-v.-city-of-overland-park"><strong>Annotated Case:</strong> <em>Mills v. City of Overland Park</em></a></td></tr><tr><td><a href="example-2-mills-v.-city-of-overland-park/annotated-case-brief-mills-v.-city-of-overland-park"><strong>Annotated Case:</strong> <em>Mills v. City of Overland Park</em></a></td></tr></tbody></table>
