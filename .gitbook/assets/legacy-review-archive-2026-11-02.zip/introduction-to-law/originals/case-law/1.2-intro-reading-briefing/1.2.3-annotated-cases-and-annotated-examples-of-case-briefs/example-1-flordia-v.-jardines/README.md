# Example 1: Flordia v. Jardines

<table data-view="cards"><thead><tr><th></th></tr></thead><tbody><tr><td><a href="example-1-flordia-v.-jardines/annotated-case-florida-v.-jardines"><strong>Annotated Case:</strong> <em>Florida v. Jardines</em></a></td></tr><tr><td><a href="example-1-flordia-v.-jardines/annotated-case-brief-florida-v.-jardines"><strong>Annotated Case Brief:</strong> <em>Florida v. Jardines</em></a></td></tr></tbody></table>
