# Exercise: Brief the Case

Prepare a case brief for [_Estate of Cavanaugh v. Andrade_](1.3-brief-the-case-exercise/estate-of-cavanaugh-v.-andrade)_._
