# The United States Court System

{% hint style="success" %}
**LEARNING OBJECTIVES**

1. Understand the core principles of the topic.
2. Apply learned concepts in practical scenarios.
3. Analyze and evaluate outcomes effectively.
4. Foster critical thinking and problem-solving skills.
5. Collaborate and communicate within a team setting.
6. Understand the US court system and how it affects the conduct of businesses.
7. Understand the three branches of government and how they check and balance each other’s powers.
8. Explore the state and federal court systems.
{% endhint %}

## Contents

{% stepper %}
{% step %}
{% content-ref url="https://github.com/ProfMacKelly/Intro-to-Law/blob/main/the-united-states-court-system/introduction.md" %}
[https://github.com/ProfMacKelly/Intro-to-Law/blob/main/the-united-states-court-system/introduction.md](https://github.com/ProfMacKelly/Intro-to-Law/blob/main/the-united-states-court-system/introduction.md)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="https://github.com/ProfMacKelly/Intro-to-Law/blob/main/the-united-states-court-system/separation-of-powers.md" %}
[https://github.com/ProfMacKelly/Intro-to-Law/blob/main/the-united-states-court-system/separation-of-powers.md](https://github.com/ProfMacKelly/Intro-to-Law/blob/main/the-united-states-court-system/separation-of-powers.md)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="https://github.com/ProfMacKelly/Intro-to-Law/blob/main/the-united-states-court-system/federalism.md" %}
[https://github.com/ProfMacKelly/Intro-to-Law/blob/main/the-united-states-court-system/federalism.md](https://github.com/ProfMacKelly/Intro-to-Law/blob/main/the-united-states-court-system/federalism.md)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="https://github.com/ProfMacKelly/Intro-to-Law/blob/main/the-united-states-court-system/trial-and-appellate-courts.md" %}
[https://github.com/ProfMacKelly/Intro-to-Law/blob/main/the-united-states-court-system/trial-and-appellate-courts.md](https://github.com/ProfMacKelly/Intro-to-Law/blob/main/the-united-states-court-system/trial-and-appellate-courts.md)
{% endcontent-ref %}
{% endstep %}
{% endstepper %}
