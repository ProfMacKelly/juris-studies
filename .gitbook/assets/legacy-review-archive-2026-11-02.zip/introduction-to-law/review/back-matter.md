> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Introduction to Law and the Courts](https://profmackelly.gitbook.io/introduction-to-law/back-matter) · Snapshot: 2026-11-02 · Original path: `back-matter`

---

# Back Matter

{% content-ref url="https://profmackelly.gitbook.io/introduction-to-law/glossary" %}
[glossary](https://profmackelly.gitbook.io/introduction-to-law/glossary)
{% endcontent-ref %}
