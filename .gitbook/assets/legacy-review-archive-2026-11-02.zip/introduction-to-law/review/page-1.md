> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Introduction to Law and the Courts](https://profmackelly.gitbook.io/introduction-to-law/page-1) · Snapshot: 2026-11-02 · Original path: `page-1`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-law/page-1)

---

# Page 1

[Attribution Snippets](https://app.gitbook.com/o/2KDFCqgo3cAQVrPSYfS9/s/gb3latek59GhBxzDZlwy/)

[**Glossary from Libretexts**](https://biz.libretexts.org/Courses/Concordia_University_Wisconsin/JPP_207_Substantive_Criminal_Law/zz%3A_Back_Matter/20%3A_Glossary)

### Quiz

{% embed url="https://profmackelly.github.io/resources-h5p/embedcode.html" %}

{% embed url="https://forms.gle/VQUaQhBTjE3hJBhr6" %}

{% embed url="https://forms.office.com/r/evmee7JkNX" %}

{% @lucid/lucid-component url="https://lucid.app/lucidchart/9a58914f-5a99-4816-b656-81ba9f18a7e1/edit?invitationId=inv_0aceba08-0777-4440-b4c3-b48ebafcf3e2&viewport_loc=-1090,97,1657,732,0_0" %}
