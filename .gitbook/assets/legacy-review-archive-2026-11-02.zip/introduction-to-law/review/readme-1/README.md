> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Introduction to Law and the Courts](https://profmackelly.gitbook.io/introduction-to-law/readme-1) · Snapshot: 2026-11-02 · Original path: `readme-1`

---

# Introduction to Law and the Courts

{% stepper %}
{% step %}
{% content-ref url="readme-1/law-and-its-functions" %}
[law-and-its-functions](readme-1/law-and-its-functions)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="readme-1/modern-legal-systems" %}
[modern-legal-systems](readme-1/modern-legal-systems)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="readme-1/basic-classifications-of-law" %}
[basic-classifications-of-law](readme-1/basic-classifications-of-law)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="readme-1/sources-of-law" %}
[sources-of-law](readme-1/sources-of-law)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="readme-1/court-system-overview" %}
[court-system-overview](readme-1/court-system-overview)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="readme-1/court-system-overview-1" %}
[court-system-overview-1](readme-1/court-system-overview-1)
{% endcontent-ref %}
{% endstep %}
{% endstepper %}
