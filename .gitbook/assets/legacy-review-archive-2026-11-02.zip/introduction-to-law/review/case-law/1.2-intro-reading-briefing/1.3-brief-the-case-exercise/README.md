> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Introduction to Law and the Courts](https://profmackelly.gitbook.io/introduction-to-law/case-law/1.2-intro-reading-briefing/1.3-brief-the-case-exercise) · Snapshot: 2026-11-02 · Original path: `case-law/1.2-intro-reading-briefing/1.3-brief-the-case-exercise`

---

# Exercise: Brief the Case

Prepare a case brief for [_Estate of Cavanaugh v. Andrade_](1.3-brief-the-case-exercise/estate-of-cavanaugh-v.-andrade)_._
