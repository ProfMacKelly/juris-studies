> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Introduction to Law and the Courts](https://profmackelly.gitbook.io/introduction-to-law/case-law/1.2-intro-reading-briefing/briefing-cases) · Snapshot: 2026-11-02 · Original path: `case-law/1.2-intro-reading-briefing/briefing-cases`

---

# Briefing Cases

