> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Introduction to Law and the Courts](https://profmackelly.gitbook.io/introduction-to-law/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-1-flordia-v.-jardines) · Snapshot: 2026-11-02 · Original path: `case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-1-flordia-v.-jardines`

---

# Example 1: Flordia v. Jardines

<table data-view="cards"><thead><tr><th></th></tr></thead><tbody><tr><td><a href="example-1-flordia-v.-jardines/annotated-case-florida-v.-jardines"><strong>Annotated Case:</strong> <em>Florida v. Jardines</em></a></td></tr><tr><td><a href="example-1-flordia-v.-jardines/annotated-case-brief-florida-v.-jardines"><strong>Annotated Case Brief:</strong> <em>Florida v. Jardines</em></a></td></tr></tbody></table>
