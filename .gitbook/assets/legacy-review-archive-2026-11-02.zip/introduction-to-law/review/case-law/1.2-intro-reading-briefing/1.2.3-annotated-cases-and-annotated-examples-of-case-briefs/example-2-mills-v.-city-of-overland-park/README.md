> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Introduction to Law and the Courts](https://profmackelly.gitbook.io/introduction-to-law/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park) · Snapshot: 2026-11-02 · Original path: `case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/primers/reading-briefing/annotated-cases-briefs/example-2-mills-v.-city-of-overland-park)

---

# Example 2: Mills v. City of Overland Park

<table data-view="cards"><thead><tr><th></th></tr></thead><tbody><tr><td><a href="example-2-mills-v.-city-of-overland-park/annotated-case-mills-v.-city-of-overland-park"><strong>Annotated Case:</strong> <em>Mills v. City of Overland Park</em></a></td></tr><tr><td><a href="example-2-mills-v.-city-of-overland-park/annotated-case-brief-mills-v.-city-of-overland-park"><strong>Annotated Case:</strong> <em>Mills v. City of Overland Park</em></a></td></tr></tbody></table>
