> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Introduction to Law and the Courts](https://profmackelly.gitbook.io/introduction-to-law/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs) · Snapshot: 2026-11-02 · Original path: `case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/primers/reading-briefing/annotated-cases-briefs/example-3-malley-v.-briggs)

---

# Example 3: Malley v. Briggs

<table data-view="cards"><thead><tr><th></th></tr></thead><tbody><tr><td><a href="example-3-malley-v.-briggs/annotated-case-malley-v.-briggs"><strong>Annotated Case:</strong> <em>Malley v. Briggs</em></a></td></tr><tr><td><a href="example-3-malley-v.-briggs/annotated-case-brief-malley-v.-briggs"><strong>Annotated Case Brief:</strong> <em>Malley v. Briggs</em></a></td></tr></tbody></table>
