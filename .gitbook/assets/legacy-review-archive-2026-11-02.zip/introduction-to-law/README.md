# Introduction to Law and the Courts — Legacy Review Archive

> REVIEW ARCHIVE. Juris Studies is the main version. These snapshots are retained for editorial comparison, not as the approved teaching version.

Snapshot date: 2026-11-02. Source space: `9CjktFRZwkqSgAs4K5y9`. Source revision: `jDNEpWEisV1Btl4mWR86`.

Legacy site: https://profmackelly.gitbook.io/introduction-to-law/

The originals/ folder contains the exact Markdown returned by the pinned GitBook revision. These are API Markdown snapshots, not byte-for-byte exports of repository files. The review/ folder contains the same text with resolvable legacy-relative links made absolute and a source/review notice added. Footnotes, attributions and conflict text remain present. Media stays linked to the existing public source URLs; binary media is not bundled.

pages.csv lists all retained readings, original visibility, the comparison classification and possible Juris Studies counterparts. Candidate counterparts are aids for human review. No title match does not prove a topic is missing or unique.

## Readings

- [Introduction to Law and the Courts Sourcebook](review/README.md) — different-review
- [Front Matter](review/front-matter.md) — different-review
- [Introduction to Law and the Courts](review/readme-1/README.md) — no-title-match
- [Law & Its Functions](review/readme-1/law-and-its-functions.md) — different-review
- [Modern Legal Systems](review/readme-1/modern-legal-systems.md) — different-review
- [Basic Classifications of Law](review/readme-1/basic-classifications-of-law.md) — different-review
- [Sources of Law](review/readme-1/sources-of-law.md) — different-review
- [Federalism](review/readme-1/court-system-overview.md) — different-review
- [Court System Overview](review/readme-1/court-system-overview-1.md) — different-review
- [Grand Jury](review/procedures-prior-to-trial/commencing-criminal-prosecutions/grand-jury.md) — no-title-match — originally hidden
- [The United States Court System](review/the-united-states-court-system/README.md) — different-review
- [Intro-reading-briefing](review/case-law/1.2-intro-reading-briefing/README.md) — no-title-match — originally hidden
- [Reading Cases](review/case-law/1.2-intro-reading-briefing/reading-cases/README.md) — no-title-match — originally hidden
- [Videos: Reading Cases](review/case-law/1.2-intro-reading-briefing/reading-cases/videos-reading-cases.md) — no-title-match — originally hidden
- [Briefing Cases](review/case-law/1.2-intro-reading-briefing/briefing-cases.md) — no-title-match — originally hidden
- [Annotated Cases & Annotated Examples of Case Briefs](review/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/README.md) — different-review — originally hidden
- [Example 1: Flordia v. Jardines](review/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-1-flordia-v.-jardines/README.md) — no-title-match — originally hidden
- [Annotated Case: Florida v. Jardines](review/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-1-flordia-v.-jardines/annotated-case-florida-v.-jardines.md) — different-review — originally hidden
- [Annotated Case Brief: Florida v. Jardines](review/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-1-flordia-v.-jardines/annotated-case-brief-florida-v.-jardines.md) — different-review — originally hidden
- [Example 2: Mills v. City of Overland Park](review/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park/README.md) — different-review — originally hidden
- [Annotated Case: Mills v. City of Overland Park](review/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park/annotated-case-mills-v.-city-of-overland-park.md) — different-review — originally hidden
- [Annotated Case Brief: Mills v. City of Overland Park](review/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park/annotated-case-brief-mills-v.-city-of-overland-park.md) — different-review — originally hidden
- [Example 3: Malley v. Briggs](review/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs/README.md) — different-review — originally hidden
- [Annotated Case: Malley v. Briggs](review/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs/annotated-case-malley-v.-briggs.md) — different-review — originally hidden
- [Annotated Case Brief: Malley v. Briggs](review/case-law/1.2-intro-reading-briefing/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs/annotated-case-brief-malley-v.-briggs.md) — different-review — originally hidden
- [Exercise: Brief the Case](review/case-law/1.2-intro-reading-briefing/1.3-brief-the-case-exercise/README.md) — no-title-match — originally hidden
- [Estate of Cavanaugh v. Andrade](review/case-law/1.2-intro-reading-briefing/1.3-brief-the-case-exercise/estate-of-cavanaugh-v.-andrade.md) — different-review — originally hidden
- [Model Brief for "Brief the Case" Exercise](review/case-law/1.2-intro-reading-briefing/1.3-brief-the-case-exercise/model-brief-for-brief-the-case-exercise.md) — different-review — originally hidden
- [Back Matter](review/back-matter.md) — no-title-match
- [Glossary](review/glossary.md) — different-review
- [Page 1](review/page-1.md) — different-review — originally hidden