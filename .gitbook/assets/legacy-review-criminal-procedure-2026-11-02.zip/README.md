# Criminal Procedure: A Sourcebook — Legacy Review Archive

> REVIEW ARCHIVE. Juris Studies is the main version. These snapshots are retained for editorial comparison, not as the approved teaching version.

Snapshot date: 2026-11-02. Source space: `6Bqz3QmhzbBYM9Y3OuYd`. Source revision: `Hj2UewnxGNpnPBvW4DqH`.

Legacy site: https://profmackelly.gitbook.io/criminal-procedure/

The originals/ folder contains the exact Markdown returned by the pinned GitBook revision. These are API Markdown snapshots, not byte-for-byte exports of repository files. The review/ folder contains the same text with resolvable legacy-relative links made absolute and a source/review notice added. Footnotes, attributions and conflict text remain present. Media stays linked to the existing public source URLs; binary media is not bundled.

pages.csv lists all retained readings, original visibility, the comparison classification and possible Juris Studies counterparts. Candidate counterparts are aids for human review. No title match does not prove a topic is missing or unique.

## Readings

- [Criminal Procedure Sourcebook](review/README.md) — no-title-match
- [Front Matter](review/front-matter.md) — different-review
- [Preparing to Understand Legal Thinking and Studying Case Law](review/preparing-to-understand-legal-thinking-and-studying-case-law/README.md) — no-title-match
- [Primers on Legal Thinking, Reasoning & Analysis](review/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis.md) — no-title-match
- [Introduction to Deductive (Rule-Based) Reasoning](review/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/introduction-to-deductive-rule-based-reasoning.md) — different-review
- [Introduction to Analogical Reasoning—A Type of Inductive Reasoning](review/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/introduction-to-analogical-reasoning-a-type-of-inductive-reasoning.md) — different-review
- [Is a Hot Dog a Sandwich?](review/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/is-a-hot-dog-a-sandwich.md) — different-review
- [Avoid Bald Assertions](review/preparing-to-understand-legal-thinking-and-studying-case-law/primers-on-legal-thinking-reasoning-and-analysis/avoid-bald-assertions.md) — different-review
- [Introduction to Reading & Briefing Cases](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/README.md) — different-review
- [How to Read a Case](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/how-to-read-a-case.md) — different-review
- [Case Briefing Tutorials](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/case-briefing-tutorials.md) — different-review
- [Annotated Cases & Annotated Examples of Case Briefs](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/README.md) — different-review
- [Example 1: Florida v. Jardines](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-1-florida-v.-jardines/README.md) — different-review
- [Annotated Case: Florida v. Jardines](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-1-florida-v.-jardines/annotated-case-florida-v.-jardines.md) — different-review
- [Annotated Case Brief: Florida v. Jardines](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-1-florida-v.-jardines/annotated-case-brief-florida-v.-jardines.md) — different-review
- [Example 2: Mills v. City of Overland Park](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park/README.md) — different-review
- [Annotated Case: Mills v. City of Overland Park](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park/annotated-case-mills-v.-city-of-overland-park.md) — different-review
- [Example 3: Malley v. Briggs](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs/README.md) — different-review
- [Annotated Case: Malley v. Briggs](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs/annotated-case-malley-v.-briggs.md) — different-review
- [Annotated Case Brief: Malley v. Briggs](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs/annotated-case-brief-malley-v.-briggs.md) — different-review
- [Practice: Brief the Case](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/exercise-brief-the-case/README.md) — no-title-match
- [Estate of Cavanaugh v. Andrade](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/exercise-brief-the-case/estate-of-cavanaugh-v.-andrade.md) — different-review
- [Model Brief for Brief the Case](review/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/exercise-brief-the-case/model-brief-for-brief-the-case.md) — no-title-match
- [Setting the Stage](review/README%20(1).md) — different-review
- [Foundations & Terminology](review/1.-introduction/foundations-and-terminology.md) — no-title-match
- [Overview of Probable Cause and Reasonable Suspicion](review/2.-overview-of-probable-cause-and-reasonable-suspicion/README.md) — different-review
- [Introduction](review/2.-overview-of-probable-cause-and-reasonable-suspicion/introduction.md) — different-review
- [The Principles of Probable Cause and Reasonable Suspicion](review/2.-overview-of-probable-cause-and-reasonable-suspicion/the-principles-of-probable-cause-and-reasonable-suspicion.md) — different-review
- [Cases & Notes](review/2.-overview-of-probable-cause-and-reasonable-suspicion/cases-notes-and-questions/README.md) — no-title-match
- [Notes on Racial Profiling](review/2.-overview-of-probable-cause-and-reasonable-suspicion/cases-notes-and-questions/notes-on-racial-profiling.md) — no-title-match
- [Consensual Encounters vs. Detentions](review/3.-consensual-encounters-vs.-detentions/README.md) — no-title-match
- [Consensual Encounters](review/3.-consensual-encounters-vs.-detentions/consensual-encounters/README.md) — no-title-match
- [Overview](review/3.-consensual-encounters-vs.-detentions/consensual-encounters/overview.md) — different-review
- [The "Free to Terminate" Test"](review/3.-consensual-encounters-vs.-detentions/consensual-encounters/the-free-to-terminate-test.md) — different-review
- [Engaging the Suspect](review/3.-consensual-encounters-vs.-detentions/consensual-encounters/engaging-the-suspect.md) — different-review
- [Officer Safety Measures](review/3.-consensual-encounters-vs.-detentions/consensual-encounters/officer-safety-measures.md) — different-review
- [Conducting the Investigation](review/3.-consensual-encounters-vs.-detentions/consensual-encounters/conducting-the-investigation.md) — different-review
- [Cases, Notes, & Questions](review/3.-consensual-encounters-vs.-detentions/consensual-encounters/cases-notes-and-questions/README.md) — different-review
- [California v. Hodari D.](review/3.-consensual-encounters-vs.-detentions/consensual-encounters/cases-notes-and-questions/california-v.-hodari-d..md) — different-review
- [U.S. v. Lillich](review/3.-consensual-encounters-vs.-detentions/consensual-encounters/cases-notes-and-questions/u.s.-v.-lillich.md) — different-review
- [Footnotes: Consensual Encounters](review/3.-consensual-encounters-vs.-detentions/consensual-encounters/footnotes-consensual-encounters.md) — no-title-match
- [Investigative Detentions (Terry Stops)](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/README.md) — no-title-match
- [Introduction](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/introduction.md) — different-review
- [Prior to the Stop](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/prior-to-the-stop-requirements-and-justifications-for-investigative-detentions.md) — no-title-match
- [After the Stop](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/README.md) — no-title-match
- [Duration](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/duration.md) — no-title-match
- [De Facto Arrests](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/de-facto-arrests.md) — no-title-match
- [Officer Procedures](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/officer-procedures/README.md) — no-title-match
- [Using Force to Detain](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/officer-procedures/using-force-to-detain.md) — no-title-match
- [Safety & Frisks](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/officer-procedures/safety-and-frisks/README.md) — no-title-match
- [Safety Precautions](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/officer-procedures/safety-precautions/README.md) — no-title-match
- [Terry Frisks](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/officer-procedures/safety-precautions/terry-frisks.md) — no-title-match
- [Identifying Detainees](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/officer-procedures/identifying-detainees.md) — no-title-match
- [Questioning Detainees](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/officer-procedures/questioning-detainees.md) — no-title-match
- [Showups](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/officer-procedures/showups.md) — no-title-match
- [Transporting Detainees](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/officer-procedures/transporting-detainees.md) — no-title-match
- [Other Procedures](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/officer-procedures/other-procedures.md) — no-title-match
- [Converting Detentions Into Consensual Encounters](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/converting-detentions-into-consensual-encounters.md) — no-title-match
- [Cases, Notes & Questions](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/README.md) — different-review
- [Terry Stops, Generally](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-generally/README.md) — no-title-match
- [Terry v. Ohio](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-generally/terry-v.-ohio.md) — different-review
- [Minnesota v. Dickerson](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-generally/minnesota-v.-dickerson.md) — different-review
- [Hiibel v. Sixth Judicial District Court of Nevada](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-generally/hiibel-v.-sixth-judicial-district-court-of-nevada.md) — no-title-match
- [Stereotyping, Profiles, and Confirmation Bias?](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-generally/stereotyping-profiles-and-confirmation-bias/README.md) — no-title-match
- [Illinois v. Wardlow](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-generally/stereotyping-profiles-and-confirmation-bias/illinois-v.-wardlow.md) — no-title-match
- [U.S. v. Sokolow](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-generally/stereotyping-profiles-and-confirmation-bias/u.s.-v.-sokolow.md) — no-title-match
- [Terry Stops of Vehicles](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-of-vehicles/README.md) — no-title-match
- [U.S. v. Place](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-of-vehicles/u.s.-v.-place.md) — different-review
- [U.S. v. Sharpe](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-of-vehicles/u.s.-v.-sharpe.md) — different-review
- [U.S. v. Arvizu](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-of-vehicles/u.s.-v.-arvizu.md) — different-review
- [Terry Stops Based on Tips/Informants](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-based-on-tips-informants/README.md) — no-title-match
- [Alabama v. White](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-based-on-tips-informants/alabama-v.-white.md) — no-title-match
- [Florida v. J.L.](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-based-on-tips-informants/florida-v.-j.l..md) — no-title-match
- [Navarette v. California](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-based-on-tips-informants/navarette-v.-california.md) — no-title-match
- [Footnotes: Investigative Detentions (Terry Stops)](review/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/footnotes-investigative-detentions-terry-stops.md) — no-title-match
- [Arrests](review/4.-arrests/README.md) — different-review — originally hidden
- [Probable Cause to Arrest](review/4.-arrests/probable-cause-to-arrest.md) — different-review — originally hidden
- [Arrests With & Without a Warrant](review/4.-arrests/arrests-with-and-without-a-warrant/README.md) — no-title-match — originally hidden
- [Preliminary Discussion](review/4.-arrests/arrests-with-and-without-a-warrant/cases-arrests-generally/preliminary-discussion.md) — different-review — originally hidden
- [Virginia v. Moore](review/4.-arrests/arrests-with-and-without-a-warrant/cases-arrests-generally/virginia-v.-moore.md) — different-review — originally hidden
- [Warrants & In-Home Arrests](review/4.-arrests/warrants-and-in-home-arrests/README.md) — no-title-match — originally hidden
- [Cases](review/4.-arrests/warrants-and-in-home-arrests/cases/README.md) — no-title-match — originally hidden
- [Payton v. New York](review/4.-arrests/warrants-and-in-home-arrests/cases/payton-v.-new-york.md) — different-review — originally hidden
- [Welsh v. Wisconsin](review/4.-arrests/warrants-and-in-home-arrests/cases/welsh-v.-wisconsin.md) — different-review — originally hidden
- [Steagald v. United States](review/4.-arrests/warrants-and-in-home-arrests/cases/steagald-v.-united-states.md) — different-review — originally hidden
- [Wilson v. Arkansas](review/4.-arrests/warrants-and-in-home-arrests/cases/wilson-v.-arkansas.md) — different-review — originally hidden
- [Richards v. Wisconsin](review/4.-arrests/warrants-and-in-home-arrests/cases/richards-v.-wisconsin.md) — different-review — originally hidden
- [Walker v. Louisville/Jefferson County Metro Government](review/4.-arrests/warrants-and-in-home-arrests/cases/walker-v.-louisville-jefferson-county-metro-government.md) — no-title-match — originally hidden
- [Making the Arrest](review/4.-arrests/making-the-arrest.md) — no-title-match — originally hidden
- [Post-Arrest Procedure](review/4.-arrests/post-arrest-procedure.md) — no-title-match — originally hidden
- [Search Incident to Lawful Arrest (SILA)](review/5.-search-incident-to-lawful-arrest-sila/README.md) — no-title-match — originally hidden
- [Cases](review/5.-search-incident-to-lawful-arrest-sila/cases/README.md) — no-title-match — originally hidden
- [Chimel v. California](review/5.-search-incident-to-lawful-arrest-sila/cases/chimel-v.-california.md) — different-review — originally hidden
- [United States v. Robinson](review/5.-search-incident-to-lawful-arrest-sila/cases/united-states-v.-robinson.md) — no-title-match — originally hidden
- [Knowles v. Iowa](review/5.-search-incident-to-lawful-arrest-sila/cases/knowles-v.-iowa.md) — no-title-match — originally hidden
- [The Automobile Exception (and More on Searches Incident to Lawful Arrest)](review/the-automobile-exception-and-more-on-searches-incident-to-lawful-arrest/README.md) — no-title-match — originally hidden
- [Cases](review/the-automobile-exception-and-more-on-searches-incident-to-lawful-arrest/cases/README.md) — no-title-match — originally hidden
- [New York v. Belton](review/the-automobile-exception-and-more-on-searches-incident-to-lawful-arrest/cases/new-york-v.-belton.md) — no-title-match — originally hidden
- [California v. Carney](review/the-automobile-exception-and-more-on-searches-incident-to-lawful-arrest/cases/california-v.-carney.md) — no-title-match — originally hidden
- [California v. Acevedo](review/the-automobile-exception-and-more-on-searches-incident-to-lawful-arrest/cases/california-v.-acevedo.md) — no-title-match — originally hidden
- [Knowles v. Iowa](review/the-automobile-exception-and-more-on-searches-incident-to-lawful-arrest/cases/knowles-v.-iowa.md) — no-title-match — originally hidden
- [Arizona v. Gant](review/the-automobile-exception-and-more-on-searches-incident-to-lawful-arrest/cases/arizona-v.-gant.md) — no-title-match — originally hidden
- [attributions](review/attributions.md) — different-review — originally hidden
- [Miranda Issues](review/miranda-issues/README.md) — no-title-match — originally hidden
- [Oregon v. Mathiason](review/miranda-issues/oregon-v.-mathiason.md) — no-title-match — originally hidden
- [J.D.B. v. North Carolina](review/miranda-issues/j.d.b.-v.-north-carolina.md) — no-title-match — originally hidden
- [Rhode Island v. Innis](review/miranda-issues/rhode-island-v.-innis.md) — no-title-match — originally hidden
- [Illinois v. Perkins](review/miranda-issues/illinois-v.-perkins.md) — no-title-match — originally hidden
- [North Carolina v. Butler](review/miranda-issues/north-carolina-v.-butler.md) — no-title-match — originally hidden
- [Colorado v. Spring](review/miranda-issues/colorado-v.-spring.md) — no-title-match — originally hidden
- [Moran v. Burdine](review/miranda-issues/moran-v.-burdine.md) — no-title-match — originally hidden
- [Attributions](review/attributions-1.md) — different-review — originally hidden