> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/the-automobile-exception-and-more-on-searches-incident-to-lawful-arrest) · Snapshot: 2026-11-02 · Original path: `the-automobile-exception-and-more-on-searches-incident-to-lawful-arrest`

---

# The Automobile Exception (and More on Searches Incident to Lawful Arrest)

