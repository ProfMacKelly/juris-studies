> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/attributions) · Snapshot: 2026-11-02 · Original path: `attributions`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/attributions)

---

# attributions

#### General Attributions & Licensing

#### Case Attributions

<details>

<summary>Editorial Notes, Attributions &#x26; Licensing</summary>

This page's content is adapted from the following source(s): [2.5: Chapter 6 - Probable Cause and Reasonable Suspicion](https://biz.libretexts.org/Workbench/Criminal_Procedure/05%3A_The_Fourth_Amendment/5.05%3A_Chapter_6_-_Probable_Cause_and_Reasonable_Suspicion) by [Anne M Alexander](https://law.missouri.edu/directory/anne-alexander/) and [Ben Trachtenberg](https://law.missouri.edu/directory/ben-trachtenberg/), in [_Criminal Procedure: A Free Law School Casebook 2e_](https://biz.libretexts.org/Bookshelves/Criminal_Law/Criminal_Procedure%3A_A_Free_Law_School_Casebook_2e_\(Alexander_and_Trachtenberg\)), used under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Additional modifications and annotations may have been here.

Many of the court's original citations to authorities and other content may have been omitted for length and readability purposes. Many elisions  are not identified, particularly string citations and original footnotes when not materially necessary to the subject of the lesson. However, some elisions are identified by bracketed ellipses (e.g., \[...]).

Subject to the following, this page is licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/): Judicial decisions and annotations thereto are not subject to copyright protection and are in the public domain. _See, e.g., Georgia v. Public.Resource.Org, Inc_., [140 S. Ct. 1498](https://scholar.google.com/scholar_case?case=8288711378870515248\&q=Georgia+et+al.+v.+Public.Resource.Org,+Inc.\&hl=en\&as_sdt=6,50) (2020).&#x20;

</details>

#### Cases (My Edits) & Public Domain

<details>

<summary>Editorial Notes and Licensing</summary>

Editing to the [original](https://scholar.google.com/scholar_case?case=11257938519868562913\&hl=en\&as_sdt=6,50) by Matthew L. Mac Kelly. Many of the court's original citations to authorities and other content may have been omitted for length and readability purposes. Many elisions are not identified, particularly string citations and original footnotes when not materially necessary to the subject of the lesson. However, some elisions are identified by bracketed ellipses (e.g., \[...]).

Judicial decisions and annotations thereto are not subject to copyright protection and are in the public domain. _See, e.g., Georgia v. Public.Resource.Org, Inc_., [140 S. Ct. 1498](https://scholar.google.com/scholar_case?case=8288711378870515248\&q=Georgia+et+al.+v.+Public.Resource.Org,+Inc.\&hl=en\&as_sdt=6,50) (2020).

This page's instructional annotations © 2025 by Mathew L. Mac Kelly are licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/?ref=chooser-v1), except where otherwise noted. <img src="https://2693790834-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F6Bqz3QmhzbBYM9Y3OuYd%2Fuploads%2FlL5l9osHpBZhsUFGEOLC%2Fimage.png?alt=media&#x26;token=7c0c7504-00cb-4eb7-889e-4196d971b97e" alt="" data-size="line"><br>

</details>

#### Public Domain

<details>

<summary>License</summary>

This page is dedicated to the public domain. [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) <img src="https://2693790834-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F6Bqz3QmhzbBYM9Y3OuYd%2Fuploads%2FKRLsezkoLtqXVM0ELf9y%2Fimage.png?alt=media&#x26;token=3b12ef58-ae77-473f-8182-539d6a9ca62c" alt="" data-size="line">

</details>

#### Mine



***

#### Creative Commons

[Wiki](https://en.wikipedia.org/wiki/Creative_Commons_license)
