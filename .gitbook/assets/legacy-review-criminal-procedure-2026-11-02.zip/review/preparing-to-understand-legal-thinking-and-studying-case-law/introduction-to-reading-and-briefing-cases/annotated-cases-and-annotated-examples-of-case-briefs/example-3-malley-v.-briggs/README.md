> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs) · Snapshot: 2026-11-02 · Original path: `preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/primers/reading-briefing/annotated-cases-briefs/example-3-malley-v.-briggs)

---

# Example 3: Malley v. Briggs

### Contents

{% content-ref url="example-3-malley-v.-briggs/annotated-case-malley-v.-briggs" %}
[annotated-case-malley-v.-briggs](example-3-malley-v.-briggs/annotated-case-malley-v.-briggs)
{% endcontent-ref %}

{% content-ref url="example-3-malley-v.-briggs/annotated-case-brief-malley-v.-briggs" %}
[annotated-case-brief-malley-v.-briggs](example-3-malley-v.-briggs/annotated-case-brief-malley-v.-briggs)
{% endcontent-ref %}
