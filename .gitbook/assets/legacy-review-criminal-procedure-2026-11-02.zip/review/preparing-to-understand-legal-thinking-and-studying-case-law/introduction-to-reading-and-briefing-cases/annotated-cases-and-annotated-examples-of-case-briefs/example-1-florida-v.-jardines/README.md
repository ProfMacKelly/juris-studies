> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-1-florida-v.-jardines) · Snapshot: 2026-11-02 · Original path: `preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-1-florida-v.-jardines`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/primers/reading-briefing/annotated-cases-briefs/example-1-florida-v.-jardines)

---

# Example 1: Florida v. Jardines

### Contents

{% content-ref url="example-1-florida-v.-jardines/annotated-case-florida-v.-jardines" %}
[annotated-case-florida-v.-jardines](example-1-florida-v.-jardines/annotated-case-florida-v.-jardines)
{% endcontent-ref %}

{% content-ref url="example-1-florida-v.-jardines/annotated-case-brief-florida-v.-jardines" %}
[annotated-case-brief-florida-v.-jardines](example-1-florida-v.-jardines/annotated-case-brief-florida-v.-jardines)
{% endcontent-ref %}
