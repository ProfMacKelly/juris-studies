> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park) · Snapshot: 2026-11-02 · Original path: `preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/primers/reading-briefing/annotated-cases-briefs/example-2-mills-v.-city-of-overland-park)

---

# Example 2: Mills v. City of Overland Park

### Contents

{% content-ref url="example-2-mills-v.-city-of-overland-park/annotated-case-mills-v.-city-of-overland-park" %}
[annotated-case-mills-v.-city-of-overland-park](example-2-mills-v.-city-of-overland-park/annotated-case-mills-v.-city-of-overland-park)
{% endcontent-ref %}

{% content-ref url="example-2-mills-v.-city-of-overland-park/annotated-case-brief-mills-v.-city-of-overland-park" %}
[annotated-case-brief-mills-v.-city-of-overland-park](example-2-mills-v.-city-of-overland-park/annotated-case-brief-mills-v.-city-of-overland-park)
{% endcontent-ref %}
