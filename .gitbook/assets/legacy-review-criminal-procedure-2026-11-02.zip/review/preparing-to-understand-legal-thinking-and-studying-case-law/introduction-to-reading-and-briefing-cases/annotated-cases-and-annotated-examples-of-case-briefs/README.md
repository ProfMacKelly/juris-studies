> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs) · Snapshot: 2026-11-02 · Original path: `preparing-to-understand-legal-thinking-and-studying-case-law/introduction-to-reading-and-briefing-cases/annotated-cases-and-annotated-examples-of-case-briefs`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/primers/reading-briefing/annotated-cases-briefs)

---

# Annotated Cases & Annotated Examples of Case Briefs

In this section:

* Read and compare three cases with the example case briefs, and&#x20;
* Examine the explanatory/instructional annotations provided within the example case briefs.

{% content-ref url="annotated-cases-and-annotated-examples-of-case-briefs/example-1-florida-v.-jardines" %}
[example-1-florida-v.-jardines](annotated-cases-and-annotated-examples-of-case-briefs/example-1-florida-v.-jardines)
{% endcontent-ref %}

{% content-ref url="annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park" %}
[example-2-mills-v.-city-of-overland-park](annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park)
{% endcontent-ref %}

{% content-ref url="annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs" %}
[example-3-malley-v.-briggs](annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs)
{% endcontent-ref %}
