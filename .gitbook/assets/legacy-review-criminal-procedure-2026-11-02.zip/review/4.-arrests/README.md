> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/4.-arrests) · Snapshot: 2026-11-02 · Original path: `4.-arrests`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-procedure/arrests) · [Candidate 2](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-procedure/arrests/arrests_)

---

# Arrests

