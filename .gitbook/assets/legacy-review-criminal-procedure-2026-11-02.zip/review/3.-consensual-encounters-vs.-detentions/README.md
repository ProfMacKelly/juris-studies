> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions) · Snapshot: 2026-11-02 · Original path: `3.-consensual-encounters-vs.-detentions`

---

# Consensual Encounters vs. Detentions

## Contents

{% content-ref url="3.-consensual-encounters-vs.-detentions/consensual-encounters" %}
[consensual-encounters](3.-consensual-encounters-vs.-detentions/consensual-encounters)
{% endcontent-ref %}

{% content-ref url="3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops" %}
[investigative-detentions-terry-stops](3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops)
{% endcontent-ref %}
