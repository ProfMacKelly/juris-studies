> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/consensual-encounters) · Snapshot: 2026-11-02 · Original path: `3.-consensual-encounters-vs.-detentions/consensual-encounters`

---

# Consensual Encounters

## Contents

{% content-ref url="consensual-encounters/overview" %}
[overview](consensual-encounters/overview)
{% endcontent-ref %}

{% content-ref url="consensual-encounters/the-free-to-terminate-test" %}
[the-free-to-terminate-test](consensual-encounters/the-free-to-terminate-test)
{% endcontent-ref %}

{% content-ref url="consensual-encounters/engaging-the-suspect" %}
[engaging-the-suspect](consensual-encounters/engaging-the-suspect)
{% endcontent-ref %}

{% content-ref url="consensual-encounters/officer-safety-measures" %}
[officer-safety-measures](consensual-encounters/officer-safety-measures)
{% endcontent-ref %}

{% content-ref url="consensual-encounters/conducting-the-investigation" %}
[conducting-the-investigation](consensual-encounters/conducting-the-investigation)
{% endcontent-ref %}

{% content-ref url="consensual-encounters/cases-notes-and-questions" %}
[cases-notes-and-questions](consensual-encounters/cases-notes-and-questions)
{% endcontent-ref %}
