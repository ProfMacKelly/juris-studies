> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/consensual-encounters/officer-safety-measures) · Snapshot: 2026-11-02 · Original path: `3.-consensual-encounters-vs.-detentions/consensual-encounters/officer-safety-measures`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-procedure/consensual-encounters-vs.-detentions/officer-safety-measures)

---

# Officer Safety Measures

A suspect who is being contacted may, of course, pose a threat to officers. This can present a problem because many basic officer-safety precautions are strongly suggestive of a detention. To help resolve this dilemma, the courts have ruled that some inquiries and requests pertaining to officer safety will not convert the encounter into a seizure.

## **REMOVE HANDS FROM POCKETS**

A detention will not result if officers simply requested that the suspect remove his hands from his pockets or keep them in sight.70 Thus in such a case, _U.S. v. Basher_, the Ninth Circuit explained that “\[p]olice officers routinely ask individuals to keep their hands in sight for officer protection,” and here the request “does not appear to have been made in a threatening manner.”71 Once again, note the importance of the officers’ choice of words and their attitude. As the Court of Appeal explained, “\[I]f the manner in which the request was made constituted a show of authority such that appellant reasonably might believe he had to comply, then the encounter was transformed into a detention.”72

## **EXIT THE VEHICLE**

For officer-safety purposes, officers may also request that the occupants of a parked vehicle step outside. But a detention will likely result if they expressly or impliedly commanded them to do so. Thus, in _People v. Rico_ the court said, “While the appellants’ initial stop did not constitute a detention, the officer’s subsequent ordering the appellants to alight from their vehicle and remain by the patrol car constituted a detention.”73

## **SPOTLIGHTS, HIGH BEAMS**

A seizure does not result merely because officers utilized a white spotlight or high beams to illuminate the suspect, whether for officer safety or to get the suspect’s attention.74 For example, in _People v. Perez_, a San Jose police officer on patrol at night noticed two men in a car parked in an unlit section of a motel parking lot known for drug sales.75 As the officer pulled up to the car, he turned on his high beams and white spotlight to “get a better look at the occupants.” He eventually arrested the driver for being under the influence of PCP, and one of the issues on appeal was whether his use of the lights converted the encounter into a detention. In ruling it did not, the court said, “While use of high beams and spotlights might cause a reasonable person to feel himself the object of official scrutiny, such directed scrutiny does not amount to a detention.” Similarly, in _People v. Franklin,_ a Ridgecrest officer on patrol in a high crime area spotlighted Franklin who was walking on the sidewalk.76 He did this because, although it was a warm night, Franklin was wearing a full-length camouflage jacket. When the officer stopped behind him, Franklin turned and walked toward the officer and repeatedly asked, “What’s going on?” Because Franklin was sweating and appeared “real jittery,” the officer asked him to remove his hands from his pockets. As he did so, the officer saw blood on his hands, which ultimately led to Franklin’s arrest for a murder that had just occurred in a nearby motel room. Again, the court rejected the argument that the spotlighting rendered the encounter a seizure, saying, “the spotlighting of appellant alone fairly can be said not to represent a sufficient show of authority so that appellant did not feel free to leave.”

## **PAT SEARCHES**

A nonconsensual pat search is both a search and a seizure and will therefore automatically result in a detention.77 As the court explained in In re Frank V., “Since Frank was physically restrained by the patdown, it constituted a detention.”78

## **HANDCUFFS, OTHER RESTRAINT**

Not surprisingly, a detention will also automatically result if officers handcuffed or otherwise restrained the suspect. This is because such measures are classic indications of a detention or arrest.79

## **DRAWN WEAPON**

Even more obviously, a detention will result if an officer drew a handgun or other weapon as a safety precaution.80 It is even significant that the officer “had his hand on his revolver.”81 However, the fact that an officer was visibly armed has “little weight in the analysis.”82 As the Supreme Court observed, “That most law enforcement officers are armed is a fact well known to the public. The presence of a holstered firearm thus is unlikely to contribute to the coerciveness of the encounter absent active brandishing of the weapon.”83

## **NUMBER OF OFFICERS**

Finally, the presence of backup officers, the number of them, their proximity to the suspect, and the manner in which they arrived and conducted themselves are all highly relevant.84 For example, in _U.S. v. Washington_ the court ruled the defendant was seized mainly because he was “confronted” by six officers who had gathered “around him.”85 And in _U.S. v. Buchanon_ the court ruled the defendant was detained largely because of “\[t]he number of officers that arrived \[three], the swiftness with which they arrived, and the manner in which they arrived (all with pursuit lights flashing).” These circumstances, said the court, “would cause a reasonable person to feel intimidated or threatened.”86 In contrast, the presence of backup officers has been deemed less significant when they were “posted in the background,”87 were “out of sight,”88 were “four to five feet away,”89 or were “little more than passive observers.”90

***

{% content-ref url="https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/consensual-encounters/footnotes-consensual-encounters" %}
[footnotes-consensual-encounters](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/consensual-encounters/footnotes-consensual-encounters)
{% endcontent-ref %}

<details>

<summary>Attributions and Licensing</summary>

Unless otherwise indicated, this page's content is adapted from the following source(s): [3.1: Investigative Contacts](https://workforce.libretexts.org/Bookshelves/Corrections/Principles_and_Procedures_of_the_Justice_System_\(Alvarez\)/03%3A_Consensual_Encounters__Investigative_Contacts/3.1%3A_Investigative_Contacts_-_POV)—[POV](https://workforce.libretexts.org/Bookshelves/Corrections/Principles_and_Procedures_of_the_Justice_System_\(Alvarez\)/03%3A_Consensual_Encounters__Investigative_Contacts/3.1%3A_Investigative_Contacts_-_POV) by [Larry Alvarez](https://www.canyons.edu/directory/larry-alvarez.php) in [_Principles and Procedures of the Justice System_](https://workforce.libretexts.org/Bookshelves/Corrections/Principles_and_Procedures_of_the_Justice_System_\(Alvarez\)) , used under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). This page is licensed under [CC BY 4.0](http://creativecommons.org/licenses/by/4.0/?ref=chooser-v1).

</details>
