> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/consensual-encounters/cases-notes-and-questions/u.s.-v.-lillich) · Snapshot: 2026-11-02 · Original path: `3.-consensual-encounters-vs.-detentions/consensual-encounters/cases-notes-and-questions/u.s.-v.-lillich`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-procedure/consensual-encounters-vs.-detentions/cases-notes-and-questions/u.s.-v.-lillich)

---

# U.S. v. Lillich

United States Court of Appeals, Eighth Circuit

#### United States v. Jeremy William Lillich <a href="#gsl_case_name" id="gsl_case_name"></a>

[6 F.4th 869 ](https://scholar.google.com/scholar_case?case=17331292441120233152\&q=6+F.4th+869+\&hl=en\&as_sdt=6,50)(2021)

No. 20-2086.

\[...]

Before SHEPHERD, ERICKSON, and KOBES, Circuit Judges.

SHEPHERD, Circuit Judge.

Jeremy William Lillich was charged with conspiracy to distribute a controlled substance (Count 1) and possession with intent to distribute a controlled substance (Count 2). Lillich filed a motion to suppress evidence, and after an evidentiary hearing, the district court granted in part and denied in part the motion. Thereafter, Lillich pled guilty to Count 2, reserving his right to appeal the partial denial of the motion to suppress. The district court sentenced him to 262 months imprisonment. Lillich appeals the district court's partial denial of his motion to suppress, arguing that law enforcement officials violated his Fourth Amendment rights when they detained him and later seized evidence from his car and that they violated his Fifth Amendment rights when they failed to give _Miranda_ warnings. \[W]e affirm.

## **I. \[Facts & Procedural History]**

In the early morning of February 3, 2019, two officers from the Woodbury County Sheriff's Office—Deputy Michael Lenz and a reserve deputy—were patrolling the small town of Sloan, Iowa, due to break-ins the night before at a church and a school. At around 2:00 a.m. while driving past a car wash, they noticed a car in a car wash bay and decided to observe from a short distance away. Deputy Lenz was concerned about a possible burglary, given the break-ins the night before, the time of day, and recent car wash burglaries in nearby counties.

The Sloan car wash has two manual car wash bays that are open and lit 24 hours a day. Both bays have two garage-type doors, allowing a person to drive in, stop and wash their car, and then drive out. The car wash owner testified that the bay doors are kept closed in the winter so the bays stay heated. The south bay (entrance) doors are manual, opened and closed by rope pulleys. The north bay (exit) doors open by pressing a button and automatically close when the car drives over a sensor. Each bay is accessible from the other by a door between the two bays.

As the officers drove by the car wash, they saw a car and a person's feet in a car wash bay that had the doors closed,\*[^1] next to an empty bay that had the automatic exit door open. The officers decided to investigate further. They entered the bay occupied by Lillich and his associate, Patrick Steffens, by walking through the open garage bay door of the empty bay and walking the length of the empty bay to the open door between the two bays. The officers identified themselves as law enforcement. They wore their sheriff's deputy uniforms, and their weapons were holstered and visible on their persons.

In the car wash bay, the officers saw Lillich and Steffens drying a car with the hood popped open. Deputy Lenz asked Lillich and Steffens what they were doing at the car wash at 2:00 a.m., and Lillich responded that they had just been at the WinnaVegas Casino and that he often washes his car after going to the casino. Deputy Lenz explained to Lillich and Steffens that he was checking in based on the recent burglaries, and he asked them for identification. Steffens gave Deputy Lenz a driver's license, and Lillich gave him an identification card. Lillich explained that he was barred from driving and that Steffens had been driving the car. Deputy Lenz radioed Lillich's and Steffens's information to dispatch. While waiting for the results, Deputy Lenz talked with Lillich and Steffens about their plans for the night.

After being on the scene for approximately four minutes, Deputy Lenz went back to his car to scan the identification cards, while the reserve deputy stayed in the bay with Lillich and Steffens. Soon after Deputy Lenz departed, another sheriff's deputy (Deputy Simoni) arrived and stood in the doorway between the two bays. While Deputy Lenz was gone, Lillich and Steffens dried the car and, on several occasions, opened the driver's side and passenger's side doors to access items in the car. Both bay doors remained closed.

Deputy Lenz returned after about three minutes and gave Lillich and Steffens their identification cards back. All three officers started to leave, but before they made it to their patrol cars, they were notified by dispatch that there was a "hit" on Steffens for a United States Marshals hold and a federal arrest warrant related to "dangerous drugs." The officers then returned to the car wash bay occupied by Steffens and Lillich, but they did not immediately arrest Steffens on the warrant, as the warrant was not verified until approximately 30 minutes later.

The officers questioned Lillich about his car. Eventually Lillich asked if he and Steffens were free to go, and Deputy Lenz responded that they were not. Less than a minute later, Deputy Lenz conducted a pat-down search of Steffens, during which Deputy Lenz discovered a baggie of methamphetamine. Deputy Lenz arrested Steffens, seized Steffens's cell phone, and placed Steffens in the back of the patrol car. When Steffens was handcuffed, Deputy Simoni suggested that Lillich call someone for a ride because Lillich was barred from driving. Lillich tried to get his cell phone from his car, but Deputy Lenz blocked his path, explaining that he "did not know what's in there" but that an officer could retrieve the phone for Lillich. Deputy Simoni looked for the phone in the car for some time, but eventually Lillich rescinded his request for the officers to look for his phone.

After finding drugs on Steffens, officers called a K-9 officer to the scene to conduct a drug dog sniff of Lillich's car. Lillich was not free to leave while they waited for the K-9 officer: Lillich asked if he could step outside, and the officer did not allow him to leave the bay; Lillich also asked if he could walk to the casino to find someone to give him a ride, and the request was denied. The K-9 officer conducted a drug dog sniff of Lillich's car, and the dog alerted on it. Officers searched the car and found approximately two pounds of methamphetamine and one pound of cocaine inside a bag on the passenger's seat. Officers then arrested Lillich.

A federal grand jury charged Lillich with conspiracy to distribute a controlled substance following a prior felony drug conviction \[...]; and possession with intent to distribute a controlled substance following a prior felony drug conviction \[...]. \[...]

Lillich filed two motions to suppress the statements he made to law enforcement and the evidence obtained from the search of his car. \[...] The magistrate judge separately addressed the "initial encounter" and the "second encounter" between Lillich and the officers. The initial encounter is composed of the seven-minute interval from when officers first entered the car wash bay occupied by Lillich and Steffens to when Deputy Lenz returned their identification cards. The second encounter is composed of the time from when the officers returned to the bay after receiving the "hit" from dispatch through the end of the interaction. The magistrate judge found that while Lillich's initial encounter with police was not consensual, it was nonetheless supported by reasonable suspicion and was not of unreasonable duration. The magistrate judge also found that the initial encounter was not custodial and thus the officers were not required to give Lillich Miranda warnings. Additionally, the magistrate judge found that the second encounter was not supported by reasonable suspicion, and accordingly any statements Lillich made during or after the second encounter should be suppressed. The magistrate judge nonetheless found that the unlawful second encounter did not require suppression of the drugs and cell phone recovered from Lillich's car, reasoning that the officers would have inevitably discovered such evidence while investigating Steffens.

Lillich objected to the ... conclusions that the initial encounter was supported by reasonable suspicion, that the officers were not required to give him Miranda warnings during the first encounter, and that the inevitable discovery doctrine saved from suppression the evidence the officers obtained from his car. The government objected to the ... conclusions that the initial encounter was not consensual and that the officers lacked reasonable suspicion to justify the second encounter. The district court \[contrary to the magistrate judge, concluded] that Lillich's initial encounter with police was consensual, but even if it were not, it was supported by reasonable suspicion. The district court adopted the balance of the \[magistrate judge's findings] and granted in part and denied in part Lillich's motion to suppress.

Before trial, Lillich entered a conditional guilty plea on Count 2. In his plea agreement, Lillich reserved the right to appeal the partial denial of his motion to suppress. The district court accepted Lillich's guilty plea and sentenced him to 262 months imprisonment. Lillich now appeals the partial denial of his motion to suppress.

## II. \[Discussion]

Lillich challenges the district court's partial denial of his motion to suppress, arguing: (1) the initial encounter was neither consensual nor supported by reasonable suspicion; (2) the initial encounter violated his Fifth Amendment right against self-incrimination because the encounter was custodial and the officers failed to give him Miranda warnings; and (3) the inevitable discovery doctrine does not apply to save from suppression the evidence found in Lillich's car. The government does not challenge the district court's determination that the second encounter was unlawful or the suppression of Lillich's statements after the second encounter. \[...]

### **A.** \[Nature of the Encounter]

Lillich first contends that his initial encounter with the officers violated the Fourth Amendment's prohibition on unreasonable seizures. He argues that the encounter was neither consensual nor supported by reasonable suspicion, and thus the district court should have suppressed all evidence the officers obtained as "fruits of the violation of Mr. Lillich's Fourth Amendment right." \[...] Lillich does not challenge any of the district court's factual findings. Thus, we consider the purely legal question of <mark style="background-color:yellow;">whether the initial encounter was either consensual or supported by reasonable suspicion</mark>.

"The Fourth Amendment prohibits \`unreasonable searches and seizures' by the Government, and its protections extend to brief investigatory stops of persons or vehicles that fall short of traditional arrest." _United States v. Arvizu_. Government officials, however, "do not violate the Fourth Amendment's prohibition of unreasonable seizures merely by approaching individuals on the street or in other public places and putting questions to them if they are willing to listen." [_United States v. Drayton_](#user-content-fn-2)[^2].&#x20;

"\[A] person has been \`seized' within the meaning of the Fourth Amendment only if, in view of all of the circumstances surrounding the incident, a reasonable person would have believed that he was not free to leave." [_United States v. Mendenhall_](#user-content-fn-3)[^3]. In certain circumstances, a citizen's freedom of movement may be "restricted by a factor independent of police conduct," ..., including "by his being a passenger on a bus," ..., or by his being at his workplace. \[...] In those circumstances, "the \`free to leave' analysis ... is inapplicable," and "the appropriate inquiry is whether a reasonable person would feel free to decline the officers' requests or otherwise terminate the encounter." \[...] Ultimately, a seizure occurs "when \[an] officer, by means of physical force or show of authority, has in some way restrained the liberty of a citizen." \[...] With some exceptions, "both the \`primary evidence obtained as a direct result of an illegal search or seizure' and ... \`evidence later discovered and found to be derivative of an illegality,' the so-called \`fruit of the poisonous tree,'" is inadmissible under the exclusionary rule. \[...]

To determine whether a police-citizen encounter is consensual or implicates Fourth Amendment protections, we must "consider\[ ] the totality of the circumstances" and "the unique facts of each case." \[...]. "The test is necessarily imprecise, because it is designed to assess the coercive effect of police conduct, taken as a whole, rather than to focus on particular details of that conduct in isolation." [_Michigan v. Chesternut_](#user-content-fn-4)[^4]. Several factors inform our analysis, including:

> officers positioning themselves in a way to limit the person's freedom of movement, the presence of several officers, the display of weapons by officers, physical touching, the use of language or intonation indicating compliance is necessary, the officer's retention of the person's property, or an officer's indication the person is the focus of a particular investigation.

[_United States v. Griffith_](#user-content-fn-5)[^5]_._

Lillich argues that he was seized because his freedom of movement was limited "to a small car wash bay with the exits blocked," and because he was "cornered in a closed area by the officers when the officer's \[sic] \`requested' his license." \[...] We disagree. First, we note that the magistrate judge found—and Lillich has never contested— "that the officers asked to see \[Lillich's] identification without indicating it was required, and \[Lillich] voluntarily gave \[his] identification card\[ ] to the officers upon request." \[...] "A request to see identification is not a seizure, \`as long as the police do not convey a message that compliance with their request\[ ] is required.'" \[...] Additionally, the district court found that, because the officers parked their car in front of the bay _next_ to the bay containing Lillich's car, the officers "did not block an exit \[Lillich and Steffens] could have used if they attempted to terminate the encounter and drive away." \[...] Although Lillich's movements were "limited" in a sense, this was the result of his decisions to wash his car and close both bay doors while doing so; "it says nothing about whether or not the police conduct at issue was coercive." \[...] Further, Lillich was "generally unhindered from walking around the bay or continuing to work on the car" after the officers arrived. \[...] Finally, the fact that Deputy Simoni remained near the doorway between the two bays did not meaningfully limit Lillich's freedom of movement. Even if the doorway were blocked, and even considering Lillich's legal inability to drive, Lillich had other ways to terminate the encounter. For example, he could have opened the bay door(s) and exited on foot. Accordingly, we find that any limitation the officers placed on Lillich's freedom of movement is minimal, and we give it little weight.

Additionally, we find that the officers' seven-minute retention of Lillich's identification card was not inconsistent with the type of brief examination Lillich consented to by voluntarily turning over his identification card. Moreover, Lillich never requested that the officers return his identification. See [_United States v. Carpenter_](#user-content-fn-6)[^6]. Moreover, Lillich continued to dry off the car while the officers retained his identification, suggesting that the retention of his identification did not interfere with his activities or meaningfully prevent him from terminating the encounter or leaving. The totality of the circumstances indicates that the officers' retention of Lillich's identification did not restrain his liberty. Accordingly, we assign the "retention of property" factor little weight.

The other circumstances support the conclusion that the initial encounter was consensual. The officers did not activate their patrol car's lights or siren, physically touch Lillich, brandish their weapons, or threaten arrest.[\* ](#user-content-fn-7)[^7]The officers' weapons were holstered and visible, and Lillich does not argue that the presence of weapons impacts the analysis. Even if he had, this fact does not compel a finding that the encounter was a seizure.[\* ](#user-content-fn-8)[^8]The presence of three officers weighs in favor of finding a seizure\*[^9], but it does not outweigh the other facts indicating that no seizure occurred.\*[^10] The record does not demonstrate that the officers restrained Lillich's liberty "by means of physical force or show of authority."\*[^11]  Based on the totality of the circumstances, we conclude that the officers' conduct would not have "communicated to a reasonable person that the person was not free to decline the officers' requests or otherwise terminate the encounter."\*[^12] Accordingly, we find that the initial encounter between Lillich and the officers was consensual, and thus Lillich's Fourth Amendment rights were not violated.\*[^13]

### B. \[Lack of _Miranda_ Warnings]

Lillich also contends that the district court should have suppressed his statements made during the initial encounter because it was a custodial interrogation requiring Miranda warnings, which the officers failed to give. Again, we disagree. "A consensual encounter does not amount to a custodial situation requiring the administration of Miranda warnings."[\* ](#user-content-fn-14)[^14]Because we conclude that the initial encounter was consensual, we necessarily conclude that the officers were not required to give Lillich Miranda warnings. Accordingly, the officers did not violate Lillich's Fifth Amendment rights during the first encounter, and the district court did not err in denying Lillich's motion to suppress the statements.

### C. \[Dog Sniff and the Search of the Car]

Finally, Lillich argues that the drugs and cell phone seized from his car should have been suppressed because they were the fruits of his unlawful seizure. Lillich contends that his car was unlawfully seized to await a drug dog sniff, which eventually led the officers to search the car and seize drugs and his cell phone from it. Lillich does not contest that the drug dog's positive alert gave the officers probable cause to search the car.\*[^15]

The district court found that the officers lacked reasonable suspicion to detain Lillich in the second encounter, and therefore Lillich was unlawfully seized. However, the district court ruled that the evidence seized from Lillich's car should not be suppressed because it would have been inevitably discovered during the officers' investigation of Steffens. The "inevitable discovery" doctrine, an exception to the exclusionary rule, "allows for the admission of evidence that would have been discovered even without the unconstitutional source."[\* ](#user-content-fn-16)[^16]The district court found that the officers had reasonable suspicion to seize Lillich's car for a drug dog sniff because "\[t]he drugs found on Steffens, combined with his potential outstanding warrant for \`dangerous drugs' and the factors that led to the initial encounter, created reasonable suspicion that Lillich's \[car] might contain further evidence of drugs or drug-related crimes." \[...] The district court further reasoned that because Steffens was the driver, there was a sufficient nexus between him and Lillich's car "because in most cases drivers exercise sufficient dominion and control" over a car to justify further searches for drugs. \[...][^17] Additionally, the district court found that Lillich would not have been able to take his car after he asked to leave, since he was legally unable to drive, and even if he had exited on foot, he would not have been able to get his phone out of his car before leaving, since less than a minute elapsed from the time he asked to leave and when the officers found drugs on Steffens.

We conclude that the district court did not err in denying the motion to suppress the evidence found in Lillich's car, albeit for a different reason. \[...] We agree with the government that the district court did not need to rely on the inevitable discovery doctrine because the drugs seized from Lillich's car were not the fruit of Lillich's unlawful detention. Evidence should be excluded only "if the \`illegality is at least a but-for cause of obtaining the evidence.'"[\* ](#user-content-fn-18)[^18]Lillich bears the burden of establishing a nexus between the constitutional violation and the discovery of the drugs and cell phone.\*[^19]

Lillich has failed to demonstrate the requisite nexus between his detention and the discovery of the evidence. No evidence from Lillich's person, after he asked to leave, was used to support the seizure or search of the car. For the less than one minute between when Lillich asked to leave and when the officers found drugs on Steffens, Lillich's car was stationary because Lillich legally was unable to drive it and Steffens, the driver, was under arrest. The detention of Lillich's person had nothing to do with the car remaining stationary for that one-minute period. Thereafter, the evidence relied upon to support the officers' seizure of the car to await the drug dog came from Steffens: the drugs found in Steffens's pocket and Steffens's outstanding warrant for "dangerous drugs." And Lillich told the officers during the initial encounter that he was barred from driving and that Steffens was driving the car. Lillich challenges the district court's conclusion that the drugs found on Steffens provided reasonable suspicion to seize the car to await a drug dog sniff. He argues that there was an insufficient nexus between Steffens and Lillich's car: although Steffens was the driver, "it still is not clear from the record what other facts show he had dominion or control over the vehicle." \[...] But the presence of drugs in Steffens's—the driver's—pocket provided reasonable suspicion to seize the car to await a drug dog sniff. \[...] No "other facts" were needed. Therefore, we reject Lillich's argument that the officers lacked authority to seize Lillich's car. Further, as stated above, Lillich does not contest that the drug dog's positive alert on his car gave the officers probable cause to search it. Lillich's unlawful detention "did not contribute in any way to discovery of the evidence" in Lillich's car\*[^20], and therefore Lillich has not demonstrated that the "illegality is ... a but-for cause of obtaining the evidence."[\* ](#user-content-fn-21)[^21]Accordingly, the district court did not err in denying Lillich's motion to suppress the drugs and cell phone seized from his car.

Lillich argues that the district court's analysis erroneously assumed that his cell phone was "always going to stay in the \[car] and always going to be searched." \[...] He implies that if he had been permitted to leave the second encounter when he requested, he would have taken the phone with him, preventing the officers from seizing it from the car. But the district court found that Lillich factually could not have left with his phone before reasonable suspicion arose to seize his car (which contained his phone) because less than one minute elapsed between his request to leave and the officers' discovery of drugs on Steffens. Lillich does not explain why this finding was erroneous. And the record shows that Deputy Simoni later looked for Lillich's phone in the car but could not find it, suggesting that the phone was not immediately accessible and that it would have taken a minute or longer to retrieve the phone and leave with it. Thus, Lillich has not demonstrated that the district court's factual finding is clearly erroneous.\*[^22]&#x20;

\[...]

We affirm the district court's judgment.

***

Keywords: consent, consensual, consensual encounter, reasonable suspicion, seized, seizure, custodial, Miranda warnings, inevitable discovery, suppression, fruits of the poisonous tree, exclusionary rule, car, automobile, totality of the circumstances, free to decline, free to leave, force, show of force, show of authority, coercive, coercion, physical contact, freedom of movement, dog sniff, drug dog, drug-sniffing dog, automobile search, automobile exception, dominion and control, but-for cause

<details>

<summary>Editorial Notes, <strong>Attributions and Licensing</strong></summary>

Editing to the [original](https://scholar.google.com/scholar_case?case=17331292441120233152\&q=6+F.4th+869+\&hl=en\&as_sdt=6,50), excluding any original footnotes (hyperlinked or otherwise), by Matthew L. Mac Kelly. Many of the court's citations to authorities have been omitted for length and readability purposes. Otherwise, elisions are identified by bracketed ellipses (e.g., \[...]), several of which reveal elided text by clicking on inline annotation indicators (e.g., \[...][^23]). Judicial decisions are not subject to copyright protection and are in the public domain. _See Georgia v. Public.Resource.Org, Inc_., [140 S.Ct. 1498](https://scholar.google.com/scholar_case?case=8288711378870515248\&q=Georgia+et+al.+v.+Public.Resource.Org,+Inc.\&hl=en\&as_sdt=6,50) (2020). This page is in the public domain.

</details>

[^1]: Deputy Lenz testified at the suppression hearing that the door was "cracked minimally along the bottom" and he could see a pair of feet.&#x20;

[^2]: 536 U.S. 194, 200 (2002); see also _Florida v. Bostick_, 501 U.S. 429, 434-35 (1991) ("\[E]ven when officers have no basis for suspecting a particular individual, they may generally ask questions of that individual\[ and] ask to examine the individual's identification ... as long as the police do not convey a message that compliance with their requests is required." (citations omitted))

[^3]: 446 U.S. 544, 554 (1980)

[^4]: 486 U.S. 567, 573 (1988)

[^5]: 533 F.3d 979, 983 (8th Cir. 2008) (citations omitted)

[^6]: 462 F.3d 981, 985 (8th Cir. 2006); see also _Oglesby v. Lesan_, 929 F.3d 526, 533 (8th Cir. 2019) (in 42 U.S.C. § 1983 case, finding no seizure where officer retained citizen's license and registration for 15 minutes to conduct records check: citizen provided the documents without objection upon officer's request, never objected to records search, and did not request that the officers return the documents)

[^7]: See _Oglesby_, 929 F.3d at 533

[^8]: See _Drayton_, 536 U.S. at 205, 122 S.Ct. 2105 (explaining that, because it is well known to the public that most officers are armed, "\[t]he presence of a holstered firearm ... is unlikely to contribute to the coerciveness of the encounter absent active brandishing of the weapon").

[^9]: see United States v. Villa-Gonzalez, 623 F.3d 526, 533 (8th Cir. 2010)

[^10]: See _United States v. White_, 81 F.3d 775, 779 (8th Cir. 1996) (explaining that encounter was consensual despite presence of three officers because two of the officers, similar to this case, "were little more than passive observers prior to commencement of the search").&#x20;

[^11]: See Bostick, 501 U.S. at 434, 111 S.Ct. 2382 (quoting Terry, 392 U.S. at 19 n.16, 88 S.Ct. 1868).

[^12]: See id. at 439, 111 S.Ct. 2382

[^13]: Because we conclude that the initial encounter was consensual, we need not consider the district court's alternative holding that the initial encounter was supported by reasonable suspicion.

[^14]: United States v. Woods, 213 F.3d 1021, 1023 (8th Cir. 2000)

[^15]: See United States v. Donnelly, 475 F.3d 946, 955 (8th Cir. 2007) ("Assuming that the dog is reliable, a dog sniff resulting in an alert on a ... car ..., standing alone, gives an officer probable cause to believe that there are drugs present.").

[^16]: Strieff, 136 S. Ct. at 2061

[^17]: See United States v. Davis, 569 F.3d 813, 817-18 (8th Cir. 2009) (holding that drugs in the driver's pocket and odor of marijuana provided probable cause to search the entire car).

[^18]: United States v. Hastings, 685 F.3d 724, 728 (8th Cir. 2012) (citation omitted); Segura v. United States, 468 U.S. 796, 815, 104 S.Ct. 3380, 82 L.Ed.2d 599 (1984) ("\[E]vidence will not be excluded as \`fruit' unless the illegality is at least the \`but for' cause of the discovery of the evidence.").&#x20;

[^19]: See Hastings, 685 F.3d at 728.

[^20]: See Segura, 468 U.S. at 815, 104 S.Ct. 3380.

[^21]: See Hastings, 685 F.3d at 728 (citation omitted); Segura, 468 U.S. at 815, 104 S.Ct. 3380.&#x20;

[^22]: See United States v. Peeples, 879 F.3d 282, 287 (8th Cir. 2018) ("Clear error occurs when the district court's finding is \`(1) not supported by substantial evidence; (2) based upon an erroneous view of the law; or (3) such that "we are left with the definite and firm conviction that an error has been made."'" (citation omitted)).

[^23]: Elided text here.
