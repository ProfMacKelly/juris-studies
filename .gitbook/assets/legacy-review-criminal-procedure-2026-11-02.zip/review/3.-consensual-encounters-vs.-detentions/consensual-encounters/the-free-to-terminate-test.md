> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/consensual-encounters/the-free-to-terminate-test) · Snapshot: 2026-11-02 · Original path: `3.-consensual-encounters-vs.-detentions/consensual-encounters/the-free-to-terminate-test`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-procedure/consensual-encounters-vs.-detentions/the-free-to-terminate-test)

---

# The "Free to Terminate" Test"

A police-suspect encounter will be deemed a contact if a reasonable person in the suspect’s position would have “felt free to decline the officers’ requests or otherwise terminate the encounter.”10 In other words, “So long as a reasonable person would feel free to disregard the police and go about his business, the encounter is consensual and no reasonable suspicion is required.”11 Later we will discuss the many circumstances that are relevant in making this determination. But first it will be helpful to discuss some important general principles.

## **Reasonable "Innocent" Person**

We begin with a principle that might seem peculiar at first: The fictitious “reasonable person” is “innocent” of the crime under investigation. What this means is that the circumstances are viewed through the eyes of a person who, although not necessarily a pillar of the community, is not currently worried about being arrested.12 Said the Third Circuit, “\[W]hat a guilty \[suspect] would feel and how he would react are irrelevant to our analysis because the reasonable person test presupposes an innocent person.”13

The reason this is significant is that a person who was guilty of the crime under investigation would necessarily view the officers' words and actions much differently—much more ominously—than an innocent person, and might therefore erroneously conclude that any perceived restriction on his freedom was an indication that he had been detained. For example, in _In re Kemonte H_. the court ruled that a reasonable innocent person who saw two officers approaching him on the street “would not have felt restrained” but would instead “only conclude that the officers wanted to talk to him.”14

## **Free to do what?**

In the past, the test was whether a reasonable person would have believed he was “free to leave” or “free to walk away” from the officers.15 This test made sense—and it still does if the encounter occurs on the streets or other place that the suspect could easily leave if he wanted to. But contacts also occur in places that the suspect has no desire to leave (e.g., his home, his car) and in places he cannot leave easily (e.g., a bus, the shoulder of a freeway, his workplace. For that reason, the Supreme Court in _Florida v. Bostick_ simplified things by ruling that freedom to terminate—not freedom to leave—is the correct test because it can be applied “equally to police encounters that take place on trains, planes, and city streets.”16 (In this article, we will use the terms “free to terminate,” “free to go” and “free to leave” interchangeably.)

## **Objective vs. Subjective Circumstances**

In applying the “free to terminate” test the only circumstances that matter are those that the suspect could have seen or heard. Thus, the officer’s thoughts, beliefs, suspicions, and plans are irrelevant unless they were somehow communicated to the suspect.17

As the California Supreme Court explained:

> \[A]n officer’s beliefs concerning the potential culpability of the individual being questioned are relevant to determining whether a seizure occurred only if those beliefs were somehow manifested to the individual being interviewed—by word or deed—and would have affected how a reasonable person in that position would perceive his or her freedom to leave.18

For the same reason, the suspect’s subjective belief that he could not freely terminate the encounter is also immaterial.19 For example, an encounter will not be deemed a seizure merely because the suspect testified that, based on his prior experiences with officers, he thought he would be arrested if he did not comply with all of the officer’s requests.20

## **"Should" vs. "Must"**

The test is whether a reasonable person would have believed he must stay or was otherwise _required_ to cooperate with officers. This means a detention will not result merely because a reasonable person would have believed he _should_ stay and cooperate, or because the officer’s request made him “uncomfortable.”21 As the Court of Appeal noted, “Cooperative citizens may ordinarily feel they should respond when approached by an officer on the street but this does not, by itself, mean that they do not have a right to leave if they so desire.”22

## **Refusal to Cooperate**

Because contacts are, by definition, consensual, a suspect may refuse to talk with officers, refuse to ID himself, or otherwise not cooperate.23 “Implicit in the notion of a consensual encounter,” said the Court of Appeal, “is a choice on the part of the citizen not to consent but to decline to listen to the questions at all and go on his way.”24 Or, as the Ninth Circuit put it, “When a citizen expresses his or her desire not to cooperate, continued questioning cannot be deemed consensual.”25

## **Don't Confuse with&#x20;**_**Miranda**_

It is important not to confuse the “free to terminate” test with _Miranda’s_ test for determining whether a suspect was “in custody.” While both tests attempt to gauge the coercive pressures that existed during a police encounter, a suspect will be deemed “in custody” for Miranda purposes only if he reasonably believed he was effectively under arrest.26 But, as noted, a contact will become a de facto detention if the suspect reasonably believed that he was not free to terminate the encounter.

## **If the Suspect Runs**

There is one exception to the “free to terminate” rule: If the suspect ran from the officers when they attempted to contact him, and if they gave chase, the encounter will not be deemed a seizure until they apprehend him.27 Thus, if the suspect discarded drugs, weapons or other evidence while running, the evidence will not be suppressed on grounds that the officers lacked grounds to detain or arrest him.

## **Totality of the Circumstances**

In applying the “free to terminate” test, the courts will consider the totality of circumstances.28 Although there are some actions that will, in and of themselves, result in a seizure (e.g., pulling a gun), in most cases it takes a “collective show of authority.”29 As the California Supreme Court explained, “This test assesses the coercive effect of police conduct as a whole, rather than emphasizing particular details of that conduct in isolation.”30

## **"Free to Terminate" vs. Street Reality**

Before going further, it must be acknowledged that many of the things that officers may say and do without converting a contact into a detention would plainly cause some innocent people to believe they were not free to terminate the encounter. But this does not mean, as some have suggested, that the test is a sham or, at best, naive.31

Instead, like many other Fourth Amendment “tests” (such as determining whether there are grounds to arrest or pat search a suspect), it is simply a practical—albeit imperfect—compromise between competing interests. As the Fourth Circuit put it, if a suspect decided to walk off, it “may have created an awkward situation,” but “awkwardness alone does not invoke the protections of the Fourth Amendment.”32 Similarly, the Ninth Circuit observed that “we must recognize that there is an element of psychological inducement when a representative of the police initiates a conversation. But it is not the kind of psychological pressure that leads, without more, to an involuntary stop.”33

Having covered the basic principles, we will now examine the various circumstances that are especially relevant in determining whether an encounter with an officer was a contact or a seizure.

***

{% content-ref url="https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/consensual-encounters/footnotes-consensual-encounters" %}
[footnotes-consensual-encounters](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/consensual-encounters/footnotes-consensual-encounters)
{% endcontent-ref %}

<details>

<summary>Attributions &#x26; Licensing</summary>

Unless otherwise indicated, this page's content is adapted from the following source(s): [3.1: Investigative Contacts](https://workforce.libretexts.org/Bookshelves/Corrections/Principles_and_Procedures_of_the_Justice_System_\(Alvarez\)/03%3A_Consensual_Encounters__Investigative_Contacts/3.1%3A_Investigative_Contacts_-_POV)—[POV](https://workforce.libretexts.org/Bookshelves/Corrections/Principles_and_Procedures_of_the_Justice_System_\(Alvarez\)/03%3A_Consensual_Encounters__Investigative_Contacts/3.1%3A_Investigative_Contacts_-_POV) in [_Principles and Procedures of the Justice System_](https://workforce.libretexts.org/Bookshelves/Corrections/Principles_and_Procedures_of_the_Justice_System_\(Alvarez\)) by [Larry Alvarez](https://www.canyons.edu/directory/larry-alvarez.php), used under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). This page is licensed under [CC BY 4.0](http://creativecommons.org/licenses/by/4.0/?ref=chooser-v1).

</details>
