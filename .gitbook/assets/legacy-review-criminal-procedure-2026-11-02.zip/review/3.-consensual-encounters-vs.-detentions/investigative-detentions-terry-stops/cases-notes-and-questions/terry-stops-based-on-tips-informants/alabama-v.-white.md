> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-based-on-tips-informants/alabama-v.-white) · Snapshot: 2026-11-02 · Original path: `3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-based-on-tips-informants/alabama-v.-white`

---

# Alabama v. White

Supreme Court of the United States

**Alabama v. Vanessa Rose White**

[496 U.S. 325](https://cite.case.law/us/496/325/) (1990)

## \[Majority]

Justice WHITE delivered the opinion of the Court.

Based on an anonymous telephone tip, police stopped respondent’s vehicle. A consensual search of the car revealed drugs. The issue is whether the tip, as corroborated by independent police work, exhibited sufficient indicia of reliability to provide reasonable suspicion to make the investigatory stop. We hold that it did.

On April 22, 1987, at approximately 3 p.m., Corporal B.H. Davis of the Montgomery Police Department received a telephone call from an anonymous person, stating that Vanessa White would be leaving 235-C Lynwood Terrace Apartments at a particular time in a brown Plymouth station wagon with the right taillight lens broken, that she would be going to Dobey’s Motel, and that she would be in possession of about an ounce of cocaine inside a brown attaché case. Corporal Davis and his partner, Corporal P. A. Reynolds, proceeded to the Lynwood Terrace Apartments. The officers saw a brown Plymouth station wagon with a broken right taillight in the parking lot in front of the 235 building. The officers observed respondent leave the 235 building, carrying nothing in her hands, and enter the station wagon. They followed the vehicle as it drove the most direct route to Dobey’s Motel. When the vehicle reached the Mobile Highway, on which Dobey’s Motel is located, Corporal Reynolds requested a patrol unit to stop the vehicle. The vehicle was stopped at approximately 4:18 p.m., just short of Dobey’s Motel. Corporal Davis asked respondent to step to the rear of her car, where he informed her that she had been stopped because she was suspected of carrying cocaine in the vehicle. He asked if they could look for cocaine, and respondent said they could look. The officers found a locked brown attaché case in the car, and, upon request, respondent provided the combination to the lock. The officers found marijuana in the attaché case and placed respondent under arrest. During processing at the station, the officers found three milligrams of cocaine in respondent’s purse.

Respondent was charged in Montgomery County Court with possession of marijuana and possession of cocaine. The trial court denied respondent’s motion to suppress, and she pleaded guilty to the charges, reserving the right to appeal the denial of her suppression motion. The Court of Criminal Appeals of Alabama concluded that respondent’s motion to dismiss should have been granted and reversed her conviction. The Supreme Court of Alabama denied the State’s petition for writ of certiorari. \[W]e granted the State’s petition for certiorari. We now reverse.

Reasonable suspicion is a less demanding standard than probable cause not only in the sense that reasonable suspicion can be established with information that is different in quantity or content than that required to establish probable cause, but also in the sense that reasonable suspicion can arise from information that is less reliable than that required to show probable cause. Reasonable suspicion, like probable cause, is dependent upon both the content of information possessed by police and its degree of reliability. Both factors—quantity and quality—are considered in the “totality of the circumstances—the whole picture” that must be taken into account when evaluating whether there is reasonable suspicion. Thus, if a tip has a relatively low degree of reliability, more information will be required to establish the requisite quantum of suspicion than would be required if the tip were more reliable. The \[_Illinois v._] _Gates_ Court applied its totality-of-the-circumstances approach in this manner, taking into account the facts known to the officers from personal observation, and giving the anonymous tip the weight it deserved in light of its indicia of reliability as established through independent police work. The same approach applies in the reasonable-suspicion context, the only difference being the level of suspicion that must be established. Contrary to the court below, we conclude that when the officers stopped respondent, the anonymous tip had been sufficiently corroborated to furnish reasonable suspicion that respondent was engaged in criminal activity and that the investigative stop therefore did not violate the Fourth Amendment.

It is true that not every detail mentioned by the tipster was verified, such as the name of the woman leaving the building or the precise apartment from which she left; but the officers did corroborate that a woman left the 235 building and got into the particular vehicle that was described by the caller. With respect to the time of departure predicted by the informant, Corporal Davis testified that the caller gave a particular time when the woman would be leaving, but he did not state what that time was. He did testify that, after the call, he and his partner proceeded to the Lynwood Terrace Apartments to put the 235 building under surveillance. Given the fact that the officers proceeded to the indicated address immediately after the call and that respondent emerged not too long thereafter, it appears from the record before us that respondent’s departure from the building was within the timeframe predicted by the caller. As for the caller’s prediction of respondent’s destination, it is true that the officers stopped her just short of Dobey’s Motel and did not know whether she would have pulled in or continued past it. But given that the 4-mile route driven by respondent was the most direct route possible to Dobey’s Motel but nevertheless involved several turns, we think respondent’s destination was significantly corroborated.

The Court’s opinion in _Gates_ gave credit to the proposition that because an informant is shown to be right about some things, he is probably right about other facts that he has alleged, including the claim that the object of the tip is engaged in criminal activity. Thus, it is not unreasonable to conclude in this case that the independent corroboration by the police of significant aspects of the informer’s predictions imparted some degree of reliability to the other allegations made by the caller.

We think it also important that, as in _Gates,_ “the anonymous \[tip] contained a range of details relating not just to easily obtained facts and conditions existing at the time of the tip, but to future actions of third parties ordinarily not easily predicted.” The fact that the officers found a car precisely matching the caller’s description in front of the 235 building is an example of the former. Anyone could have “predicted” that fact because it was a condition presumably existing at the time of the call. What was important was the caller’s ability to predict respondent’s _future behavior,_ because it demonstrated inside information—a special familiarity with respondent’s affairs. The general public would have had no way of knowing that respondent would shortly leave the building, get in the described car, and drive the most direct route to Dobey’s Motel. Because only a small number of people are generally privy to an individual’s itinerary, it is reasonable for police to believe that a person with access to such information is likely to also have access to reliable information about that individual’s illegal activities. When significant aspects of the caller’s predictions were verified, there was reason to believe not only that the caller was honest but also that he was well informed, at least well enough to justify the stop.

Although it is a close case, we conclude that under the totality of the circumstances the anonymous tip, as corroborated, exhibited sufficient indicia of reliability to justify the investigatory stop of respondent’s car. We therefore reverse the judgment of the Court of Criminal Appeals of Alabama and remand the case for further proceedings not inconsistent with this opinion.

## \[Dissent]

Justice STEVENS, with whom Justice BRENNAN and Justice MARSHALL join, dissenting.

Millions of people leave their apartments at about the same time every day carrying an attaché case and heading for a destination known to their neighbors. Usually, however, the neighbors do not know what the briefcase contains. An anonymous neighbor’s prediction about somebody’s time of departure and probable destination is anything but a reliable basis for assuming that the commuter is in possession of an illegal substance—particularly when the person is not even carrying the attaché case described by the tipster.

The record in this case does not tell us how often respondent drove from the Lynwood Terrace Apartments to Dobey’s Motel; for all we know, she may have been a room clerk or telephone operator working the evening shift. It does not tell us whether Officer Davis made any effort to ascertain the informer’s identity, his reason for calling, or the basis of his prediction about respondent’s destination. Indeed, for all that this record tells us, the tipster may well have been another police officer who had a “hunch” that respondent might have cocaine in her attaché case.

Anybody with enough knowledge about a given person to make her the target of a prank, or to harbor a grudge against her, will certainly be able to formulate a tip about her like the one predicting Vanessa White’s excursion. In addition, under the Court’s holding, every citizen is subject to being seized and questioned by any officer who is prepared to testify that the warrantless stop was based on an anonymous tip predicting whatever conduct the officer just observed. Fortunately, the vast majority of those in our law enforcement community would not adopt such a practice. But the Fourth Amendment was intended to protect the citizen from the overzealous and unscrupulous officer as well as from those who are conscientious and truthful. This decision makes a mockery of that protection.

I respectfully dissent.

\* \* \*

The stop in _White_ was made upon reasonable suspicion; then the suspect consented to the automobile search. Without consent, could the officer search the car? Why or why not?

In the next case, the Court distinguished _Alabama v. White_ and found that the information provided by a tipster did not justify a _Terry_ stop.

<details>

<summary>Attributions and Licensing</summary>

This page is adapted from [5.20: Chapter 21 - Reasonable Suspicion](https://biz.libretexts.org/Workbench/Criminal_Procedure/05%3A_The_Fourth_Amendment/5.20%3A_Chapter_21_-_Reasonable_Suspicion) by [Anne M Alexander](https://law.missouri.edu/directory/anne-alexander/) and [Ben Trachtenberg](https://law.missouri.edu/directory/ben-trachtenberg/), used under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0). The corresponding content is licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0).

</details>
