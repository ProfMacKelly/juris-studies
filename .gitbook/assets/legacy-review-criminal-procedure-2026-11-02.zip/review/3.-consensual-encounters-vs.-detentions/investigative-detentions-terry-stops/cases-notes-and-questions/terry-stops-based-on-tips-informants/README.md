> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-based-on-tips-informants) · Snapshot: 2026-11-02 · Original path: `3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-based-on-tips-informants`

---

# Terry Stops Based on Tips/Informants

Police rely on information volunteered by persons outside of law enforcement to conduct investigations. Witnesses to crimes, suspects themselves, and others willing to provide relevant information to help officers do their work. The Court has decided a handful of cases concerning how much a “tip” from an informant contributes to a finding of reasonable suspicion.
