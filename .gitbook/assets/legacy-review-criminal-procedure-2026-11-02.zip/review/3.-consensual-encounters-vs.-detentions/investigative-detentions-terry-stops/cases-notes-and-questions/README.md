> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions) · Snapshot: 2026-11-02 · Original path: `3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-procedure/consensual-encounters-vs.-detentions/cases-notes-and-questions) · [Candidate 2](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-procedure/investigative-detentions-terry-stops/cases-notes-and-questions)

---

# Cases, Notes & Questions

1. [_U.S. v. Mendenhall_](../consensual-encounters/cases-notes-and-questions/u.s.-v.-mendenhall)
2. [_California v. Hodari D._](../consensual-encounters/cases-notes-and-questions/california-v.-hodari-d.)
3. [_U.S. v. Lillich_](../consensual-encounters/cases-notes-and-questions/u.s.-v.-lillich)
