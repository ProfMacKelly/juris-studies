> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-of-vehicles) · Snapshot: 2026-11-02 · Original path: `3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/cases-notes-and-questions/terry-stops-of-vehicles`

---

# Terry Stops of Vehicles

