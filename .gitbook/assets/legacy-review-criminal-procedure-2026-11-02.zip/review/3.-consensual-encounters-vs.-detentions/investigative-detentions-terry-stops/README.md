> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops) · Snapshot: 2026-11-02 · Original path: `3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops`

---

# Investigative Detentions (Terry Stops)

## Contents

{% content-ref url="investigative-detentions-terry-stops/introduction" %}
[introduction](investigative-detentions-terry-stops/introduction)
{% endcontent-ref %}

{% content-ref url="investigative-detentions-terry-stops/prior-to-the-stop-requirements-and-justifications-for-investigative-detentions" %}
[prior-to-the-stop-requirements-and-justifications-for-investigative-detentions](investigative-detentions-terry-stops/prior-to-the-stop-requirements-and-justifications-for-investigative-detentions)
{% endcontent-ref %}

{% content-ref url="investigative-detentions-terry-stops/after-the-stop" %}
[after-the-stop](investigative-detentions-terry-stops/after-the-stop)
{% endcontent-ref %}

{% content-ref url="investigative-detentions-terry-stops/cases-notes-and-questions" %}
[cases-notes-and-questions](investigative-detentions-terry-stops/cases-notes-and-questions)
{% endcontent-ref %}

