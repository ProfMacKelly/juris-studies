> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop) · Snapshot: 2026-11-02 · Original path: `3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop`

---

# After the Stop

## Contents

{% content-ref url="after-the-stop/duration" %}
[duration](after-the-stop/duration)
{% endcontent-ref %}

{% content-ref url="after-the-stop/de-facto-arrests" %}
[de-facto-arrests](after-the-stop/de-facto-arrests)
{% endcontent-ref %}

{% content-ref url="after-the-stop/officer-procedures" %}
[officer-procedures](after-the-stop/officer-procedures)
{% endcontent-ref %}

{% content-ref url="after-the-stop/converting-detentions-into-consensual-encounters" %}
[converting-detentions-into-consensual-encounters](after-the-stop/converting-detentions-into-consensual-encounters)
{% endcontent-ref %}

