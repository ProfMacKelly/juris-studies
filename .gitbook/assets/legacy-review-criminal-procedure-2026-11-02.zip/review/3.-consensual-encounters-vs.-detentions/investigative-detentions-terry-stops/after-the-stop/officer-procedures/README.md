> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/officer-procedures) · Snapshot: 2026-11-02 · Original path: `3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/officer-procedures`

---

# Officer Procedures

Having discussed the basic principles that the courts apply in determining whether a detention was conducted in a reasonable manner, we will now look at how the courts have analyzed the various procedures that officers typically utilize in the course of investigative detentions.

## Contents

{% content-ref url="officer-procedures/using-force-to-detain" %}
[using-force-to-detain](officer-procedures/using-force-to-detain)
{% endcontent-ref %}

{% content-ref url="officer-procedures/safety-and-frisks" %}
[safety-and-frisks](officer-procedures/safety-and-frisks)
{% endcontent-ref %}

{% content-ref url="officer-procedures/identifying-detainees" %}
[identifying-detainees](officer-procedures/identifying-detainees)
{% endcontent-ref %}

{% content-ref url="officer-procedures/questioning-detainees" %}
[questioning-detainees](officer-procedures/questioning-detainees)
{% endcontent-ref %}

{% content-ref url="officer-procedures/showups" %}
[showups](officer-procedures/showups)
{% endcontent-ref %}

{% content-ref url="officer-procedures/transporting-detainees" %}
[transporting-detainees](officer-procedures/transporting-detainees)
{% endcontent-ref %}

{% content-ref url="officer-procedures/safety-and-frisks/terry-frisks" %}
[terry-frisks](officer-procedures/safety-and-frisks/terry-frisks)
{% endcontent-ref %}

{% content-ref url="officer-procedures/other-procedures" %}
[other-procedures](officer-procedures/other-procedures)
{% endcontent-ref %}

***

<details>

<summary>Attributions &#x26; Licensing</summary>

Unless otherwise indicated, this page's content is from [4.1 Investigative Detentions](https://workforce.libretexts.org/@go/page/16224) by [Larry Alvarez](https://www.canyons.edu/directory/larry-alvarez.php), used under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). This page is licensed under [CC BY 4.0](http://creativecommons.org/licenses/by/4.0/?ref=chooser-v1).

</details>
