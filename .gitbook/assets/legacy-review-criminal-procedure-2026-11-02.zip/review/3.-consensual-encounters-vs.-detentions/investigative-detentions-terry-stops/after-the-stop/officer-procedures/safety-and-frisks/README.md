> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/officer-procedures/safety-and-frisks) · Snapshot: 2026-11-02 · Original path: `3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops/after-the-stop/officer-procedures/safety-and-frisks`

---

# Safety & Frisks

## Contents

{% content-ref url="safety-and-frisks/safety-precautions" %}
[safety-precautions](safety-and-frisks/safety-precautions)
{% endcontent-ref %}

{% content-ref url="safety-and-frisks/terry-frisks" %}
[terry-frisks](safety-and-frisks/terry-frisks)
{% endcontent-ref %}

