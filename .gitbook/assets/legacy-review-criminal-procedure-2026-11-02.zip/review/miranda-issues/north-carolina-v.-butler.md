> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/miranda-issues/north-carolina-v.-butler) · Snapshot: 2026-11-02 · Original path: `miranda-issues/north-carolina-v.-butler`

---

# North Carolina v. Butler

Supreme Court of the United States

**North Carolina**&#x20;

**v.**&#x20;

**Willie Thomas Butler**

Decided April 24, 1979 – [441 U.S. 369](https://supreme.justia.com/cases/federal/us/441/369/)

Mr. Justice STEWART delivered the opinion of the Court.

In evident conflict with the present view of every other court that has considered the issue, the North Carolina Supreme Court has held that _Miranda v. Arizona_ requires that no statement of a person under custodial interrogation may be admitted in evidence against him unless, at the time the statement was made, he explicitly waived the right to the presence of a lawyer. We granted certiorari to consider whether this _per se_ rule reflects a proper understanding of the _Miranda_ decision.

The respondent was convicted in a North Carolina trial court of kidnaping, armed robbery, and felonious assault. The evidence at his trial showed that he and a man named Elmer Lee had robbed a gas station in Goldsboro, N.C., in December 1976, and had shot the station attendant as he was attempting to escape. The attendant was paralyzed, but survived to testify against the respondent.

The prosecution also produced evidence of incriminating statements made by the respondent shortly after his arrest by Federal Bureau of Investigation agents in the Bronx, N.Y., on the basis of a North Carolina fugitive warrant. Outside the presence of the jury, FBI Agent Martinez testified that at the time of the arrest he fully advised the respondent of the rights delineated in the _Miranda_ case. According to the uncontroverted testimony of Martinez, the agents then took the respondent to the FBI office in nearby New Rochelle, N.Y. There, after the agents determined that the respondent had an 11th grade education and was literate, he was given the Bureau’s “Advice of Rights” form which he read. When asked if he understood his rights, he replied that he did. The respondent refused to sign the waiver at the bottom of the form. He was told that he need neither speak nor sign the form, but that the agents would like him to talk to them. The respondent replied: “I will talk to you but I am not signing any form.” He then made inculpatory statements. Agent Martinez testified that the respondent said nothing when advised of his right to the assistance of a lawyer. At no time did the respondent request counsel or attempt to terminate the agents’ questioning.

At the conclusion of this testimony the respondent moved to suppress the evidence of his incriminating statements on the ground that he had not waived his right to the assistance of counsel at the time the statements were made. The court denied the motion, finding that

“the statement made by the defendant, William Thomas Butler, to Agent David C. Martinez, was made freely and voluntarily to said agent after having been advised of his rights as required by the _Miranda_ ruling, including his right to an attorney being present at the time of the inquiry and that the defendant, Butler, understood his rights; \[and] that he effectively waived his rights, including the right to have an attorney present during the questioning by his indication that he was willing to answer questions, having read the rights form together with the Waiver of Rights ….”

The respondent’s statements were then admitted into evidence, and the jury ultimately found the respondent guilty of each offense charged.

On appeal, the North Carolina Supreme Court reversed the convictions and ordered a new trial. It found that the statements had been admitted in violation of the requirements of the _Miranda_ decision, noting that the respondent had refused to waive in writing his right to have counsel present and that there had not been a _specific_ oral waiver.

We conclude that the North Carolina Supreme Court erred in its reading of the _Miranda_ opinion. \[T]he Court held that an express statement can constitute a waiver, and that silence alone after such warnings cannot do so. But the Court did not hold that such an express statement is indispensable to a finding of waiver.

An express written or oral statement of waiver of the right to remain silent or of the right to counsel is usually strong proof of the validity of that waiver, but is not inevitably either necessary or sufficient to establish waiver. The question is not one of form, but rather whether the defendant in fact knowingly and voluntarily waived the rights delineated in the _Miranda_ case. As was unequivocally said in _Miranda,_ mere silence is not enough. That does not mean that the defendant’s silence, coupled with an understanding of his rights and a course of conduct indicating waiver, may never support a conclusion that a defendant has waived his rights. The courts must presume that a defendant did not waive his rights; the prosecution’s burden is great; but in at least some cases waiver can be clearly inferred from the actions and words of the person interrogated.

The Court’s opinion in _Miranda_ explained the reasons for the prophylactic rules it created:

> We have concluded that without proper safeguards the process of in-custody interrogation of persons suspected or accused of crime contains inherently compelling pressures which work to undermine the individual’s will to resist and to compel him to speak where he would not otherwise do so freely. In order to combat these pressures and to permit a full opportunity to exercise the privilege against self-incrimination, the accused must be adequately and effectively apprised of his rights and the exercise of those rights must be fully honored.

The _per se_ rule that the North Carolina Supreme Court has found in _Miranda_ does not speak to these concerns. There is no doubt that this respondent was adequately and effectively apprised of his rights. The only question is whether he waived the exercise of one of those rights, the right to the presence of a lawyer. Neither the state court nor the respondent has offered any reason why there must be a negative answer to that question in the absence of an _express_ waiver. This is not the first criminal case to question whether a defendant waived his constitutional rights. It is an issue with which courts must repeatedly deal. Even when a right so fundamental as that to counsel at trial is involved, the question of waiver must be determined on “the particular facts and circumstances surrounding that case, including the background, experience, and conduct of the accused.”

We see no reason to discard that standard and replace it with an inflexible _per se_ rule in a case such as this. As stated at the outset of this opinion, it appears that every court that has considered this question has now reached the same conclusion. Ten of the eleven United States Courts of Appeals and the courts of at least 17 States have held that an explicit statement of waiver is not invariably necessary to support a finding that the defendant waived the right to remain silent or the right to counsel guaranteed by the _Miranda_ case. By creating an inflexible rule that no implicit waiver can ever suffice, the North Carolina Supreme Court has gone beyond the requirements of federal organic law. It follows that its judgment cannot stand, since a state court can neither add to nor subtract from the mandates of the United States Constitution.

Accordingly, the judgment is vacated, and the case is remanded to the North Carolina Supreme Court for further proceedings not inconsistent with this opinion.

### Mr. Justice BRENNAN, with whom Mr. Justice MARSHALL and Mr. Justice STEVENS joins, dissenting.

The rule announced by the Court today allows a finding of waiver based upon “infer\[ence] from the actions and words of the person interrogated.” The Court thus shrouds in half-light the question of waiver, allowing courts to construct inferences from ambiguous words and gestures. But the very premise of _Miranda_ requires that ambiguity be interpreted against the interrogator. That premise is the recognition of the “compulsion inherent in custodial” interrogation and of its purpose “to subjugate the individual to the will of \[his] examiner.” Under such conditions, only the most explicit waivers of rights can be considered knowingly and freely given.

The instant case presents a clear example of the need for an express waiver requirement. As the Court acknowledges, there is a disagreement over whether respondent was orally advised of his rights at the time he made his statement. The fact that Butler received a written copy of his rights is deemed by the Court to be sufficient basis to resolve the disagreement. But, unfortunately, there is also a dispute over whether Butler could read. And, obviously, if Butler did not have his rights read to him, and could not read them himself, there could be no basis upon which to conclude that he knowingly waived them. Indeed, even if Butler could read there is no reason to believe that his oral statements, which followed a refusal to sign a written waiver form, were intended to signify relinquishment of his rights.

Faced with “actions and words” of uncertain meaning, some judges may find waivers where none occurred. Others may fail to find them where they did. In the former case, the defendant’s rights will have been violated; in the latter, society’s interest in effective law enforcement will have been frustrated. A simple prophylactic rule requiring the police to obtain an express waiver of the right to counsel before proceeding with interrogation eliminates these difficulties. And since the Court agrees that _Miranda_ requires the police to obtain some kind of waiver—whether express or implied—the requirement of an express waiver would impose no burden on the police not imposed by the Court’s interpretation. It would merely make that burden explicit. Had Agent Martinez simply elicited a clear answer from Willie Butler to the question, “Do you waive your right to a lawyer?” this journey through three courts would not have been necessary.
