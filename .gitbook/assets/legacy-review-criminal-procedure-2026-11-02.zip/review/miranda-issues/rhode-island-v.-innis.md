> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/miranda-issues/rhode-island-v.-innis) · Snapshot: 2026-11-02 · Original path: `miranda-issues/rhode-island-v.-innis`

---

# Rhode Island v. Innis

Supreme Court of the United States

**Rhode Island**&#x20;

**v.**&#x20;

**Thomas J. Innis**

[446 U.S. 291](https://supreme.justia.com/cases/federal/us/446/291/) (1980)

Mr. Justice STEWART delivered the opinion of the Court.

In _Miranda v. Arizona_, the Court held that, once a defendant in custody asks to speak with a lawyer, all interrogation must cease until a lawyer is present. The issue in this case is whether the respondent was “interrogated” in violation of the standards promulgated in the _Miranda_ opinion.

### **I**

On the night of January 12, 1975, John Mulvaney, a Providence, R.I., taxicab driver, disappeared after being dispatched to pick up a customer. His body was discovered four days later buried in a shallow grave in Coventry, R.I. He had died from a shotgun blast aimed at the back of his head.

On January 17, 1975, shortly after midnight, the Providence police received a telephone call from Gerald Aubin, also a taxicab driver, who reported that he had just been robbed by a man wielding a sawed-off shotgun. Aubin further reported that he had dropped off his assailant near Rhode Island College in a section of Providence known as Mount Pleasant. While at the Providence police station waiting to give a statement, Aubin noticed a picture of his assailant on a bulletin board. Aubin so informed one of the police officers present. The officer prepared a photo array, and again Aubin identified a picture of the same person. That person was the respondent. Shortly thereafter, the Providence police began a search of the Mount Pleasant area.

At approximately 4:30 a.m. on the same date, Patrolman Lovell, while cruising the streets of Mount Pleasant in a patrol car, spotted the respondent standing in the street facing him. When Patrolman Lovell stopped his car, the respondent walked towards it. Patrolman Lovell then arrested the respondent, who was unarmed, and advised him of his so-called _Miranda_ rights. While the two men waited in the patrol car for other police officers to arrive, Patrolman Lovell did not converse with the respondent other than to respond to the latter’s request for a cigarette.

Within minutes, Sergeant Sears arrived at the scene of the arrest, and he also gave the respondent the _Miranda_ warnings. Immediately thereafter, Captain Leyden and other police officers arrived. Captain Leyden advised the respondent of his _Miranda_ rights. The respondent stated that he understood those rights and wanted to speak with a lawyer. Captain Leyden then directed that the respondent be placed in a “caged wagon,” a four-door police car with a wire screen mesh between the front and rear seats, and be driven to the central police station. Three officers, Patrolmen Gleckman, Williams, and McKenna, were assigned to accompany the respondent to the central station. They placed the respondent in the vehicle and shut the doors. Captain Leyden then instructed the officers not to question the respondent or intimidate or coerce him in any way. The three officers then entered the vehicle, and it departed.

While en route to the central station, Patrolman Gleckman initiated a conversation with Patrolman McKenna concerning the missing shotgun. As Patrolman Gleckman later testified:

“A. At this point, I was talking back and forth with Patrolman McKenna stating that I frequent this area while on patrol and \[that because a school for handicapped children is located nearby,] there’s a lot of handicapped children running around in this area, and God forbid one of them might find a weapon with shells and they might hurt themselves.”

Patrolman McKenna apparently shared his fellow officer’s concern:

“A. I more or less concurred with him \[Gleckman] that it was a safety factor and that we should, you know, continue to search for the weapon and try to find it.”

While Patrolman Williams said nothing, he overheard the conversation between the two officers:

“A. He \[Gleckman] said it would be too bad if the little—I believe he said a girl—would pick up the gun, maybe kill herself.”

The respondent then interrupted the conversation, stating that the officers should turn the car around so he could show them where the gun was located. At this point, Patrolman McKenna radioed back to Captain Leyden that they were returning to the scene of the arrest and that the respondent would inform them of the location of the gun. At the time the respondent indicated that the officers should turn back, they had traveled no more than a mile, a trip encompassing only a few minutes.

The police vehicle then returned to the scene of the arrest where a search for the shotgun was in progress. There, Captain Leyden again advised the respondent of his _Miranda_ rights. The respondent replied that he understood those rights but that he “wanted to get the gun out of the way because of the kids in the area in the school.” The respondent then led the police to a nearby field, where he pointed out the shotgun under some rocks by the side of the road.

On March 20, 1975, a grand jury returned an indictment charging the respondent with the kidnaping, robbery, and murder of John Mulvaney. Before trial, the respondent moved to suppress the shotgun and the statements he had made to the police regarding it. After an evidentiary hearing at which the respondent elected not to testify, the trial judge found that the respondent had been “repeatedly and completely advised of his _Miranda_ rights.” He further found that it was “entirely understandable that \[the officers in the police vehicle] would voice their concern \[for the safety of the handicapped children] to each other.” The judge then concluded that the respondent’s decision to inform the police of the location of the shotgun was “a waiver, clearly, and on the basis of the evidence that I have heard, and \[_sic_] intelligent waiver, of his \[_Miranda_] right to remain silent.” Thus, without passing on whether the police officers had in fact “interrogated” the respondent, the trial court sustained the admissibility of the shotgun and testimony related to its discovery. That evidence was later introduced at the respondent’s trial, and the jury returned a verdict of guilty on all counts.

On appeal, the Rhode Island Supreme Court, in a 3–2 decision, set aside the respondent’s conviction. \[T]he court concluded that the respondent had invoked his _Miranda_ right to counsel and that, contrary to _Miranda’_&#x73; mandate that, in the absence of counsel, all custodial interrogation then cease, the police officers in the vehicle had “interrogated” the respondent without a valid waiver of his right to counsel. It was the view of the state appellate court that, even though the police officers may have been genuinely concerned about the public safety and even though the respondent had not been addressed personally by the police officers, the respondent nonetheless had been subjected to “subtle coercion” that was the equivalent of “interrogation” within the meaning of the _Miranda_ opinion. Moreover, contrary to the holding of the trial court, the appellate court concluded that the evidence was insufficient to support a finding of waiver. Having concluded that both the shotgun and testimony relating to its discovery were obtained in violation of the _Miranda_ standards and therefore should not have been admitted into evidence, the Rhode Island Supreme Court held that the respondent was entitled to a new trial.

We granted certiorari to address for the first time the meaning of “interrogation” under _Miranda v. Arizona_.

### **II**

The Court in the _Miranda_ opinion \[] outlined in some detail the consequences that would result if a defendant sought to invoke those procedural safeguards. With regard to the right to the presence of counsel, the Court noted:

“Once warnings have been given, the subsequent procedure is clear. … If the individual states that he wants an attorney, the interrogation must cease until an attorney is present. At that time, the individual must have an opportunity to confer with the attorney and to have him present during any subsequent questioning. If the individual cannot obtain an attorney and he indicates that he wants one before speaking to police, they must respect his decision to remain silent.”

In the present case, the parties are in agreement that the respondent was fully informed of his _Miranda_ rights and that he invoked his _Miranda_ right to counsel when he told Captain Leyden that he wished to consult with a lawyer. It is also uncontested that the respondent was “in custody” while being transported to the police station.

The issue, therefore, is whether the respondent was “interrogated” by the police officers in violation of the respondent’s undisputed right under _Miranda_ to remain silent until he had consulted with a lawyer. In resolving this issue, we first define the term “interrogation” under _Miranda_ before turning to a consideration of the facts of this case.

#### **A**

The starting point for defining “interrogation” in this context is, of course, the Court’s _Miranda_ opinion. There the Court observed that “\[b]y custodial interrogation, we mean _questioning_ initiated by law enforcement officers after a person has been taken into custody or otherwise deprived of his freedom of action in any significant way.” This passage and other references throughout the opinion to “questioning” might suggest that the _Miranda_ rules were to apply only to those police interrogation practices that involve express questioning of a defendant while in custody.

We do not, however, construe the _Miranda_ opinion so narrowly. The concern of the Court in _Miranda_ was that the “interrogation environment” created by the interplay of interrogation and custody would “subjugate the individual to the will of his examiner” and thereby undermine the privilege against compulsory self-incrimination. The police practices that evoked this concern included several that did not involve express questioning. For example, one of the practices discussed in _Miranda_ was the use of line-ups in which a coached witness would pick the defendant as the perpetrator. This was designed to establish that the defendant was in fact guilty as a predicate for further interrogation. A variation on this theme discussed in _Miranda_ was the so-called “reverse line-up” in which a defendant would be identified by coached witnesses as the perpetrator of a fictitious crime, with the object of inducing him to confess to the actual crime of which he was suspected in order to escape the false prosecution. The Court in _Miranda_ also included in its survey of interrogation practices the use of psychological ploys, such as to “posi\[t]” “the guilt of the subject,” to “minimize the moral seriousness of the offense,” and “to cast blame on the victim or on society.” It is clear that these techniques of persuasion, no less than express questioning, were thought, in a custodial setting, to amount to interrogation.

This is not to say, however, that all statements obtained by the police after a person has been taken into custody are to be considered the product of interrogation. It is clear \[] that the special procedural safeguards outlined in _Miranda_ are required not where a suspect is simply taken into custody, but rather where a suspect in custody is subjected to interrogation. “Interrogation,” as conceptualized in the _Miranda_ opinion, must reflect a measure of compulsion above and beyond that inherent in custody itself.

We conclude that the _Miranda_ safeguards come into play whenever a person in custody is subjected to either express questioning or its functional equivalent. That is to say, the term “interrogation” under _Miranda_ refers not only to express questioning, but also to any words or actions on the part of the police (other than those normally attendant to arrest and custody) that the police should know are reasonably likely to elicit an incriminating response from the suspect. The latter portion of this definition focuses primarily upon the perceptions of the suspect, rather than the intent of the police. This focus reflects the fact that the _Miranda_ safeguards were designed to vest a suspect in custody with an added measure of protection against coercive police practices, without regard to objective proof of the underlying intent of the police. A practice that the police should know is reasonably likely to evoke an incriminating response from a suspect thus amounts to interrogation.<sup>1</sup> But, since the police surely cannot be held accountable for the unforeseeable results of their words or actions, the definition of interrogation can extend only to words or actions on the part of police officers that they _should have known_ were reasonably likely to elicit an incriminating response.

#### **B**

Turning to the facts of the present case, we conclude that the respondent was not “interrogated” within the meaning of _Miranda_. It is undisputed that the first prong of the definition of “interrogation” was not satisfied, for the conversation between Patrolmen Gleckman and McKenna included no express questioning of the respondent. Rather, that conversation was, at least in form, nothing more than a dialogue between the two officers to which no response from the respondent was invited.

Moreover, it cannot be fairly concluded that the respondent was subjected to the “functional equivalent” of questioning. It cannot be said, in short, that Patrolmen Gleckman and McKenna should have known that their conversation was reasonably likely to elicit an incriminating response from the respondent. There is nothing in the record to suggest that the officers were aware that the respondent was peculiarly susceptible to an appeal to his conscience concerning the safety of handicapped children. Nor is there anything in the record to suggest that the police knew that the respondent was unusually disoriented or upset at the time of his arrest.

The case thus boils down to whether, in the context of a brief conversation, the officers should have known that the respondent would suddenly be moved to make a self-incriminating response. Given the fact that the entire conversation appears to have consisted of no more than a few off hand remarks, we cannot say that the officers should have known that it was reasonably likely that Innis would so respond. This is not a case where the police carried on a lengthy harangue in the presence of the suspect. Nor does the record support the respondent’s contention that, under the circumstances, the officers’ comments were particularly “evocative.” It is our view, therefore, that the respondent was not subjected by the police to words or actions that the police should have known were reasonably likely to elicit an incriminating response from him.

The Rhode Island Supreme Court erred, in short, in equating “subtle compulsion” with interrogation. That the officers’ comments struck a responsive chord is readily apparent. Thus, it may be said, as the Rhode Island Supreme Court did say, that the respondent was subjected to “subtle compulsion.” But that is not the end of the inquiry. It must also be established that a suspect’s incriminating response was the product of words or actions on the part of the police that they should have known were reasonably likely to elicit an incriminating response. This was not established in the present case.

For the reasons stated, the judgment of the Supreme Court of Rhode Island is vacated, and the case is remanded to that court for further proceedings not inconsistent with this opinion.

### Mr. Justice MARSHALL, with whom Mr. Justice BRENNAN joins, dissenting.

I am substantially in agreement with the Court’s definition of “interrogation” within the meaning of _Miranda v. Arizona_.

I am utterly at a loss, however, to understand how this objective standard as applied to the facts before us can rationally lead to the conclusion that there was no interrogation. Innis was arrested at 4:30 a.m., handcuffed, searched, advised of his rights, and placed in the back seat of a patrol car. Within a short time he had been twice more advised of his rights and driven away in a four-door sedan with three police officers. Two officers sat in the front seat and one sat beside Innis in the back seat. Since the car traveled no more than a mile before Innis agreed to point out the location of the murder weapon, Officer Gleckman must have begun almost immediately to talk about the search for the shotgun.

The Court attempts to characterize Gleckman’s statements as “no more than a few off hand remarks” which could not reasonably have been expected to elicit a response. If the statements had been addressed to respondent, it would be impossible to draw such a conclusion. The simple message of the “talking back and forth” between Gleckman and McKenna was that they had to find the shotgun to avert a child’s death.

One can scarcely imagine a stronger appeal to the conscience of a suspect—_any_ suspect—than the assertion that if the weapon is not found an innocent person will be hurt or killed. And not just any innocent person, but an innocent child—a little girl—a helpless, handicapped little girl on her way to school. The notion that such an appeal could not be expected to have any effect unless the suspect were known to have some special interest in handicapped children verges on the ludicrous. As a matter of fact, the appeal to a suspect to confess for the sake of others, to “display some evidence of decency and honor,” is a classic interrogation technique.

Gleckman’s remarks would obviously have constituted interrogation if they had been explicitly directed to respondent, and the result should not be different because they were nominally addressed to McKenna. This is not a case where police officers speaking among themselves are accidentally overheard by a suspect. These officers were “talking back and forth” in close quarters with the handcuffed suspect, traveling past the very place where they believed the weapon was located. They knew respondent would hear and attend to their conversation, and they are chargeable with knowledge of and responsibility for the pressures to speak which they created.

I firmly believe that this case is simply an aberration, and that in future cases the Court will apply the standard adopted today in accordance with its plain meaning.

### Mr. Justice STEVENS, dissenting.

An original definition of an old term coupled with an original finding of fact on a cold record makes it possible for this Court to vacate the judgment of the Supreme Court of Rhode Island. That court, on the basis of the facts in the record before it, concluded that members of the Providence, R.I., police force had interrogated respondent, who was clearly in custody at the time, in the absence of counsel after he had requested counsel. In my opinion the state court’s conclusion that there was interrogation rests on a proper interpretation of both the facts and the law; thus, its determination that the products of the interrogation were inadmissible at trial should be affirmed.

In short, in order to give full protection to a suspect’s right to be free from any interrogation at all, the definition of “interrogation” must include any police statement or conduct that has the same purpose or effect as a direct question. Statements that appear to call for a response from the suspect, as well as those that are designed to do so, should be considered interrogation. By prohibiting only those relatively few statements or actions that a police officer should know are likely to elicit an incriminating response, the Court today accords a suspect considerably less protection. Indeed, since I suppose most suspects are unlikely to incriminate themselves even when questioned directly, this new definition will almost certainly exclude every statement that is not punctuated with a question mark from the concept of “interrogation.”

The difference between the approach required by a faithful adherence to _Miranda_ and the stinted test applied by the Court today can be illustrated by comparing three different ways in which Officer Gleckman could have communicated his fears about the possible dangers posed by the shotgun to handicapped children. He could have:

1. directly asked Innis: "Will you please tell me where the shotgun is so we can protect handicapped school children from danger?"
2. announced to the other officers in the wagon: "If the man sitting in the back seat with me should decide to tell us where the gun is, we can protect handicapped children from danger."

or

3. stated to the other officers: "It would be too bad if a little handicapped girl would pick up the gun that this man left in the area and maybe kill herself."

In my opinion, all three of these statements should be considered interrogation because all three appear to be designed to elicit a response from anyone who in fact knew where the gun was located. Under the Court’s test, on the other hand, the form of the statements would be critical. The third statement would not be interrogation because in the Court’s view there was no reason for Officer Gleckman to believe that Innis was susceptible to this type of an implied appeal; therefore, the statement would not be reasonably likely to elicit an incriminating response. Assuming that this is true, then it seems to me that the first two statements, which would be just as unlikely to elicit such a response, should also not be considered interrogation. But, because the first statement is clearly an express question, it _would_ be considered interrogation under the Court’s test. The second statement, although just as clearly a deliberate appeal to Innis to reveal the location of the gun, would presumably not be interrogation because (a) it was not in form a direct question and (b) it does not fit within the “reasonably likely to elicit an incriminating response” category that applies to indirect interrogation.

As this example illustrates, the Court’s test creates an incentive for police to ignore a suspect’s invocation of his rights in order to make continued attempts to extract information from him. If a suspect does not appear to be susceptible to a particular type of psychological pressure, the police are apparently free to exert that pressure on him despite his request for counsel, so long as they are careful not to punctuate their statements with question marks. And if, contrary to all reasonable expectations, the suspect makes an incriminating statement, that statement can be used against him at trial. The Court thus turns _Miranda’s_ unequivocal rule against any interrogation at all into a trap in which unwary suspects may be caught by police deception.
