> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/miranda-issues) · Snapshot: 2026-11-02 · Original path: `miranda-issues`

---

# Miranda Issues

### **Cases for Class Discussion**

**What Is Custody?**

* [_Oregon v. Mathiason_](miranda-issues/oregon-v.-mathiason)
* [_J.D.B. v. North Carolina_](miranda-issues/j.d.b.-v.-north-carolina)

**What is Interrogation?**

* [_Rhode Island v. Innis_](miranda-issues/rhode-island-v.-innis)
* [_Illinois v. Perkins_](miranda-issues/illinois-v.-perkins)

**Waiver**

* [_North Carolina v. Butler_](miranda-issues/north-carolina-v.-butler)
* [_Colorado v. Spring_](miranda-issues/colorado-v.-spring)
*   [_Moran v. Burbine_](miranda-issues/moran-v.-burdine)

    <br>

### Miscellaneous Readings

{% file src="https://2693790834-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F6Bqz3QmhzbBYM9Y3OuYd%2Fuploads%2F3qlF5or5TLT1haYNgBhq%2FMiranda_-_When_Compliance_Is_Compulsory.pdf?alt=media&token=e8785c88-bdf9-43cf-ae38-67199b0a2c1c" %}

{% file src="https://2693790834-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F6Bqz3QmhzbBYM9Y3OuYd%2Fuploads%2F1E9dVrahsOIXVsnthQxw%2FMiranda_Waivers.pdf?alt=media&token=77ab1bea-74bc-43fe-ac26-409aa17c7288" %}

{% file src="https://2693790834-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F6Bqz3QmhzbBYM9Y3OuYd%2Fuploads%2F094pjTUa8KM2ZGNSWpcO%2F5th%20-%206th%20Amendments.pdf?alt=media&token=4c661f9a-b92e-4ac7-b5c5-340333160692" %}
_From_ [_Legal Training Handbook_](https://www.fletc.gov/sites/default/files/25_0106-LEG-LegalTrainingHandbook.pdf) _(2025) by Federal Lawful Enforcement Training Centers, Office of Chief Counsel_
{% endfile %}
