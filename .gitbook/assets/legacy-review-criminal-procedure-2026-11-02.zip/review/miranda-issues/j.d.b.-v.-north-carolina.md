> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/miranda-issues/j.d.b.-v.-north-carolina) · Snapshot: 2026-11-02 · Original path: `miranda-issues/j.d.b.-v.-north-carolina`

---

# J.D.B. v. North Carolina

Supreme Court of the United States

**J.D.B.**&#x20;

**v.**&#x20;

**North Carolina**

[564 U.S. 261](https://supreme.justia.com/cases/federal/us/564/261/) (2011)

Justice SOTOMAYOR delivered the opinion of the Court.

This case presents the question whether the age of a child subjected to police questioning is relevant to the custody analysis of _Miranda v. Arizona_. It is beyond dispute that children will often feel bound to submit to police questioning when an adult in the same circumstances would feel free to leave. Seeing no reason for police officers or courts to blind themselves to that commonsense reality, we hold that a child’s age properly informs the _Miranda_ custody analysis.

### **I**

#### **A**

Petitioner J.D.B. was a 13-year-old, seventh-grade student attending class at Smith Middle School in Chapel Hill, North Carolina when he was removed from his classroom by a uniformed police officer, escorted to a closed-door conference room, and questioned by police for at least half an hour.

This was the second time that police questioned J.D.B. in the span of a week. Five days earlier, two home break-ins occurred, and various items were stolen. Police stopped and questioned J.D.B. after he was seen behind a residence in the neighborhood where the crimes occurred. That same day, police also spoke to J.D.B.’s grandmother—his legal guardian—as well as his aunt.

Police later learned that a digital camera matching the description of one of the stolen items had been found at J.D.B.’s middle school and seen in J.D.B.’s possession. Investigator DiCostanzo, the juvenile investigator with the local police force who had been assigned to the case, went to the school to question J.D.B. Upon arrival, DiCostanzo informed the uniformed police officer on detail to the school (a so-called school resource officer), the assistant principal, and an administrative intern that he was there to question J.D.B. about the break-ins. Although DiCostanzo asked the school administrators to verify J.D.B.’s date of birth, address, and parent contact information from school records, neither the police officers nor the school administrators contacted J.D.B.’s grandmother.

The uniformed officer interrupted J.D.B.’s afternoon social studies class, removed J.D.B. from the classroom, and escorted him to a school conference room. There, J.D.B. was met by DiCostanzo, the assistant principal, and the administrative intern. The door to the conference room was closed. With the two police officers and the two administrators present, J.D.B. was questioned for the next 30 to 45 minutes. Prior to the commencement of questioning, J.D.B. was given neither _Miranda_ warnings nor the opportunity to speak to his grandmother. Nor was he informed that he was free to leave the room.

Questioning began with small talk—discussion of sports and J.D.B.’s family life. DiCostanzo asked, and J.D.B. agreed, to discuss the events of the prior weekend. Denying any wrongdoing, J.D.B. explained that he had been in the neighborhood where the crimes occurred because he was seeking work mowing lawns. DiCostanzo pressed J.D.B. for additional detail about his efforts to obtain work; asked J.D.B. to explain a prior incident, when one of the victims returned home to find J.D.B. behind her house; and confronted J.D.B. with the stolen camera. The assistant principal urged J.D.B. to “do the right thing,” warning J.D.B. that “the truth always comes out in the end.”

Eventually, J.D.B. asked whether he would “still be in trouble” if he returned the “stuff.” In response, DiCostanzo explained that return of the stolen items would be helpful, but “this thing is going to court” regardless. DiCostanzo then warned that he may need to seek a secure custody order if he believed that J.D.B. would continue to break into other homes. When J.D.B. asked what a secure custody order was, DiCostanzo explained that “it’s where you get sent to juvenile detention before court.”

After learning of the prospect of juvenile detention, J.D.B. confessed that he and a friend were responsible for the break-ins. DiCostanzo only then informed J.D.B. that he could refuse to answer the investigator’s questions and that he was free to leave. Asked whether he understood, J.D.B. nodded and provided further detail, including information about the location of the stolen items. Eventually J.D.B. wrote a statement, at DiCostanzo’s request. When the bell rang indicating the end of the schoolday, J.D.B. was allowed to leave to catch the bus home.

#### **B**

Two juvenile petitions were filed against J.D.B., each alleging one count of breaking and entering and one count of larceny. J.D.B.’s public defender moved to suppress his statements and the evidence derived therefrom, arguing that suppression was necessary because J.D.B. had been “interrogated by police in a custodial setting without being afforded _Miranda_ warning\[s]” and because his statements were involuntary under the totality of the circumstances test. After a suppression hearing at which DiCostanzo and J.D.B. testified, the trial court denied the motion, deciding that J.D.B. was not in custody at the time of the schoolhouse interrogation and that his statements were voluntary. As a result, J.D.B. entered a transcript of admission to all four counts, renewing his objection to the denial of his motion to suppress, and the court adjudicated J.D.B. delinquent.

A divided panel of the North Carolina Court of Appeals affirmed. The North Carolina Supreme Court held, over two dissents, that J.D.B. was not in custody when he confessed, “declin\[ing] to extend the test for custody to include consideration of the age … of an individual subjected to questioning by police.” We granted certiorari to determine whether the _Miranda_ custody analysis includes consideration of a juvenile suspect’s age.

### **II**

#### **A**

Any police interview of an individual suspected of a crime has “coercive aspects to it.” Only those interrogations that occur while a suspect is in police custody, however, “heighte\[n] the risk” that statements obtained are not the product of the suspect’s free choice.

By its very nature, custodial police interrogation entails “inherently compelling pressures.” Even for an adult, the physical and psychological isolation of custodial interrogation can “undermine the individual’s will to resist and … compel him to speak where he would not otherwise do so freely.” Indeed, the pressure of custodial interrogation is so immense that it “can induce a frighteningly high percentage of people to confess to crimes they never committed.” That risk is all the more troubling—and recent studies suggest, all the more acute—when the subject of custodial interrogation is a juvenile.

Recognizing that the inherently coercive nature of custodial interrogation “blurs the line between voluntary and involuntary statements,” this Court in _Miranda_ adopted a set of prophylactic measures designed to safeguard the constitutional guarantee against self-incrimination. Because these measures protect the individual against the coercive nature of custodial interrogation, they are required “‘only where there has been such a restriction on a person’s freedom as to render him “in custody.”’” As we have repeatedly emphasized, whether a suspect is “in custody” is an objective inquiry.

The benefit of the objective custody analysis is that it is “designed to give clear guidance to the police.”

#### **B**

The State and its _amici_ contend that a child’s age has no place in the custody analysis, no matter how young the child subjected to police questioning. We cannot agree. In some circumstances, a child’s age “would have affected how a reasonable person” in the suspect’s position “would perceive his or her freedom to leave.” That is, a reasonable child subjected to police questioning will sometimes feel pressured to submit when a reasonable adult would feel free to go. We think it clear that courts can account for that reality without doing any damage to the objective nature of the custody analysis.

A child’s age is far “more than a chronological fact.” It is a fact that “generates commonsense conclusions about behavior and perception.” Such conclusions apply broadly to children as a class. And, they are self-evident to anyone who was a child once himself, including any police officer or judge.

Time and again, this Court has drawn these commonsense conclusions for itself. We have observed that children “generally are less mature and responsible than adults,” that they “often lack the experience, perspective, and judgment to recognize and avoid choices that could be detrimental to them,” that they “are more vulnerable or susceptible to … outside pressures” than adults, and so on. Addressing the specific context of police interrogation, we have observed that events that “would leave a man cold and unimpressed can overawe and overwhelm a lad in his early teens.” Describing no one child in particular, these observations restate what “any parent knows”—indeed, what any person knows—about children generally.

Our various statements to this effect are far from unique. The law has historically reflected the same assumption that children characteristically lack the capacity to exercise mature judgment and possess only an incomplete ability to understand the world around them. Like this Court’s own generalizations, the legal disqualifications placed on children as a class—_e.g.,_ limitations on their ability to alienate property, enter a binding contract enforceable against them, and marry without parental consent—exhibit the settled understanding that the differentiating characteristics of youth are universal.

Indeed, even where a “reasonable person” standard otherwise applies, the common law has reflected the reality that children are not adults. In negligence suits, for instance, where liability turns on what an objectively reasonable person would do in the circumstances, “\[a]ll American jurisdictions accept the idea that a person’s childhood is a relevant circumstance” to be considered.

As this discussion establishes, “\[o]ur history is replete with laws and judicial recognition” that children cannot be viewed simply as miniature adults. We see no justification for taking a different course here\[,] \[s]o long as the child’s age was known to the officer at the time of the interview, or would have been objectively apparent to any reasonable officer. The same “wide basis of community experience” that makes it possible, as an objective matter, “to determine what is to be expected” of children in other contexts likewise makes it possible to know what to expect of children subjected to police questioning.

In other words, a child’s age differs from other personal characteristics that, even when known to police, have no objectively discernible relationship to a reasonable person’s understanding of his freedom of action. Precisely because childhood yields objective conclusions like those we have drawn ourselves—among others, that children are “most susceptible to influence” and “outside pressures,”—considering age in the custody analysis in no way involves a determination of how youth “subjectively affect\[s] the mindset” of any particular child.

In fact, in many cases involving juvenile suspects, the custody analysis would be nonsensical absent some consideration of the suspect’s age. This case is a prime example. Were the court precluded from taking J.D.B.’s youth into account, it would be forced to evaluate the circumstances present here through the eyes of a reasonable person of average years. In other words, how would a reasonable adult understand his situation, after being removed from a seventh-grade social studies class by a uniformed school resource officer; being encouraged by his assistant principal to “do the right thing”; and being warned by a police investigator of the prospect of juvenile detention and separation from his guardian and primary caretaker? To describe such an inquiry is to demonstrate its absurdity. Neither officers nor courts can reasonably evaluate the effect of objective circumstances that, by their nature, are specific to children without accounting for the age of the child subjected to those circumstances.

Indeed, the effect of the schoolhouse setting cannot be disentangled from the identity of the person questioned. A student—whose presence at school is compulsory and whose disobedience at school is cause for disciplinary action—is in a far different position than, say, a parent volunteer on school grounds to chaperone an event, or an adult from the community on school grounds to attend a basketball game. Without asking whether the person “questioned in school” is a “minor,” the coercive effect of the schoolhouse setting is unknowable.

Reviewing the question _de novo_ today, we hold that so long as the child’s age was known to the officer at the time of police questioning, or would have been objectively apparent to a reasonable officer, its inclusion in the custody analysis is consistent with the objective nature of that test. This is not to say that a child’s age will be a determinative, or even a significant, factor in every case. It is, however, a reality that courts cannot simply ignore.

The question remains whether J.D.B. was in custody when police interrogated him. We remand for the state courts to address that question, this time taking account of all of the relevant circumstances of the interrogation, including J.D.B.’s age at the time. The judgment of the North Carolina Supreme Court is reversed, and the case is remanded for proceedings not inconsistent with this opinion.

### **Justice ALITO, with whom THE CHIEF JUSTICE, Justice SCALIA, and Justice THOMAS join, dissenting.**

The Court’s decision in this case may seem on first consideration to be modest and sensible, but in truth it is neither. It is fundamentally inconsistent with one of the main justifications for the _Miranda_ rule: the perceived need for a clear rule that can be easily applied in all cases. And today’s holding is not needed to protect the constitutional rights of minors who are questioned by the police.

_Miranda’_&#x73; prophylactic regime places a high value on clarity and certainty. Dissatisfied with the highly fact-specific constitutional rule against the admission of involuntary confessions, the _Miranda_ Court set down rigid standards that often require courts to ignore personal characteristics that may be highly relevant to a particular suspect’s actual susceptibility to police pressure. This rigidity, however, has brought with it one of _Miranda’_&#x73; principal strengths—“the ease and clarity of its application” by law enforcement officials and courts. A key contributor to this clarity, at least up until now, has been _Miranda’_&#x73; objective reasonable-person test for determining custody.

_Miranda_’s custody requirement is based on the proposition that the risk of unconstitutional coercion is heightened when a suspect is placed under formal arrest or is subjected to some functionally equivalent limitation on freedom of movement. When this custodial threshold is reached, _Miranda_ warnings must precede police questioning. But in the interest of simplicity, the custody analysis considers only whether, under the circumstances, a hypothetical reasonable person would consider himself to be confined.

Many suspects, of course, will differ from this hypothetical reasonable person. Some, including those who have been hardened by past interrogations, may have no need for _Miranda_ warnings at all. And for other suspects—those who are unusually sensitive to the pressures of police questioning—_Miranda_ warnings may come too late to be of any use. That is a necessary consequence of _Miranda’_&#x73; rigid standards, but it does not mean that the constitutional rights of these especially sensitive suspects are left unprotected. A vulnerable defendant can still turn to the constitutional rule against _actual_ coercion and contend that that his confession was extracted against his will.

Today’s decision shifts the _Miranda_ custody determination from a one-size-fits-all reasonable-person test into an inquiry that must account for at least one individualized characteristic—age—that is thought to correlate with susceptibility to coercive pressures. Age, however, is in no way the only personal characteristic that may correlate with pliability, and in future cases the Court will be forced to choose between two unpalatable alternatives. It may choose to limit today’s decision by arbitrarily distinguishing a suspect’s age from other personal characteristics—such as intelligence, education, occupation, or prior experience with law enforcement—that may also correlate with susceptibility to coercive pressures. Or, if the Court is unwilling to draw these arbitrary lines, it will be forced to effect a fundamental transformation of the _Miranda_ custody test—from a clear, easily applied prophylactic rule into a highly fact-intensive standard resembling the voluntariness test that the _Miranda_ Court found to be unsatisfactory.

For at least three reasons, there is no need to go down this road. First, many minors subjected to police interrogation are near the age of majority, and for these suspects the one-size-fits-all _Miranda_ custody rule may not be a bad fit. Second, many of the difficulties in applying the _Miranda_ custody rule to minors arise because of the unique circumstances present when the police conduct interrogations at school. The _Miranda_ custody rule has always taken into account the setting in which questioning occurs, and accounting for the school setting in such cases will address many of these problems. Third, in cases like the one now before us, where the suspect is especially young, courts applying the constitutional voluntariness standard can take special care to ensure that incriminating statements were not obtained through coercion. Safeguarding the constitutional rights of minors does not require the extreme makeover of _Miranda_ that today’s decision may portend.
