> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/miranda-issues/colorado-v.-spring) · Snapshot: 2026-11-02 · Original path: `miranda-issues/colorado-v.-spring`

---

# Colorado v. Spring

Supreme Court of the United States

**Colorado v. John Leroy Spring**

Decided Jan. 27, 1987 – [479 U.S. 564](https://supreme.justia.com/cases/federal/us/479/564/)

Justice POWELL delivered the opinion of the Court.

This case presents the question whether the suspect’s awareness of all the crimes about which he may be questioned is relevant to determining the validity of his decision to waive the Fifth Amendment privilege.

### **I**

In February 1979, respondent John Leroy Spring and a companion shot and killed Donald Walker during a hunting trip in Colorado. Shortly thereafter, an informant told agents of the Bureau of Alcohol, Tobacco, and Firearms (ATF) that Spring was engaged in the interstate transportation of stolen firearms. The informant also told the agents that Spring had discussed his participation in the Colorado killing. At the time the ATF agents received this information, Walker’s body had not been found and the police had received no report of his disappearance. Based on the information received from the informant relating to the firearms violations, the ATF agents set up an undercover operation to purchase firearms from Spring. On March 30, 1979, ATF agents arrested Spring in Kansas City, Missouri, during the undercover purchase.

An ATF agent on the scene of the arrest advised Spring of his _Miranda_ rights. Spring was advised of his _Miranda_ rights a second time after he was transported to the ATF office in Kansas City. At the ATF office, the agents also advised Spring that he had the right to stop the questioning at any time or to stop the questioning until the presence of an attorney could be secured. Spring then signed a written form stating that he understood and waived his rights, and that he was willing to make a statement and answer questions.

ATF agents first questioned Spring about the firearms transactions that led to his arrest. They then asked Spring if he had a criminal record. He admitted that he had a juvenile record for shooting his aunt when he was 10 years old. The agents asked if Spring had ever shot anyone else. Spring ducked his head and mumbled, “I shot another guy once.” The agents asked Spring if he had ever been to Colorado. Spring said no. The agents asked Spring whether he had shot a man named Walker in Colorado and thrown his body into a snowbank. Spring paused and then ducked his head again and said no. The interview ended at this point.

On May 26, 1979, Colorado law enforcement officials visited Spring while he was in jail in Kansas City pursuant to his arrest on the firearms offenses. The officers gave Spring the _Miranda_ warnings, and Spring again signed a written form indicating that he understood his rights and was willing to waive them. The officers informed Spring that they wanted to question him about the Colorado homicide. Spring indicated that he “wanted to get it off his chest.” In an interview that lasted approximately 1 ½ hours, Spring confessed to the Colorado murder. During that time, Spring talked freely to the officers, did not indicate a desire to terminate the questioning, and never requested counsel. The officers prepared a written statement summarizing the interview. Spring read, edited, and signed the statement.

Spring was charged in Colorado state court with first-degree murder. Spring moved to suppress both statements on the ground that his waiver of _Miranda_ rights was invalid. The trial court found that the ATF agents’ failure to inform Spring before the March 30 interview that they would question him about the Colorado murder did not affect his waiver of his _Miranda_ rights.

Accordingly, the trial court concluded that the March 30 statement should not be suppressed on Fifth Amendment grounds. The trial court, however, subsequently ruled that Spring’s statement that he “shot another guy once” was irrelevant, and that the context of the discussion did not support the inference that the statement related to the Walker homicide. For that reason, the March 30 statement was not admitted at Spring’s trial. The court concluded that the May 26 statement “was made freely, voluntarily, and intelligently, after \[Spring’s] being properly and fully advised of his rights, and that the statement should not be suppressed, but should be admitted in evidence.” The May 26 statement was admitted into evidence at trial, and Spring was convicted of first-degree murder.

Spring argued on appeal that his waiver of _Miranda_ rights before the March 30 statement was invalid because he was not informed that he would be questioned about the Colorado murder. Although this statement was not introduced at trial, he claimed that its validity was relevant because the May 26 statement that was admitted against him was the illegal “fruit” of the March 30 statement and therefore should have been suppressed. The Colorado Court of Appeals agreed with Spring, holding that the ATF agents “had a duty to inform Spring that he was a suspect, or to readvise him of his _Miranda_ rights, before questioning him about the murder.”

The Colorado Supreme Court affirmed the judgment of the Court of Appeals. The court concluded:

“Here, the absence of an advisement to Spring that he would be questioned about the Colorado homicide, and the lack of any basis to conclude that at the time of the execution of the waiver, he reasonably could have expected that the interrogation would extend to that subject, _are_ determinative factors in undermining the validity of the waiver.”

We granted certiorari to resolve an arguable Circuit conflict and to review the Colorado Supreme Court’s determination that a suspect’s awareness of the possible subjects of questioning is a relevant and sometimes determinative consideration in assessing whether a waiver of the Fifth Amendment privilege is valid. We now reverse.

### **II**

There is no dispute that the police obtained the May 26 confession after complete _Miranda_ warnings and after informing Spring that he would be questioned about the Colorado homicide. The Colorado Supreme Court nevertheless held that the confession should have been suppressed because it was the illegal “fruit” of the March 30 statement. A confession cannot be “fruit of the poisonous tree” if the tree itself is not poisonous. Our inquiry, therefore, centers on the validity of the March 30 statement.

#### **A**

The Court’s fundamental aim in designing the _Miranda_ warnings was “to assure that the individual’s right to choose between silence and speech remains unfettered throughout the interrogation process.”

Consistent with this purpose, a suspect may waive his Fifth Amendment privilege, “provided the waiver is made voluntarily, knowingly and intelligently.” In this case, the law enforcement officials twice informed Spring of his Fifth Amendment privilege in precisely the manner specified by _Miranda._ As we have noted, Spring indicated that he understood the enumerated rights and signed a written form expressing his intention to waive his Fifth Amendment privilege. The trial court specifically found that “there was no element of duress or coercion used to induce Spring’s statements \[on March 30, 1978].” Despite the explicit warnings and the finding by the trial court, Spring argues that his March 30 statement was in effect compelled in violation of his Fifth Amendment privilege because he signed the waiver form without being aware that he would be questioned about the Colorado homicide. Spring’s argument strains the meaning of compulsion past the breaking point.

#### **B**

A statement is not “compelled” within the meaning of the Fifth Amendment if an individual “voluntarily, knowingly and intelligently” waives his constitutional privilege. The inquiry whether a waiver is coerced “has two distinct dimensions.”

“First the relinquishment of the right must have been voluntary in the sense that it was the product of a free and deliberate choice rather than intimidation, coercion, or deception. Second, the waiver must have been made with a full awareness both of the nature of the right being abandoned and the consequences of the decision to abandon it. Only if the ‘totality of the circumstances surrounding the interrogation’ reveal both an uncoerced choice and the requisite level of comprehension may a court properly conclude that the _Miranda_ rights have been waived.”

There is no doubt that Spring’s decision to waive his Fifth Amendment privilege was voluntary. He alleges no “coercion of a confession by physical violence or other deliberate means calculated to break \[his] will” and the trial court found none. His allegation that the police failed to supply him with certain information does not relate to any of the traditional indicia of coercion: “the duration and conditions of detention …, the manifest attitude of the police toward him, his physical and mental state, the diverse pressures which sap or sustain his powers of resistance and self-control.” Absent evidence that Spring’s “will \[was] overborne and his capacity for self-determination critically impaired” because of coercive police conduct, his waiver of his Fifth Amendment privilege was voluntary under this Court’s decision in _Miranda._

There also is no doubt that Spring’s waiver of his Fifth Amendment privilege was knowingly and intelligently made: that is, that Spring understood that he had the right to remain silent and that anything he said could be used as evidence against him. The Constitution does not require that a criminal suspect know and understand every possible consequence of a waiver of the Fifth Amendment privilege. The Fifth Amendment’s guarantee is both simpler and more fundamental: A defendant may not be compelled to be a witness against himself in any respect. The _Miranda_ warnings protect this privilege by ensuring that a suspect knows that he may choose not to talk to law enforcement officers, to talk only with counsel present, or to discontinue talking at any time. The _Miranda_ warnings ensure that a waiver of these rights is knowing and intelligent by requiring that the suspect be fully advised of this constitutional privilege, including the critical advice that whatever he chooses to say may be used as evidence against him.

In this case there is no allegation that Spring failed to understand the basic privilege guaranteed by the Fifth Amendment. Nor is there any allegation that he misunderstood the consequences of speaking freely to the law enforcement officials. In sum, we think that the trial court was indisputably correct in finding that Spring’s waiver was made knowingly and intelligently within the meaning of _Miranda._

### **III**

#### **A**

Spring relies on this Court’s statement in _Miranda_ that “any evidence that the accused was threatened, tricked, or cajoled into a waiver will … show that the defendant did not voluntarily waive his privilege.” He contends that the failure to inform him of the potential subjects of interrogation constitutes the police trickery and deception condemned in _Miranda,_ thus rendering his waiver of _Miranda_ rights invalid. Spring, however, reads this statement in _Miranda_ out of context and without due regard to the constitutional privilege the _Miranda_ warnings were designed to protect.

We note first that the Colorado courts made no finding of official trickery. In fact, as noted above, the trial court expressly found that “there was no element of duress or coercion used to induce Spring’s statements.” Spring nevertheless insists that the failure of the ATF agents to inform him that he would be questioned about the murder constituted official “trickery” sufficient to invalidate his waiver of his Fifth Amendment privilege, even if the official conduct did not amount to “coercion.” Even assuming that Spring’s proposed distinction has merit, we reject his conclusion. This Court has never held that mere silence by law enforcement officials as to the subject matter of an interrogation is “trickery” sufficient to invalidate a suspect’s waiver of _Miranda_ rights, and we expressly decline so to hold today.

Once _Miranda_ warnings are given, it is difficult to see how official silence could cause a suspect to misunderstand the nature of his constitutional right—“his right to refuse to answer any question which might incriminate him.” “Indeed, it seems self-evident that one who is told he is free to refuse to answer questions is in a curious posture to later complain that his answers were compelled.” We have held that a valid waiver does not require that an individual be informed of all information “useful” in making his decision or all information that “might … affec\[t] his decision to confess.” “\[W]e have never read the Constitution to require that the police supply a suspect with a flow of information to help him calibrate his self-interest in deciding whether to speak or stand by his rights.” Here, the additional information could affect only the wisdom of a _Miranda_ waiver, not its essentially voluntary and knowing nature. Accordingly, the failure of the law enforcement officials to inform Spring of the subject matter of the interrogation could not affect Spring’s decision to waive his Fifth Amendment privilege in a constitutionally significant manner.

#### **B**

This Court’s holding in _Miranda_ specifically required that the police inform a criminal suspect that he has the right to remain silent and that _anything_ he says may be used against him. There is no qualification of this broad and explicit warning. The warning, as formulated in _Miranda,_ conveys to a suspect the nature of his constitutional privilege and the consequences of abandoning it. Accordingly, we hold that a suspect’s awareness of all the possible subjects of questioning in advance of interrogation is not relevant to determining whether the suspect voluntarily, knowingly, and intelligently waived his Fifth Amendment privilege.

### **IV**

The judgment of the Colorado Supreme Court is reversed, and the case is remanded for further proceedings not inconsistent with this opinion.

### Justice MARSHALL, with whom Justice BRENNAN joins, dissenting.

\[T]he Court\[] hold\[s] today: “\[A] suspect’s awareness of _all_ the possible subjects of questioning in advance of interrogation is not relevant to determining” the validity of his waiver. This careful phraseology avoids the important question whether the lack of _any_ indication of the identified subjects for questioning _is_ relevant to determining the validity of the suspect’s waiver.

I would include among the relevant factors for consideration whether before waiving his Fifth Amendment rights the suspect was aware, either through the circumstances surrounding his arrest or through a specific advisement from the arresting or interrogating officers, of the crime or crimes he was suspected of committing and about which they intended to ask questions. To hold that such knowledge is relevant would not undermine the “‘virtue of informing police and prosecutors with specificity’ as to how a pretrial questioning of a suspect must be conducted,” nor would it interfere with the use of legitimate interrogation techniques. Indeed, requiring the officers to articulate at a minimum the crime or crimes for which the suspect has been arrested could contribute significantly toward ensuring that the arrest was in fact lawful and the suspect’s statement not compelled because of an error at this stage alone.

The interrogation tactics utilized in this case demonstrate the relevance of the information Spring did not receive. The agents evidently hoped to obtain from Spring a valid confession to the federal firearms charge for which he was arrested and then parlay this admission into an additional confession of first-degree murder. Spring could not have expected questions about the latter, separate offense when he agreed to waive his rights, as it occurred in a different State and was a violation of state law outside the normal investigative focus of federal Alcohol, Tobacco, and Firearms agents.

The coercive aspects of the psychological ploy intended in this case, when combined with an element of surprise which may far too easily rise to a level of deception, cannot be justified in light of _Miranda’_&#x73; strict requirements that the suspect’s waiver and confession be voluntary, knowing, and intelligent. If a suspect has signed a waiver form with the intention of making a statement regarding a specifically alleged crime, the Court today would hold this waiver valid with respect to questioning about any other crime, regardless of its relation to the charges the suspect believes he will be asked to address. Yet once this waiver is given and the intended statement made, the protections afforded by _Miranda_ against the “inherently compelling pressures” of the custodial interrogation have effectively dissipated. Additional questioning about entirely separate and more serious suspicions of criminal activity can take unfair advantage of the suspect’s psychological state, as the unexpected questions cause the compulsive pressures suddenly to reappear. Given this technique of interrogation, a suspect’s understanding of the topics planned for questioning is, therefore, at the very least “relevant” to assessing whether his decision to talk to the officers was voluntarily, knowingly, and intelligently made.

I dissent.
