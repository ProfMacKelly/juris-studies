> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/5.-search-incident-to-lawful-arrest-sila/cases) · Snapshot: 2026-11-02 · Original path: `5.-search-incident-to-lawful-arrest-sila/cases`

---

# Cases

