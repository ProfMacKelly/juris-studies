> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/readme-1) · Snapshot: 2026-11-02 · Original path: `readme-1`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-procedure/setting-the-stage)

---

# Setting the Stage

### Contents

{% content-ref url="readme-1/key-constitutional-text" %}
[key-constitutional-text](readme-1/key-constitutional-text)
{% endcontent-ref %}

{% content-ref url="readme-1/introduction-to-the-fourth-amendment" %}
[introduction-to-the-fourth-amendment](readme-1/introduction-to-the-fourth-amendment)
{% endcontent-ref %}

{% content-ref url="readme-1/foundations-and-terminology" %}
[foundations-and-terminology](readme-1/foundations-and-terminology)
{% endcontent-ref %}
