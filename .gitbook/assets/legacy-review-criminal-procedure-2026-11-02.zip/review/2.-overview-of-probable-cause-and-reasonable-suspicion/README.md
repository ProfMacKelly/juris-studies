> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Criminal Procedure: A Sourcebook](https://profmackelly.gitbook.io/criminal-procedure/2.-overview-of-probable-cause-and-reasonable-suspicion) · Snapshot: 2026-11-02 · Original path: `2.-overview-of-probable-cause-and-reasonable-suspicion`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-procedure/overview-of-probable-cause-and-reasonable-suspicion)

---

# Overview of Probable Cause and Reasonable Suspicion

## Contents

{% content-ref url="2.-overview-of-probable-cause-and-reasonable-suspicion/introduction" %}
[introduction](2.-overview-of-probable-cause-and-reasonable-suspicion/introduction)
{% endcontent-ref %}

{% content-ref url="2.-overview-of-probable-cause-and-reasonable-suspicion/the-principles-of-probable-cause-and-reasonable-suspicion" %}
[the-principles-of-probable-cause-and-reasonable-suspicion](2.-overview-of-probable-cause-and-reasonable-suspicion/the-principles-of-probable-cause-and-reasonable-suspicion)
{% endcontent-ref %}

{% content-ref url="2.-overview-of-probable-cause-and-reasonable-suspicion/cases-notes-and-questions" %}
[cases-notes-and-questions](2.-overview-of-probable-cause-and-reasonable-suspicion/cases-notes-and-questions)
{% endcontent-ref %}
