# Consensual Encounters vs. Detentions

## Contents

{% content-ref url="3.-consensual-encounters-vs.-detentions/consensual-encounters" %}
[consensual-encounters](3.-consensual-encounters-vs.-detentions/consensual-encounters)
{% endcontent-ref %}

{% content-ref url="3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops" %}
[investigative-detentions-terry-stops](3.-consensual-encounters-vs.-detentions/investigative-detentions-terry-stops)
{% endcontent-ref %}
