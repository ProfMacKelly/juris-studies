# Consensual Encounters

## Contents

{% content-ref url="consensual-encounters/overview" %}
[overview](consensual-encounters/overview)
{% endcontent-ref %}

{% content-ref url="consensual-encounters/the-free-to-terminate-test" %}
[the-free-to-terminate-test](consensual-encounters/the-free-to-terminate-test)
{% endcontent-ref %}

{% content-ref url="consensual-encounters/engaging-the-suspect" %}
[engaging-the-suspect](consensual-encounters/engaging-the-suspect)
{% endcontent-ref %}

{% content-ref url="consensual-encounters/officer-safety-measures" %}
[officer-safety-measures](consensual-encounters/officer-safety-measures)
{% endcontent-ref %}

{% content-ref url="consensual-encounters/conducting-the-investigation" %}
[conducting-the-investigation](consensual-encounters/conducting-the-investigation)
{% endcontent-ref %}

{% content-ref url="consensual-encounters/cases-notes-and-questions" %}
[cases-notes-and-questions](consensual-encounters/cases-notes-and-questions)
{% endcontent-ref %}
