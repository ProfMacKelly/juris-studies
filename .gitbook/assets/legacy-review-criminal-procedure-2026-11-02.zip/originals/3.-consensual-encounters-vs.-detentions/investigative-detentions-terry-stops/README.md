# Investigative Detentions (Terry Stops)

## Contents

{% content-ref url="investigative-detentions-terry-stops/introduction" %}
[introduction](investigative-detentions-terry-stops/introduction)
{% endcontent-ref %}

{% content-ref url="investigative-detentions-terry-stops/prior-to-the-stop-requirements-and-justifications-for-investigative-detentions" %}
[prior-to-the-stop-requirements-and-justifications-for-investigative-detentions](investigative-detentions-terry-stops/prior-to-the-stop-requirements-and-justifications-for-investigative-detentions)
{% endcontent-ref %}

{% content-ref url="investigative-detentions-terry-stops/after-the-stop" %}
[after-the-stop](investigative-detentions-terry-stops/after-the-stop)
{% endcontent-ref %}

{% content-ref url="investigative-detentions-terry-stops/cases-notes-and-questions" %}
[cases-notes-and-questions](investigative-detentions-terry-stops/cases-notes-and-questions)
{% endcontent-ref %}

