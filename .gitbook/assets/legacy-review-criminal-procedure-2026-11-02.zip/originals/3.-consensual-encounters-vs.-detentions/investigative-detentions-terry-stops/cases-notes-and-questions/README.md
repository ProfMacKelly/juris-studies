# Cases, Notes & Questions

1. [_U.S. v. Mendenhall_](../consensual-encounters/cases-notes-and-questions/u.s.-v.-mendenhall)
2. [_California v. Hodari D._](../consensual-encounters/cases-notes-and-questions/california-v.-hodari-d.)
3. [_U.S. v. Lillich_](../consensual-encounters/cases-notes-and-questions/u.s.-v.-lillich)
