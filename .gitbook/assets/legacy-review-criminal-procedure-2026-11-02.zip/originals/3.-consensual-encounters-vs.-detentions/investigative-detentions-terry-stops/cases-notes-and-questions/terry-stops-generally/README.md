# Terry Stops, Generally

