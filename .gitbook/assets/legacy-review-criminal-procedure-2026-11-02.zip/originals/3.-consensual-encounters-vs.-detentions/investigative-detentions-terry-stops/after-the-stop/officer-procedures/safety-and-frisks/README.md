# Safety & Frisks

## Contents

{% content-ref url="safety-and-frisks/safety-precautions" %}
[safety-precautions](safety-and-frisks/safety-precautions)
{% endcontent-ref %}

{% content-ref url="safety-and-frisks/terry-frisks" %}
[terry-frisks](safety-and-frisks/terry-frisks)
{% endcontent-ref %}

