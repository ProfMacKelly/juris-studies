# After the Stop

## Contents

{% content-ref url="after-the-stop/duration" %}
[duration](after-the-stop/duration)
{% endcontent-ref %}

{% content-ref url="after-the-stop/de-facto-arrests" %}
[de-facto-arrests](after-the-stop/de-facto-arrests)
{% endcontent-ref %}

{% content-ref url="after-the-stop/officer-procedures" %}
[officer-procedures](after-the-stop/officer-procedures)
{% endcontent-ref %}

{% content-ref url="after-the-stop/converting-detentions-into-consensual-encounters" %}
[converting-detentions-into-consensual-encounters](after-the-stop/converting-detentions-into-consensual-encounters)
{% endcontent-ref %}

