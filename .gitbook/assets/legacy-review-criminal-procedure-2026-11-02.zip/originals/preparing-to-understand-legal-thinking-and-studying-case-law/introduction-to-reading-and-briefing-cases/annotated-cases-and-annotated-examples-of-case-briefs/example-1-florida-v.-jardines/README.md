# Example 1: Florida v. Jardines

### Contents

{% content-ref url="example-1-florida-v.-jardines/annotated-case-florida-v.-jardines" %}
[annotated-case-florida-v.-jardines](example-1-florida-v.-jardines/annotated-case-florida-v.-jardines)
{% endcontent-ref %}

{% content-ref url="example-1-florida-v.-jardines/annotated-case-brief-florida-v.-jardines" %}
[annotated-case-brief-florida-v.-jardines](example-1-florida-v.-jardines/annotated-case-brief-florida-v.-jardines)
{% endcontent-ref %}
