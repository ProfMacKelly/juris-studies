# Example 2: Mills v. City of Overland Park

### Contents

{% content-ref url="example-2-mills-v.-city-of-overland-park/annotated-case-mills-v.-city-of-overland-park" %}
[annotated-case-mills-v.-city-of-overland-park](example-2-mills-v.-city-of-overland-park/annotated-case-mills-v.-city-of-overland-park)
{% endcontent-ref %}

{% content-ref url="example-2-mills-v.-city-of-overland-park/annotated-case-brief-mills-v.-city-of-overland-park" %}
[annotated-case-brief-mills-v.-city-of-overland-park](example-2-mills-v.-city-of-overland-park/annotated-case-brief-mills-v.-city-of-overland-park)
{% endcontent-ref %}
