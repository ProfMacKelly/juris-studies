# Example 3: Malley v. Briggs

### Contents

{% content-ref url="example-3-malley-v.-briggs/annotated-case-malley-v.-briggs" %}
[annotated-case-malley-v.-briggs](example-3-malley-v.-briggs/annotated-case-malley-v.-briggs)
{% endcontent-ref %}

{% content-ref url="example-3-malley-v.-briggs/annotated-case-brief-malley-v.-briggs" %}
[annotated-case-brief-malley-v.-briggs](example-3-malley-v.-briggs/annotated-case-brief-malley-v.-briggs)
{% endcontent-ref %}
