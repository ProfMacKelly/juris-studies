# Introduction

The Fourth Amendment provides that “no warrants shall issue, but upon probable cause.” Accordingly, warrants (and the searches that followed in the wake of their issuance) have been challenged on the ground that police did not provide sufficient evidence when obtaining the warrants from judges. In addition, the Court has held that in several common situations, police may conduct searches and seizures without a warrant, but only with probable cause. For example, the vehicle searches described in [_Florida v. Harris_](https://scholar.google.com/scholar_case?case=15114207959509730903\&q=568+U.S.+237\&hl=en\&as_sdt=6,50) were permissible under the “automobile exception” to the warrant requirement, about which we will learn more later. In [_Illinois v. Gates_](cases-notes-and-questions/ilinois-v.-gates), the Court set forth a new standard for when an informant’s tip provides probable cause to justify a search or arrest.

<details>

<summary>Attributions &#x26; Licensing</summary>

Except where otherwise noted, this page's content is adapted from [1.1:  Chapter 1 - What Is This Book? ](https://biz.libretexts.org/Bookshelves/Criminal_Law/Criminal_Procedure%3A_A_Free_Law_School_Casebook_2e_\(Alexander_and_Trachtenberg\)/01%3A_Introduction/1.01%3A_Chapter_1_-_What_Is_This_Book)by [Anne M Alexander](https://law.missouri.edu/directory/anne-alexander/) and [Ben Trachtenberg](https://law.missouri.edu/directory/ben-trachtenberg/), in [_Criminal Procedure: A Free Law School Casebook 2e_](https://biz.libretexts.org/Bookshelves/Criminal_Law/Criminal_Procedure%3A_A_Free_Law_School_Casebook_2e_\(Alexander_and_Trachtenberg\)), used under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). This page is licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). <img src="https://2693790834-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2F6Bqz3QmhzbBYM9Y3OuYd%2Fuploads%2F4RM3xj97RhTRxZtEB0FT%2Fimage.png?alt=media&#x26;token=3c008788-aeef-4a47-b902-fec1392964d1" alt="" data-size="line">

</details>
