# Cases & Notes

## Contents

{% content-ref url="cases-notes-and-questions/ilinois-v.-gates" %}
[ilinois-v.-gates](cases-notes-and-questions/ilinois-v.-gates)
{% endcontent-ref %}

{% content-ref url="cases-notes-and-questions/whren-v.-united-states" %}
[whren-v.-united-states](cases-notes-and-questions/whren-v.-united-states)
{% endcontent-ref %}

{% content-ref url="cases-notes-and-questions/district-of-columbia-v.-wesby" %}
[district-of-columbia-v.-wesby](cases-notes-and-questions/district-of-columbia-v.-wesby)
{% endcontent-ref %}

{% content-ref url="cases-notes-and-questions/notes-on-racial-profiling" %}
[notes-on-racial-profiling](cases-notes-and-questions/notes-on-racial-profiling)
{% endcontent-ref %}
