# Setting the Stage

### Contents

{% content-ref url="readme-1/key-constitutional-text" %}
[key-constitutional-text](readme-1/key-constitutional-text)
{% endcontent-ref %}

{% content-ref url="readme-1/introduction-to-the-fourth-amendment" %}
[introduction-to-the-fourth-amendment](readme-1/introduction-to-the-fourth-amendment)
{% endcontent-ref %}

{% content-ref url="readme-1/foundations-and-terminology" %}
[foundations-and-terminology](readme-1/foundations-and-terminology)
{% endcontent-ref %}
