# Steagald v. United States

\[Edited from the [original](https://www.courtlistener.com/opinion/110464/steagald-v-united-states/).]

***

451 U.S. 204 (1981)

Supreme Court of the United States

**Gary Keith Steagald**\
**v.**\
**United States**

## \[Majority]

Justice MARSHALL delivered the opinion of the Court.

The issue in this case is whether, under the Fourth Amendment, a law enforcement officer may legally search for the subject of an arrest warrant in the home of a third party without first obtaining a search warrant. Concluding that a search warrant must be obtained absent exigent circumstances or consent, we reverse the judgment of the United States Court of Appeals for the Fifth Circuit affirming petitioner's conviction.

## I

In early January 1978, an agent of the Drug Enforcement Administration (DEA) was contacted in Detroit, Mich., by a confidential informant who suggested that he might be able to locate Ricky Lyons, a federal fugitive wanted on drug charges. On January 14, 1978, the informant called the agent again, and gave him a telephone number in the Atlanta, Ga., area where, according to the informant, Ricky Lyons could be reached during the next 24 hours. On January 16, 1978, the agent called fellow DEA Agent Kelly Goodowens in Atlanta and relayed the information he had obtained from the informant. Goodowens contacted Southern Bell Telephone Co., and secured the address corresponding to the telephone number obtained by the informant. Goodowens also discovered that Lyons was the subject of a 6-month-old arrest warrant.

Two days later, Goodowens and 11 other officers drove to the address supplied by the telephone company to search for Lyons. The officers observed two men standing outside the house to be searched. These men were Hoyt Gaultney and petitioner Gary Steagald. The officers approached with guns drawn, frisked both men, and, after demanding identification, determined that neither man was Lyons. Several agents proceeded to the house. Gaultney’s wife answered the door, and informed the agents that she was alone in the house. She was told to place her hands against the wall and was guarded in that position while one agent searched the house. Ricky Lyons was not found, but during the search of the house the agent observed what he believed to be cocaine. Upon being informed of this discovery, Agent Goodowens sent an officer to obtain a search warrant and in the meantime conducted a second search of the house, which uncovered additional incriminating evidence. During a third search conducted pursuant to a search warrant, the agents uncovered 43 pounds of cocaine. Petitioner was arrested and indicted on federal drug charges.

Prior to trial, petitioner moved to suppress all evidence uncovered during the various searches on the ground that it was illegally obtained because the agents had failed to secure a search warrant before entering the house. Agent Goodowens testified at the suppression hearing that there had been no “physical hinderance” preventing him from obtaining a search warrant and that he did not do so because he believed that the arrest warrant for Ricky Lyons was sufficient to justify the entry and search. The District Court agreed with this view, and denied the suppression motion. Petitioner was convicted, and renewed his challenge to the search in his appeal. A divided Court of Appeals for the Fifth Circuit affirmed the District Court’s denial of petitioner’s suppression motion. \[...] Because the issue presented by this case is an important one \[...] that has divided the Circuits, \[...] we granted certiorari.

&#x20;\[...]

## &#x20;III

The question before us is a narrow one. \[...] The search at issue here took place in the absence of consent or exigent circumstances. Except in such special situations, we have consistently held that the entry into a home to conduct a search or make an arrest is unreasonable under the Fourth Amendment unless done pursuant to a warrant. See [_Payton v. New York_](#user-content-fn-1)[^1]. Thus, as we recently observed: “In terms that apply equally to seizures of property and to seizures of persons, the Fourth Amendment has drawn a firm line at the entrance to the house. Absent exigent circumstances, that threshold may not reasonably be crossed without a warrant.” [_Payton v. New York_](#user-content-fn-2)[^2]. Here, of course, the agents had a warrant—one authorizing the arrest of Ricky Lyons. However, the Fourth Amendment claim here is not being raised by Ricky Lyons. Instead, the challenge to the search is asserted by a person not named in the warrant who was convicted on the basis of evidence uncovered during a search of his residence for Ricky Lyons. Thus, the narrow issue before us is whether an arrest warrant—as opposed to a search warrant—is adequate to protect the Fourth Amendment interests of persons not named in the warrant, when their homes are searched without their consent and in the absence of exigent circumstances.

The purpose of a warrant is to allow a neutral judicial officer to assess whether the police have probable cause to make an arrest or conduct a search. As we have often explained, the placement of this checkpoint between the Government and the citizen implicitly acknowledges that an “officer engaged in the often competitive enterprise of ferreting out crime,” Johnson v. United States, supra, 333 U.S. at 14, may lack sufficient objectivity to weigh correctly the strength of the evidence supporting the contemplated action against the individual’s interests in protecting his own liberty and the privacy of his home. [_Coolidge v. New Hampshire_](#user-content-fn-3)[^3]. However, while an arrest warrant and a search warrant both serve to subject the probable-cause determination of the police to judicial review, the interests protected by the two warrants differ. An arrest warrant is issued by a magistrate upon a showing that probable cause exists to believe that the subject of the warrant has committed an offense and thus the warrant primarily serves to protect an individual from an unreasonable seizure. A search warrant, in contrast is issued upon a showing of probable cause to believe that the legitimate object of a search is located in a particular place, and therefore safeguards an individual’s interest in the privacy of his home and possessions against the unjustified intrusion of the police.

Thus, whether the arrest warrant issued in this case adequately safeguarded the interests protected by the Fourth Amendment depends upon what the warrant authorized the agents to do. To be sure, the warrant embodied a judicial finding that there was probable cause to believe the Ricky Lyons had committed a felony, and the warrant therefore authorized the officers to seize Lyons. However, the agents sought to do more than use the warrant to arrest Lyons in a public place or in his home; instead, they relied on the warrant as legal authority to enter the home of a third person based on their belief that Ricky Lyons might be a guest there. Regardless of how reasonable this belief might have been, it was never subjected to the detached scrutiny of a judicial officer. Thus, while the warrant in this case may have protected Lyons from an unreasonable seizure, it did absolutely nothing to protect petitioner’s privacy interest in being free from an unreasonable invasion and search of his home. Instead, petitioner’s only protection from an illegal entry and search was the agent’s personal determination of probable cause. In the absence of exigent circumstances, we have consistently held that such judicially untested determinations are not reliable enough to justify an entry into a person’s home to arrest him without a warrant, or a search of a home for objects in the absence of a search warrant. Payton v. New York, supra. We see no reason to depart from this settled course when the search of a home is for a person rather than an object.

A contrary conclusion—that the police, acting alone and in the absence of exigent circumstances, may decide when there is sufficient justification for searching the home of a third party for the subject of an arrest warrant—would create a significant potential for abuse. Armed solely with an arrest warrant for a single person, the police could search all the homes of that individual’s friends and acquaintances. \[...] The Government recognizes the potential for such abuses, but contends that existing remedies—such as motions to suppress illegally procured evidence and damages actions for Fourth Amendment violations—provide adequate means of redress. We do not agree. As we observed on a previous occasion, “\[t]he \[Fourth] Amendment is designed to prevent, not simply to redress, unlawful police action.”  [_Chimel v. California_](#user-content-fn-4)[^4]. Indeed, if suppression motions and damages actions were sufficient to implement the Fourth Amendment’s prohibition against unreasonable searches and seizures, there would be no need for the constitutional requirement that in the absence of exigent circumstances a warrant must be obtained for a home arrest or a search of a home for objects. We have instead concluded that in such cases the participation of a detached magistrate in the probable-cause determination is an essential element of a reasonable search or seizure, and we believe that the same conclusion should apply here.

In sum, two distinct interests were implicated by the search at issue here—Ricky Lyons’ interest in being free from an unreasonable seizure and petitioner’s interest in being free from an unreasonable search of his home. Because the arrest warrant for Lyons addressed only the former interest, the search of petitioner’s home was no more reasonable from petitioner’s perspective than it would have been if conducted in the absence of any warrant. Since warrantless searches of a home are impermissible absent consent or exigent circumstances, we conclude that the instant search violated the Fourth Amendment.

&#x20;\[...]&#x20;

## \[IV] B

The Government \[...] suggests that practical problems might arise if law enforcement officers are required to obtain a search warrant before entering the home of a third party to make an arrest. The basis of this concern is that persons, as opposed to objects, are inherently mobile, and thus officers seeking to effect an arrest may be forced to return to the magistrate several times as the subject of the arrest warrant moves from place to place. We are convinced, however, that a search warrant requirement will not significantly impede effective law enforcement efforts.

First, the situations in which a search warrant will be necessary are few. As noted in [_Payton_ v. _New York_](#user-content-fn-5)[^5], an arrest warrant alone will suffice to enter a suspect's own residence to effect his arrest. Furthermore, if probable cause exists, no warrant is required to apprehend a suspected felon in a public place. [_United States_ v. _Watson_](#user-content-fn-6)[^6]. Thus, the subject of an arrest warrant can be readily seized before entering or after leaving the home of a third party. Finally, the exigent-circumstances doctrine significantly limits the situations in which a search warrant would be needed. For example, a warrantless entry of a home would be justified if the police were in "hot pursuit" of a fugitive.\*[^7] Thus, to the extent that searches for persons pose special problems, we believe that the exigent-circumstances doctrine is adequate to accommodate legitimate law enforcement needs.

Moreover, in those situations in which a search warrant is necessary, the inconvenience incurred by the police is simply not that significant. First, if the police know of the location of the felon when they obtain an arrest warrant, the additional burden of obtaining a search warrant at the same time is miniscule. The inconvenience of obtaining such a warrant does not increase significantly when an outstanding arrest warrant already exists. In this case, for example, Agent Goodowens knew the address of the house to be searched two days in advance, and planned the raid from the federal courthouse in Atlanta where, we are informed, three fulltime magistrates were on duty. In routine search cases such as this, the short time required to obtain a search warrant from a magistrate will seldom hinder efforts to apprehend a felon. Finally, if a magistrate is not nearby, a telephonic search warrant can usually be obtained.\*[^8]

Whatever practical problems remain, however, cannot outweigh the constitutional interests at stake. Any warrant requirement impedes to some extent the vigor with which the Government can seek to enforce its laws, yet the Fourth Amendment recognizes that this restraint is necessary in some cases to protect against unreasonable searches and seizures. We conclude that this is such a case. The additional burden imposed on the police by a warrant requirement is minimal. In contrast, the right protectedthat of presumptively innocent people to be secure in their homes from unjustified, forcible intrusions by the Governmentis weighty. Thus, in order to render the instant search reasonable under the Fourth Amendment, a search warrant was required.

Accordingly, the judgment of the Court of Appeals is reversed, and the case is remanded to that court for further proceedings consistent with this opinion.

&#x20;_So ordered_.

\[...]

## \[Dissent]

JUSTICE REHNQUIST, with whom JUSTICE WHITE joins, dissenting.

The Court's opinion reversing petitioner's conviction proceeds in a pristinely simple manner: Steagald had a Fourth Amendment privacy interest in the dwelling entered by the police, and even though the police entered the premises for the sole purpose of executing a valid arrest warrant for Lyons, a fugitive from justice, whom they had probable cause to believe was within, the arrest warrant was not sufficient absent exigent circumstances to justify invading Steagald's privacy interest in the dwelling. Petitioner Steagald's privacy interest is different from Lyons' interest in being free from an unreasonable seizure, according to the Court, and the arrest warrant only validated the invasion of the latter. In the words of the Court:

> "\[T]he search of petitioner's home was no more reasonable from petitioner's perspective than it would have been if conducted in the absence of any warrant. Since warrantless searches of a home are impermissible absent consent or exigent circumstances, we conclude that the instant search violated the Fourth Amendment." \[...]

This "reasoning" not only assumes the answer to the question presented—whether the search of petitioner's dwelling could be undertaken without a search warrant—but also conveniently ignores the critical fact in this case, the existence of an arrest warrant for a fugitive believed on the basis of probable cause to be in the dwelling. The Court assumes that because the arrest warrant did not specifically address petitioner's privacy interest it is of no further relevance to the case. Incidental infringements of distinct Fourth Amendment interests may, however, be reasonable when they occur in the course of executing a valid warrant addressed to other interests. In [_Dalia_ v. _United States_](#user-content-fn-9)[^9]_,_ the Court rejected the argument that a separate search warrant was required before police could enter a business office to install an eavesdropping device when a warrant authorizing the eavesdropping itself had already been obtained. As the Court put it: "This view of the Warrant Clause parses too finely the interests protected by the Fourth Amendment. _Often in executing a warrant the police may find it necessary to interfere with privacy rights not explicitly considered by the judge who issued the warrant._"\*[^10] In [_Payton_ v. _New York_](#user-content-fn-11)[^11], the Court rejected the suggestion that a separate search warrant was required before police could execute an arrest warrant by entering the home of the subject of the warrant. Although the subject of the warrant had a Fourth Amendment interest in the privacy of his dwelling quite distinct from the interest in being free from unreasonable seizures addressed by the arrest warrant, the Court concluded that it was "constitutionally reasonable to require him to open his doors to the officers of the law."\*[^12]

This case, therefore, cannot be resolved by the simple Aristotelian syllogism which the Court employs. Concluding as it does that the arrest warrant did not address the privacy interest affected by the search by no means ends the matter; it simply presents the issue for decision. Resolution of that issue depends upon a balancing of the "need to search against the invasion which the search entails." [_Camara_ v. _Municipal Court of San Francisco_](#user-content-fn-13)[^13]. Here, as in all Fourth Amendment cases, "reasonableness is still the ultimate standard."[\* ](#user-content-fn-14)[^14]In determining the reasonableness of dispensing with the requirement of a separate search warrant in this case, I believe that the existence of a valid arrest warrant is highly relevant.

The government's interests in the warrantless entry of a third-party dwelling to execute an arrest warrant are compelling. The basic problem confronting police in such situations is the inherent mobility of the fugitive. By definition, the police have probable cause to believe that the fugitive is in a dwelling which is not his home. He may stay there for a week, a day, or 10 minutes. Fugitives from justice tend to be mobile, and police officers will generally have no way of knowing whether the subject of an arrest warrant will be at the dwelling when they return from seeking a search warrant.\*[^15] Imposition of a search warrant requirement in such circumstances will frustrate the compelling interests of the government and indeed the public in the apprehension of those subject to outstanding arrest warrants.

The Court's responses to these very real concerns are singularly unpersuasive. It first downplays them by stating that "the situations in which a search warrant will be necessary are few,"\*[^16] because no search warrant is necessary to arrest a suspect at his home and, if the suspect is at another's home, the police need only wait until he leaves, since no search warrant is needed to arrest him in a public place.\*[^16] These beguilingly simple answers to a serious law enforcement problem simply will not wash. Criminals who know or suspect they are subject to arrest warrants would not be likely to return to their homes, and while "\[t]he police could reduce the likelihood of escape by staking out all possible exits ... the costs of such a stakeout seem excessive in an era of rising crime and scarce police resources." [_Payton_ v. _New York_](#user-content-fn-17)[^17]. The Court's ivory tower misconception of the realities of the apprehension of fugitives from justice reaches its apogee when it states: "In routine search cases such as this, the short time required to obtain a search warrant from a magistrate will seldom hinder efforts to apprehend a felon."\*[^18] The cases we are considering are _not_ "routine search cases." They are cases of attempted arrest, pursuant to a warrant, when the object of the arrest may flee at any timeincluding the "short time" during which the police are endeavoring to obtain a search warrant.

At the same time the interference with the Fourth Amendment privacy interests of those whose homes are entered to apprehend the felon is not nearly as significant as suggested by the Court. The arrest warrant serves some of the functions a separate search warrant would. It assures the occupants that the police officer is present on official business. The arrest warrant also limits the scope of the search, specifying what the police may search for&#x97;_&#x69;. e.,_ the subject of the arrest warrant. No general search is permitted, but only a search of those areas in which the object of the search might hide.\*[^19] Indeed there may be no intrusion on the occupant's privacy at all, since if present the suspect will have the opportunity to voluntarily surrender at the door. Even if the suspect does not surrender but secrets himself within the house, the occupant can limit the search by pointing him out to the police. It is important to remember that the contraband discovered during the entry and search for Lyons was in plain view, and was discovered during a "sweep search" for Lyons, not a probing of drawers or cabinets for contraband. [_United States_ v. _Gaultney_](#user-content-fn-20)[^20].

Because the burden on law enforcement officers to obtain a separate search warrant before entering the dwelling of a third party to execute a concededly valid arrest warrant is great, and carries with it a high possibility that the fugitive named in the arrest warrant will escape apprehension, I would conclude that the application of the traditional "reasonableness" standard of the Fourth Amendment does not require a separate search warrant in a case such as this.

\[...]

While I cannot subscribe to the Court's decision today. I will not falsely cry "wolf" in this dissent. The decision rests on a very special set of facts, and with a change in one or more of them it is clear that no separate search warrant would be required even under the reasoning of the Court.

On the one side [_Payton_ ](https://www.courtlistener.com/opinion/110235/payton-v-new-york/)makes clear that an arrest warrant is all that is needed to enter the suspect's "home" to effect the arrest.\*[^21] If a suspect has been living in a particular dwelling for any significant period, say a few days, it can certainly be considered his "home" for Fourth Amendment purposes, even if the premises are owned by a third party and others are living there, and even if the suspect concurrently maintains a residence elsewhere as well. In such a case the police could enter the premises with only an arrest warrant. On the other side, the more fleeting a suspect's connection with the premises, such as when he is a mere visitor, the more likely that exigent circumstances will exist justifying immediate police action without departing to obtain a search warrant. The practical damage done to effective law enforcement by today's decision, without any basis in the Constitution, may well be minimal if courts carefully consider the various congeries of facts in the actual case before them.

The genuinely unfortunate aspect of today's ruling is not that fewer fugitives will be brought to book, or fewer criminals apprehended, though both of these consequences will undoubtedly occur; the greater misfortune is the increased uncertainty imposed on police officers in the field, committing magistrates, and trial judges, who must confront variations and permutations of this factual situation on a day-to-day basis. They will, in their various capacities, have to weigh the time during which a suspect for whom there is an outstanding arrest warrant has been in the building, whether the dwelling is the suspect's home, how long he has lived there, whether he is likely to leave immediately, and a number of related and equally imponderable questions. Certainty and repose, as Justice Holmes said, may not be the destiny of man, but one might have hoped for a higher degree of certainty in this one narrow but important area of the law than is offered by today's decision.



**\[Footnotes omitted.]**



[^1]: [445 U.S. 573](https://www.courtlistener.com/opinion/110235/payton-v-new-york/?q=cites%3A77608) (1980)

[^2]: 445 U.S., at 590

[^3]: [403 U.S. 443](https://www.courtlistener.com/opinion/108377/coolidge-v-new-hampshire/), 449-451

[^4]: [395 U.S. 752](https://www.courtlistener.com/opinion/107979/chimel-v-california/), 766 n. 12

[^5]: [_supra_](https://www.courtlistener.com/opinion/110235/payton-v-new-york/)_,_ at 602-603

[^6]: [423 U.S. 411](https://www.courtlistener.com/opinion/109352/united-states-v-watson/) (1976)

[^7]: See _United States_ v. _Santana,_ [427 U.S. 38](https://www.courtlistener.com/opinion/109504/united-states-v-santana/), 42-43 (1976); _Warden_ v. _Hayden,_ [387 U.S. 294 ](https://www.courtlistener.com/opinion/107465/warden-md-penitentiary-v-hayden/)\*222 (1967)

[^8]: &#x20;See [Fed. Rule Crim. Proc. 41](https://www.law.cornell.edu/rules/frcrmp/rule_41)(c)(1), (2).

[^9]: [441 U.S. 238 ](https://www.courtlistener.com/opinion/110061/dalia-v-united-states/)(1979)

[^10]: _Id.,_ at 257 (emphasis supplied)

[^11]: &#x20;[445 U.S. 573 ](https://www.courtlistener.com/opinion/110235/payton-v-new-york/)(1980)

[^12]: _Id.,_ at 602-603

[^13]: [387 U.S. 523](https://www.courtlistener.com/opinion/107473/camara-v-municipal-court-of-city-and-county-of-san-francisco/), 537 (1967)

[^14]: _Id.,_ at 539. See _Wyman_ v. _James,_ [400 U.S. 309](https://www.courtlistener.com/opinion/108223/wyman-v-james/), 318 (1971); _Marshall_ v. _Barlow's, Inc.,_ [436 U.S. 307](https://www.courtlistener.com/opinion/109866/marshall-v-barlows-inc/), 315-316 (1978)

[^15]: See _United States_ v. _McKinney,_ [379 F.2d 259](https://www.courtlistener.com/opinion/276331/united-states-v-roy-mckinney/), 263 (CA6 1967); _State_ v. _Jordan,_ 288 Ore. 391, 400-401, [605 P.2d 646](https://www.courtlistener.com/opinion/1356897/state-v-jordan/), 651 (1980) (en banc)

[^16]: _ante,_ at 221

[^17]: [_supra_](https://www.courtlistener.com/opinion/110235/payton-v-new-york/)_,_ at 619 (WHITE, J., dissenting)

[^18]: _Ante,_ at 222

[^19]: See _Fisher_ v. _Volz,_ [496 F.2d 333](https://www.courtlistener.com/opinion/319014/marian-fisher-v-christian-j-volz-individually-and-in-his-capacity-as/), 343 (CA3 1974); _State_ v. _Jordan, supra,_ at 400-401, [605 P.2d, at 651](https://www.courtlistener.com/opinion/1356897/state-v-jordan/); _United States_ v. _Cravero,_ 545 F.2d 406, 421, nn. 1. 2 (CA5 1976), cert. denied, 429 U.S. 1100 and 430 U.S. 983 (1977)

[^20]: [606 F.2d 540](https://www.courtlistener.com/opinion/370304/united-states-v-hoyt-albert-gaultney-united-states-of-america-v-gary/), 544 (1979)

[^21]: 445 U.S., at 602-603
