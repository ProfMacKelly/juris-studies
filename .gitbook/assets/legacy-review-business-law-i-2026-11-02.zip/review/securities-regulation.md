> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/securities-regulation) · Snapshot: 2026-11-02 · Original path: `securities-regulation`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/business-law-i/securities-regulation)

---

# Securities Regulation

## Chapter Content

x

x

x
