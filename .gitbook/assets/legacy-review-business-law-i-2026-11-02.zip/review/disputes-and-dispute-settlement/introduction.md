> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/disputes-and-dispute-settlement/introduction) · Snapshot: 2026-11-02 · Original path: `disputes-and-dispute-settlement/introduction`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/introduction-to-law/readme-1) · [Candidate 2](https://profmackelly.gitbook.io/learn/sourcebooks/introduction-to-law/the-united-states-court-system/introduction) · [Candidate 3](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-procedure/setting-the-stage/introduction) · [Candidate 4](https://profmackelly.gitbook.io/learn/sourcebooks/business-law-i/united-states-court-system/introduction) · [Candidate 5](https://profmackelly.gitbook.io/learn/sourcebooks/business-law-i/business-and-the-united-states-constitution/introduction) · [Candidate 6](https://profmackelly.gitbook.io/learn/sourcebooks/business-law-i/litigation/introduction) · [Candidate 7](https://profmackelly.gitbook.io/learn/sourcebooks/business-law-i/contract-law-sales-contracts-and-warranties/page-2) · [Candidate 8](https://profmackelly.gitbook.io/learn/sourcebooks/business-law-i/tort-law/introduction) · [Candidate 9](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-law/1.1-introduction)

---

# Introduction

Litigation provides an opportunity for each side in a dispute to tell their story to an impartial jury or judge to decide who wins. Business professionals have a responsibility to their company and stakeholders to avoid legal liability. Acting ethically helps achieve this goal. Agreeing to mediation or arbitration may help businesses avoid court. However, litigation may be the only dispute-resolution mechanism available or the one that is best for the situation.

{% hint style="warning" %}
#### Law in Practice

&#x20;Litigation is like any other business effort: you are trying to get someone to see things your way.  The best way to do that is to be likable and persuasive to the judge, other lawyers, and the jury.  Construct your theory of the case early on. Meet your deadlines. Maintain a strict ethical standard in your professional life.  Work hard to explore both sides of the case, and develop a short and compelling statement about why your side should prevail. If you do all that, you will make it easy for others to want to find in your favor. Why does this work?  Because as humans, we want good to prevail.  Be good.&#x20;



\~ Valerie M., magistrate
{% endhint %}

***

<details>

<summary>Attributions and Licensing</summary>

Except where otherwise noted, this page's content is adapted from [Introduction](https://pressbooks.pub/introductiontobusinesslaw/chapter/chapter-3/) in [_Fundamentals of Business Law_ ](https://pressbooks.pub/introductiontobusinesslaw/)by Melissa Randall (2020), used under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). This page is licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). <img src="https://3740340822-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FX7KyXZptCmBnyJBn0ocw%2Fuploads%2FsC0H3i5DKWLdoOKEIY7l%2FCC%20BY%20NC%20SA%20badge.png?alt=media&#x26;token=9d010a86-960f-4d15-9c98-aa8945b9764e" alt="" data-size="line">

</details>
