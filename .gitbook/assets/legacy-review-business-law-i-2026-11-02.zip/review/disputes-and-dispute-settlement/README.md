> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/disputes-and-dispute-settlement) · Snapshot: 2026-11-02 · Original path: `disputes-and-dispute-settlement`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/business-law-i/litigation)

---

# Litigation

{% hint style="success" %}
#### LEARNING OBJECTIVES

1. Identify the parties involved in litigation.
2. Explore the responsibilities of attorneys.
3. Understand the roles and types of juries.
4. Explore the standing requirement.
5. Follow a trial from opening statements to closing arguments.
{% endhint %}

***

## Contents

{% stepper %}
{% step %}
{% content-ref url="disputes-and-dispute-settlement/introduction" %}
[introduction](disputes-and-dispute-settlement/introduction)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="disputes-and-dispute-settlement/the-parties-attorneys-and-jury" %}
[the-parties-attorneys-and-jury](disputes-and-dispute-settlement/the-parties-attorneys-and-jury)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="disputes-and-dispute-settlement/standing" %}
[standing](disputes-and-dispute-settlement/standing)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="disputes-and-dispute-settlement/subject-matter-and-personal-jurisdiction" %}
[subject-matter-and-personal-jurisdiction](disputes-and-dispute-settlement/subject-matter-and-personal-jurisdiction)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="disputes-and-dispute-settlement/venue" %}
[venue](disputes-and-dispute-settlement/venue)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="disputes-and-dispute-settlement/pretrial-procedures" %}
[pretrial-procedures](disputes-and-dispute-settlement/pretrial-procedures)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="disputes-and-dispute-settlement/the-trial-and-appeal" %}
[the-trial-and-appeal](disputes-and-dispute-settlement/the-trial-and-appeal)
{% endcontent-ref %}
{% endstep %}
{% endstepper %}
