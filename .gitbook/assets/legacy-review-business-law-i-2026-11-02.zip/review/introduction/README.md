> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/introduction) · Snapshot: 2026-11-02 · Original path: `introduction`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/introduction-to-law/readme-1) · [Candidate 2](https://profmackelly.gitbook.io/learn/sourcebooks/introduction-to-law/the-united-states-court-system/introduction) · [Candidate 3](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-procedure/setting-the-stage/introduction) · [Candidate 4](https://profmackelly.gitbook.io/learn/sourcebooks/business-law-i/united-states-court-system/introduction) · [Candidate 5](https://profmackelly.gitbook.io/learn/sourcebooks/business-law-i/business-and-the-united-states-constitution/introduction) · [Candidate 6](https://profmackelly.gitbook.io/learn/sourcebooks/business-law-i/litigation/introduction) · [Candidate 7](https://profmackelly.gitbook.io/learn/sourcebooks/business-law-i/contract-law-sales-contracts-and-warranties/page-2) · [Candidate 8](https://profmackelly.gitbook.io/learn/sourcebooks/business-law-i/tort-law/introduction) · [Candidate 9](https://profmackelly.gitbook.io/learn/sourcebooks/criminal-law/1.1-introduction)

---

# 1. Introduction

## Chapter Outline & Outcomes

{% content-ref url="introduction-to-american-law-and-the-legal-system/1.1-the-relationship-between-business-and-law" %}
[1.1-the-relationship-between-business-and-law](introduction-to-american-law-and-the-legal-system/1.1-the-relationship-between-business-and-law)
{% endcontent-ref %}

{% content-ref url="introduction/1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis" %}
[1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis](introduction/1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis)
{% endcontent-ref %}

