> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/introduction/1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis) · Snapshot: 2026-11-02 · Original path: `introduction/1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis`

---

# 1.2 Preparing to Understand Legal Thinking, Reasoning & Analysis

Legal reasoning skills improve the ability to (1) spot and distinguish between relevant and irrelevant facts and evidence in a particular set of circumstances, and (2) develop the ability to communicate thoughts and arguments clearly and persuasively. And while these skills are important for business students and [professionals](../introduction-to-american-law-and-the-legal-system/1.1-the-relationship-between-business-and-law), they are just as translatable and applicable to everyday life.

{% embed url="https://youtu.be/ByPJtMjlvyQ" %}
"[Legal Reasoning as a Life Skill](https://youtu.be/ByPJtMjlvyQ)." YouTube, uploaded by OJEN ROEJ, 12 July 2012. \
(Permissions: [YouTube Terms of Service](https://www.youtube.com/t/terms))
{% endembed %}

## Section Outline

{% content-ref url="1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.2.1-introduction-to-deductive-rule-based-reasoning" %}
[1.2.1-introduction-to-deductive-rule-based-reasoning](1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.2.1-introduction-to-deductive-rule-based-reasoning)
{% endcontent-ref %}

{% content-ref url="broken-reference" %}
[Broken link](broken-reference)
{% endcontent-ref %}

{% content-ref url="broken-reference" %}
[Broken link](broken-reference)
{% endcontent-ref %}

{% content-ref url="1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.2.4-avoid-bald-assertions" %}
[1.2.4-avoid-bald-assertions](1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.2.4-avoid-bald-assertions)
{% endcontent-ref %}

{% content-ref url="1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.2.5-issue-spotting" %}
[1.2.5-issue-spotting](1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.2.5-issue-spotting)
{% endcontent-ref %}

***

<details>

<summary>Licensing</summary>

[ <img src="https://chooser-beta.creativecommons.org/img/cc-logo.f0ab4ebe.svg" alt="" data-size="line"><img src="https://chooser-beta.creativecommons.org/img/cc-by.21b728bb.svg" alt="" data-size="line"><img src="https://chooser-beta.creativecommons.org/img/cc-nc.218f18fc.svg" alt="" data-size="line"><img src="https://chooser-beta.creativecommons.org/img/cc-sa.d1572b71.svg" alt="" data-size="line">](https://creativecommons.org/licenses/by-nc-sa/4.0/?ref=chooser-v1)

Except where otherwise noted, [Preparing to Understand Legal Thinking, Reasoning & Analysis](1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis) by Matthew L. Mac Kelly is licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/?ref=chooser-v1).

<img src="https://3740340822-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FX7KyXZptCmBnyJBn0ocw%2Fuploads%2FsC0H3i5DKWLdoOKEIY7l%2FCC%20BY%20NC%20SA%20badge.png?alt=media&#x26;token=9d010a86-960f-4d15-9c98-aa8945b9764e" alt="" data-size="line">

</details>

