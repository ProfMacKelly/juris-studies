> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/unit-8-other-administrative-liability-issues/bonenberger-v.-plymouth-township) · Snapshot: 2026-11-02 · Original path: `unit-8-other-administrative-liability-issues/bonenberger-v.-plymouth-township`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/cj-liability/unit-8-other-administrative-liability-issues/bonenberger-v.-plymouth-township)

---

# Bonenberger v. Plymouth Township

