> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/good-faith-defense/malley-v.-briggs) · Snapshot: 2026-11-02 · Original path: `unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/good-faith-defense/malley-v.-briggs`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/cj-liability/unit-4-defenses-to-civil-litigation-and-risk-management/immunity-absolute-and-qualified/malley-v.-briggs) · [Candidate 2](https://profmackelly.gitbook.io/learn/sourcebooks/cj-liability/unit-4-defenses-to-civil-litigation-and-risk-management/good-faith-defense/malley-v.-briggs)

---

# Malley v. Briggs

