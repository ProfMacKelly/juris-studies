> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally) · Snapshot: 2026-11-02 · Original path: `unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally`

---

# Absolute and Qualified Immunity, Generally

