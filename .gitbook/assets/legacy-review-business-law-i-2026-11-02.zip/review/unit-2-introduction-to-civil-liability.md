> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/unit-2-introduction-to-civil-liability) · Snapshot: 2026-11-02 · Original path: `unit-2-introduction-to-civil-liability`

---

# Unit 2: Introduction to Civil Liability

