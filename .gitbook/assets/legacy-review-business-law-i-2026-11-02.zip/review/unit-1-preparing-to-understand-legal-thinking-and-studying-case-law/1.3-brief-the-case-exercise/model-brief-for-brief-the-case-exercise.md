> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.3-brief-the-case-exercise/model-brief-for-brief-the-case-exercise) · Snapshot: 2026-11-02 · Original path: `unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.3-brief-the-case-exercise/model-brief-for-brief-the-case-exercise`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/primers/reading-briefing/brief-the-case-exercise/model-brief-for-brief-the-case-exercise)

---

# Model Brief for Brief the Case Exercise

