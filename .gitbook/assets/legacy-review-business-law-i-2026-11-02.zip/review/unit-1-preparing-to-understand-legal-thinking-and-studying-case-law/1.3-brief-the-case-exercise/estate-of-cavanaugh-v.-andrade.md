> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.3-brief-the-case-exercise/estate-of-cavanaugh-v.-andrade) · Snapshot: 2026-11-02 · Original path: `unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.3-brief-the-case-exercise/estate-of-cavanaugh-v.-andrade`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/primers/reading-briefing/brief-the-case-exercise/estate-of-cavanaugh-v.-andrade) · [Candidate 2](https://profmackelly.gitbook.io/learn/sourcebooks/cj-liability/unit-4-defenses-to-civil-litigation-and-risk-management/immunity-absolute-and-qualified/estate-of-cavanaugh-v.-andrade)

---

# Estate of Cavanaugh v. Andrade

