> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park/annotated-case-brief-mills-v.-city-of-overland-park) · Snapshot: 2026-11-02 · Original path: `unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park/annotated-case-brief-mills-v.-city-of-overland-park`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/primers/reading-briefing/annotated-cases-briefs/example-2-mills-v.-city-of-overland-park/annotated-case-brief-mills-v.-city-of-overland-park)

---

# Annotated Case Brief: Mills v. City of Overland Park

