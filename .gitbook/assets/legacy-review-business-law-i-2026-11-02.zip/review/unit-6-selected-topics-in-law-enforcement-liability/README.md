> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/unit-6-selected-topics-in-law-enforcement-liability) · Snapshot: 2026-11-02 · Original path: `unit-6-selected-topics-in-law-enforcement-liability`

---

# Unit 6: Selected Topics in Law Enforcement Liability

