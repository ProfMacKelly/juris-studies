> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/unit-6-selected-topics-in-law-enforcement-liability/graham-v.-connor) · Snapshot: 2026-11-02 · Original path: `unit-6-selected-topics-in-law-enforcement-liability/graham-v.-connor`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/cj-liability/unit-6-selected-topics-in-law-enforcement-liability/graham-v.-connor)

---

# Graham v. Connor

