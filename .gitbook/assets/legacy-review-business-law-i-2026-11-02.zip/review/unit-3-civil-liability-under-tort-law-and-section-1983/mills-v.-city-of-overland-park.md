> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/unit-3-civil-liability-under-tort-law-and-section-1983/mills-v.-city-of-overland-park) · Snapshot: 2026-11-02 · Original path: `unit-3-civil-liability-under-tort-law-and-section-1983/mills-v.-city-of-overland-park`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/cj-liability/civil-liability-under-tort-law-and-1983/mills-v.-city-of-overland-park)

---

# Mills v. City of Overland Park

