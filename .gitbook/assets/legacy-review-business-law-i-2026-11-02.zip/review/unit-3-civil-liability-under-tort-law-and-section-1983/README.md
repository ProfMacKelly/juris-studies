> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/unit-3-civil-liability-under-tort-law-and-section-1983) · Snapshot: 2026-11-02 · Original path: `unit-3-civil-liability-under-tort-law-and-section-1983`

---

# Unit 3: Civil Liability under Tort Law and "Section § 1983"

