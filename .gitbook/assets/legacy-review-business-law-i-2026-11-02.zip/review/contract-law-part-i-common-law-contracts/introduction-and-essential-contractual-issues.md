> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/contract-law-part-i-common-law-contracts/introduction-and-essential-contractual-issues) · Snapshot: 2026-11-02 · Original path: `contract-law-part-i-common-law-contracts/introduction-and-essential-contractual-issues`

---

# Introduction and Essential Contractual Issues

### Overview

"**Contract**" is probably the most familiar legal concept in our society because it is so central to the essence of our political, economic, and social life. In common parlance, "contract" is used interchangeably with _agreement_, _bargain_, _undertaking_, or _deal_. Whatever the word, the concept it embodies is our notion of freedom to pursue our own lives together with others. So commonplace is the concept of contract—and our freedom to make contracts with each other—that it is difficult to imagine a time when contracts were rare, when people’s everyday associations with one another were not freely determined.

Modern capitalism, indeed, would not be possible without contract law, and contract law may be viewed economically as well as culturally. In [_An Economic Analysis of Law_](https://archive.org/details/economicanalysis0000posn), Judge Richard A. Posner (a former University of Chicago law professor) suggests that contract law performs three significant economic functions:

1. It helps maintain incentives for individuals to exchange goods and services efficiently.&#x20;
2. It reduces the costs of economic transactions because its very existence means that the parties need not go to the trouble of negotiating a variety of rules and terms already spelled out.&#x20;
3. It alerts the parties to troubles that have arisen in the past, thus making it easier to plan the transactions more intelligently and avoid potential pitfalls.

### The Definition of _Contract_

Although businesses tend to use the terms “agreement” and “contract” interchangeably, as noted above, the terms have very different legal meanings. An **agreement** is a mutual understanding between two or more parties about their rights and duties toward each other, which involves the combination of an [offer and an acceptance of the offer](https://profmackelly.gitbook.io/learn-business-law-i/contract-law-part-i-common-law-contracts/contract-elements).

On the other hand, as a practical matter, a **contract** is a _**legally enforceable**_ promise. More specifically, the legal definition of a contract is "a promise or a set of promises for the breach of which the law gives a remedy, or the performance of which **the law in some way recognizes as a duty**."[<sup>1</sup>](#user-content-fn-1)[^1] Accordingly, it is correct to infer that not all promises are enforceable. The law takes into account the way in which contracts are made, by whom they are made, and for [what purposes they are made](#user-content-fn-2)[^2].&#x20;

{% hint style="info" %}
All contracts are agreements, but not all agreements are contracts.
{% endhint %}

When contracts are [**breached**](https://profmackelly.gitbook.io/learn-business-law-i/contract-law-part-i-common-law-contracts/performance-and-breach)—i.e., one or more parties to the contract failed to perform their agreed-upon obligations—the injured party can seek damages. In contracts, the concept of damages usually refers to an amount that would make that party whole again.

Generally speaking, contracts are a form of **private law**, because the terms of the contract are binding on the parties to the contract and no one else. Parties may enter into contracts for whatever they wish and under any terms that they agree on. In other words, parties may assent to agreements even if those agreements represent a "bad" bargain for one or more parties.

Contracts may restrict parties’ future activity. For example, a [non-compete clause](#user-content-fn-3)[^3] in an employment contract may be enforceable in the future against an employee after termination of employment.

However, contracts that are [illegal ](../affirmative-defenses-to-breach-claims#illegality)or against public policy are not enforceable.

Contract law performs three significant economic functions:

1. It helps individuals and businesses exchange goods and services efficiently.
2. It reduces the costs of economic transactions because parties do not need to negotiate a variety of rules and terms with each separate transaction.
3. It alerts the parties to problems that have arisen in the past, making it easier to avoid potential pitfalls.

### Essential Issues in a Contractual Relationship

Although contract law has many wrinkles and nuances, there are a few essential issues that arise:

* Did the parties create a valid contract?&#x20;
  * There are a number of basic requirements necessary for a contract to be valid, including:
    * Assent: (1) **mutual assent** (an agreement, which is the combination of an [offer and acceptance](https://profmackelly.gitbook.io/learn-business-law-i/contract-law-part-i-common-law-contracts/contract-elements)) and (2) **real assent** (i.e., the agreement did not arise out of duress, undue influence, misrepresentation, mistake, or incapacity). (Also, even if both mutual and real assent exist, the contract also must be "[legal](../affirmative-defenses-to-breach-claims#illegality)"; and
    * [Consideration](../contract-elements#consideration).
* What does the contract mean?
* Is the contract in the proper [form ](../affirmative-defenses-to-breach-claims#statute-of-frauds)to carry out this meaning?&#x20;
  * Sometimes contracts need to be in writing (or evidenced by some writing), or they can’t be enforced. Sometimes it isn’t clear what the contract means, and a court has to figure that out.&#x20;
* Do persons other than the contracting parties have rights or duties under the contract?&#x20;
  * Can the right to receive a benefit from the contract be assigned, and can the duties be delegated so that a new person is responsible?&#x20;
  * Can someone not a party to the contract sue to enforce its terms?&#x20;
* How do [contractual duties terminate](https://profmackelly.gitbook.io/learn-business-law-i/contract-law-part-i-common-law-contracts/performance-and-breach)?
* What [remedies ](https://profmackelly.gitbook.io/learn-business-law-i/contract-law-part-i-common-law-contracts/remedies)are available if a party has breached the contract?&#x20;

Together, the answers to these questions determine the rights and obligations of contracting parties.

{% hint style="warning" %}
#### Law in Practice

We live in a world of contracts, which are the bread and butter of business transactions. However, many consumers, employees, and small businesses are afraid to read and understand contracts. That fear allows others to take advantage of them. Take the time to read contracts provided to you. Ask questions about anything you don’t understand _before_ you sign. Have the courage to revise and edit contracts to ensure your interests are protected. Or even write your own. It’s not hard and the more you do it, the more confidence you will have to negotiate business transactions and protect your interests.&#x20;



\~ Darnell T., attorney
{% endhint %}

***

<details>

<summary>Attributions and Licensing</summary>

Except where otherwise noted, this page's content is adapted from:

* [Contracts](https://pressbooks.pub/introductiontobusinesslaw/chapter/chapter-10/) in [_Fundamentals of Business Law_ ](https://pressbooks.pub/introductiontobusinesslaw/)by Melissa Randall (2020), used under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).  <img src="https://3740340822-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FX7KyXZptCmBnyJBn0ocw%2Fuploads%2FsC0H3i5DKWLdoOKEIY7l%2FCC%20BY%20NC%20SA%20badge.png?alt=media&#x26;token=9d010a86-960f-4d15-9c98-aa8945b9764e" alt="" data-size="line">
* [General Perspectives on Contracts](https://2012books.lardbucket.org/books/the-legal-environment-and-foundations-of-business-law/s11-01-general-perspectives-on-contra.html) in [_The Legal Environment and Foundations of Business Law_](https://2012books.lardbucket.org/books/the-legal-environment-and-foundations-of-business-law/index.html) by Mayer, D., Warner, D. M., Siedel, G. J., Lieberman, J. K., & Martina, A. R., used under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).&#x20;

This page is licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).  <img src="https://3740340822-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FX7KyXZptCmBnyJBn0ocw%2Fuploads%2FsC0H3i5DKWLdoOKEIY7l%2FCC%20BY%20NC%20SA%20badge.png?alt=media&#x26;token=9d010a86-960f-4d15-9c98-aa8945b9764e" alt="" data-size="line">

</details>

[^1]: Emphasis added; _Restatement of the Law, Second, Contracts_, [§ 1](https://archive.org/details/restatementoflaw0012unse). American Law Institute, 1981.

[^2]: For example, in many states, a wager (bet) is unenforceable, even though both parties “shake” on the bet.

[^3]: a contract provision in which "one party promises not to engage in conduct that would increase competition for the other party for a specific period of time." [Wex, noncompetition agreement](https://www.law.cornell.edu/wex/noncompetition_agreement).
