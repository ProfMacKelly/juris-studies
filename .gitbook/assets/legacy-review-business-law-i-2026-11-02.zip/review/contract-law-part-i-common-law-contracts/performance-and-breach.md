> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/contract-law-part-i-common-law-contracts/performance-and-breach) · Snapshot: 2026-11-02 · Original path: `contract-law-part-i-common-law-contracts/performance-and-breach`

Possible main-version counterparts: [Candidate 1](https://profmackelly.gitbook.io/learn/sourcebooks/business-law-i/common-law-contracts/performance-and-breach)

---

# Performance and Breach

