> **LEGACY REVIEW COPY — Juris Studies is the main version.** This reading is preserved for comparison, including any incomplete text, broken references or merge-conflict markers.

Source: [Business Law I](https://profmackelly.gitbook.io/learn-business-law-i/contract-law-part-i-common-law-contracts/contract-classifications) · Snapshot: 2026-11-02 · Original path: `contract-law-part-i-common-law-contracts/contract-classifications`

---

# Contract Classifications

