# Business Law I — Legacy Review Archive

> REVIEW ARCHIVE. Juris Studies is the main version. These snapshots are retained for editorial comparison, not as the approved teaching version.

Snapshot date: 2026-11-02. Source space: `X7KyXZptCmBnyJBn0ocw`. Source revision: `8Qt4lc95MjhbVcfoo4c1`.

Legacy site: https://profmackelly.gitbook.io/learn-business-law-i/

The originals/ folder contains the exact Markdown returned by the pinned GitBook revision. These are API Markdown snapshots, not byte-for-byte exports of repository files. The review/ folder contains the same text with resolvable legacy-relative links made absolute and a source/review notice added. Footnotes, attributions and conflict text remain present. Media stays linked to the existing public source URLs; binary media is not bundled.

pages.csv lists all retained readings, original visibility, the comparison classification and possible Juris Studies counterparts. Candidate counterparts are aids for human review. No title match does not prove a topic is missing or unique.

## Readings

- [Business Law I: A Sourcebook](review/README.md) — no-title-match
- [Front Matter](review/front-matter.md) — different-review
- [Attributions/Licensing, Hints, Videos ...](review/attributions-licensing-hints-videos-....md) — no-title-match — originally hidden
- [1. Introduction](review/introduction/README.md) — different-review — originally hidden
- [1.2 Preparing to Understand Legal Thinking, Reasoning & Analysis](review/introduction/1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis/README.md) — no-title-match — originally hidden
- [1.2.1 Introduction to Deductive (Rule-Based) Reasoning](review/introduction/1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.2.1-introduction-to-deductive-rule-based-reasoning.md) — different-review — originally hidden
- [1.2.2 Introduction to Analogical Reasoning—A Type of Inductive Reasoning](review/introduction/1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.2.2-introduction-to-analogical-reasoning-a-type-of-inductive-reasoning.md) — different-review — originally hidden
- [1.2.3 Is a Hot Dog a Sandwich?](review/introduction/1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.2.3-is-a-hot-dog-a-sandwich.md) — different-review — originally hidden
- [1.2.4 Avoid Bald Assertions](review/introduction/1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.2.4-avoid-bald-assertions.md) — different-review — originally hidden
- [1.2.5 Issue Spotting](review/introduction/1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis/1.2.5-issue-spotting.md) — no-title-match — originally hidden
- [Endnotes: Landing Page, Preface & Introduction](review/introduction/endnotes-landing-page-and-introduction.md) — no-title-match — originally hidden
- [Introduction to the Law & Legal Systems](review/introduction-to-american-law-and-the-legal-system/README.md) — different-review
- [Why Legal Literacy is Fundamental to Business Success](review/introduction-to-american-law-and-the-legal-system/1.1-the-relationship-between-business-and-law.md) — different-review
- [Sources of Law](review/introduction-to-american-law-and-the-legal-system/sources-of-law.md) — different-review
- [The United States Court System](review/the-united-states-court-system/README.md) — different-review
- [Introduction](review/the-united-states-court-system/introduction.md) — different-review
- [Litigation](review/disputes-and-dispute-settlement/README.md) — different-review
- [Introduction](review/disputes-and-dispute-settlement/introduction.md) — different-review
- [Contract Law: Common Law Contracts](review/contract-law-part-i-common-law-contracts/README.md) — different-review
- [Introduction and Essential Contractual Issues](review/contract-law-part-i-common-law-contracts/introduction-and-essential-contractual-issues.md) — no-title-match
- [Contract Classifications](review/contract-law-part-i-common-law-contracts/contract-classifications.md) — no-title-match — originally hidden
- [Contract Elements](review/contract-law-part-i-common-law-contracts/contract-elements/README.md) — different-review
- [Introduction & Terminology](review/contract-law-part-i-common-law-contracts/contract-elements/introduction-and-terminology.md) — no-title-match
- [The Offer](review/contract-law-part-i-common-law-contracts/contract-elements/the-offer.md) — different-review
- [Performance and Breach](review/contract-law-part-i-common-law-contracts/performance-and-breach.md) — different-review — originally hidden
- [Affirmative Defenses to Breach Claims](review/contract-law-part-i-common-law-contracts/affirmative-defenses-to-breach-claims.md) — different-review — originally hidden
- [Remedies](review/contract-law-part-i-common-law-contracts/remedies.md) — different-review — originally hidden
- [Business Ethics and Social Responsibility](review/business-ethics-and-social-responsibility.md) — different-review — originally hidden
- [Business and the United States Constitution](review/business-and-the-united-states-constitution.md) — different-review — originally hidden
- [Criminal Liability](review/criminal-liability.md) — different-review — originally hidden
- [Tort Law](review/tort-law.md) — different-review — originally hidden
- [Contract Law, Part II—Sales Contracts](review/contract-law-part-ii-sales-contracts.md) — no-title-match — originally hidden
- [Employment and Labor Law](review/employment-and-labor-law.md) — different-review — originally hidden
- [Government Regulation](review/government-regulation.md) — different-review — originally hidden
- [Antitrust Law](review/antitrust-law.md) — different-review — originally hidden
- [Unfair Trade Practices](review/unfair-trade-practices.md) — different-review — originally hidden
- [International Law](review/international-law.md) — different-review — originally hidden
- [Securities Regulation](review/securities-regulation.md) — different-review — originally hidden
- [mypage (4).html](review/mypage-4-.html.md) — no-title-match — originally hidden
- [Your Obligation to Know the Law](review/your-obligation-to-know-the-law.md) — no-title-match — originally hidden
- [Unit 1: Preparing to Understand Legal Thinking and Studying Case Law](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/README.md) — no-title-match — originally hidden
- [1.1 Primers on Legal Thinking, Reasoning & Analysis](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.1-primers-on-legal-thinking-reasoning-and-analysis/README.md) — no-title-match — originally hidden
- [1.1.1 Introduction to Deductive (Rule-Based) Reasoning](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.1-primers-on-legal-thinking-reasoning-and-analysis/1.1.1-introduction-to-deductive-rule-based-reasoning.md) — different-review — originally hidden
- [1.1.2 Introduction to Analogical Reasoning—A Type of Inductive Reasoning](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.1-primers-on-legal-thinking-reasoning-and-analysis/1.1.2-introduction-to-analogical-reasoning-a-type-of-inductive-reasoning.md) — different-review — originally hidden
- [1.1.3 Is a Hot Dog a Sandwich?](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.1-primers-on-legal-thinking-reasoning-and-analysis/1.1.3-is-a-hot-dog-a-sandwich.md) — different-review — originally hidden
- [1.1.4 Avoid Bald Assertions](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.1-primers-on-legal-thinking-reasoning-and-analysis/1.1.4-avoid-bald-assertions.md) — different-review — originally hidden
- [1.2 Introduction Reading & Briefing Cases](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/README.md) — no-title-match — originally hidden
- [1.2.1 How to Read a Case](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/1.2.1-how-to-read-a-case.md) — different-review — originally hidden
- [1.2.2 Case Briefing Tutorials](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/1.2.2-case-briefing-tutorials.md) — different-review — originally hidden
- [1.2.3 Annotated Cases & Annotated Examples of Case Briefs](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/README.md) — different-review — originally hidden
- [Example 1: Florida v. Jardines](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-1-florida-v.-jardines/README.md) — different-review — originally hidden
- [Annotated Case: Florida v. Jardines](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-1-florida-v.-jardines/annotated-case-florida-v.-jardines.md) — different-review — originally hidden
- [Annotated Case Brief: Florida v. Jardines](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-1-florida-v.-jardines/annotated-case-brief-florida-v.-jardines.md) — different-review — originally hidden
- [Example 2: Mills v. City of Overland Park](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park/README.md) — different-review — originally hidden
- [Annotated Case: Mills v. City of Overland Park](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park/annotated-case-mills-v.-city-of-overland-park.md) — different-review — originally hidden
- [Annotated Case Brief: Mills v. City of Overland Park](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-2-mills-v.-city-of-overland-park/annotated-case-brief-mills-v.-city-of-overland-park.md) — different-review — originally hidden
- [Example 3: Malley v. Briggs](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs/README.md) — different-review — originally hidden
- [Annotated Case: Malley v. Briggs](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs/annotated-case-malley-v.-briggs.md) — different-review — originally hidden
- [Annotated Case Brief: Malley v. Briggs](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.2-introduction-reading-and-briefing-cases/1.2.3-annotated-cases-and-annotated-examples-of-case-briefs/example-3-malley-v.-briggs/annotated-case-brief-malley-v.-briggs.md) — different-review — originally hidden
- [1.3 Brief the Case Exercise](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.3-brief-the-case-exercise/README.md) — different-review — originally hidden
- [Estate of Cavanaugh v. Andrade](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.3-brief-the-case-exercise/estate-of-cavanaugh-v.-andrade.md) — different-review — originally hidden
- [Model Brief for Brief the Case Exercise](review/unit-1-preparing-to-understand-legal-thinking-and-studying-case-law/1.3-brief-the-case-exercise/model-brief-for-brief-the-case-exercise.md) — different-review — originally hidden
- [Unit 2: Introduction to Civil Liability](review/unit-2-introduction-to-civil-liability.md) — no-title-match — originally hidden
- [Unit 3: Civil Liability under Tort Law and "Section § 1983"](review/unit-3-civil-liability-under-tort-law-and-section-1983/README.md) — no-title-match — originally hidden
- [Govea v. City of Norcross](review/unit-3-civil-liability-under-tort-law-and-section-1983/govea-v.-city-of-norcross.md) — different-review — originally hidden
- [Strickland v. University of North Carolina](review/unit-3-civil-liability-under-tort-law-and-section-1983/strickland-v.-university-of-north-carolina.md) — different-review — originally hidden
- [Estate of Cavanaugh v. Andrade](review/unit-3-civil-liability-under-tort-law-and-section-1983/estate-of-cavanaugh-v.-andrade.md) — different-review — originally hidden
- [Mills v. City of Overland Park](review/unit-3-civil-liability-under-tort-law-and-section-1983/mills-v.-city-of-overland-park.md) — different-review — originally hidden
- [Other Cases](review/unit-3-civil-liability-under-tort-law-and-section-1983/other-cases.md) — different-review — originally hidden
- [Unit 4: Defenses to Civil Litigation and Risk Management](review/unit-4-defenses-to-civil-litigation-and-risk-management/README.md) — no-title-match — originally hidden
- [Absolute and Qualified Immunity, Generally](review/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/README.md) — no-title-match — originally hidden
- [Articles](review/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/articles.md) — different-review — originally hidden
- [Cleavinger v. Saxner](review/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/cleavinger-v.-saxner.md) — different-review — originally hidden
- [Anderson v. Creighton](review/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/anderson-v.-creighton.md) — different-review — originally hidden
- [Estate of Cavanaugh v. Andrade](review/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/estate-of-cavanaugh-v.-andrade.md) — different-review — originally hidden
- [Malley v. Briggs](review/unit-4-defenses-to-civil-litigation-and-risk-management/absolute-and-qualified-immunity-generally/good-faith-defense/malley-v.-briggs.md) — different-review — originally hidden
- [Unit 5: Vicarious Liability Principles](review/unit-5-vicarious-liability-principles/README.md) — no-title-match — originally hidden
- [Monell v. Dept. of Social Services](review/unit-5-vicarious-liability-principles/monell-v.-dept.-of-social-services.md) — different-review — originally hidden
- [Forrest v. Parry](review/unit-5-vicarious-liability-principles/forrest-v.-parry.md) — different-review — originally hidden
- [Clipper v. Takoma Park](review/unit-5-vicarious-liability-principles/clipper-v.-takoma-park.md) — different-review — originally hidden
- [Unit 6: Selected Topics in Law Enforcement Liability](review/unit-6-selected-topics-in-law-enforcement-liability/README.md) — no-title-match — originally hidden
- [Graham v. Connor](review/unit-6-selected-topics-in-law-enforcement-liability/graham-v.-connor.md) — different-review — originally hidden
- [Wilson v. City of Lafayette](review/unit-6-selected-topics-in-law-enforcement-liability/wilson-v.-city-of-lafayette.md) — different-review — originally hidden
- [Scott v. Harris](review/unit-6-selected-topics-in-law-enforcement-liability/scott-v.-harris.md) — different-review — originally hidden
- [Unit 7: Selected Topics in Correctional Liability](review/unit-7-selected-topics-in-correctional-liability.md) — no-title-match — originally hidden
- [Unit 8: Other Administrative Liability Issues](review/unit-8-other-administrative-liability-issues/README.md) — no-title-match — originally hidden
- [Bonenberger v. Plymouth Township](review/unit-8-other-administrative-liability-issues/bonenberger-v.-plymouth-township.md) — different-review — originally hidden
- [Mys v. Michigan Dept. of State Police](review/unit-8-other-administrative-liability-issues/mys-v.-michigan-dept.-of-state-police.md) — different-review — originally hidden
- [Sources Referenced in Annotations](review/sources-referenced-in-annotations.md) — different-review — originally hidden