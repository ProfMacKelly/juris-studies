# 1. Introduction

## Chapter Outline & Outcomes

{% content-ref url="introduction-to-american-law-and-the-legal-system/1.1-the-relationship-between-business-and-law" %}
[1.1-the-relationship-between-business-and-law](introduction-to-american-law-and-the-legal-system/1.1-the-relationship-between-business-and-law)
{% endcontent-ref %}

{% content-ref url="introduction/1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis" %}
[1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis](introduction/1.2-preparing-to-understand-legal-thinking-reasoning-and-analysis)
{% endcontent-ref %}

