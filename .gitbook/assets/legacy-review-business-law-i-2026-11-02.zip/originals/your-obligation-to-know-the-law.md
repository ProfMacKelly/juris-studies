# Your Obligation to Know the Law

