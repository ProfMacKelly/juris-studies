# Introduction to the Law & Legal Systems

<figure><img src="https://3740340822-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FX7KyXZptCmBnyJBn0ocw%2Fuploads%2FvFJQHIaqRo5tuGqwD1oZ%2F800px-US_Supreme_Court_-_corrected.jpg?alt=media&#x26;token=6b66ac45-09b7-4fa0-8682-799e39614781" alt="Picture of the front facade of the United States Supreme Court building in Washington D.C." width="563"><figcaption><p>"US Supreme Court" by <a href="https://commons.wikimedia.org/wiki/File:US_Supreme_Court_-_corrected.jpg">Jarek Tuszyński</a> is licensed <a href="https://creativecommons.org/licenses/by-sa/3.0/deed.en">CC BY-SA 3.0</a>)</p></figcaption></figure>

{% hint style="success" %}
#### LEARING OBJECTIVES

1. Understand the various functions of the American legal system.
2. Describe the foundation and sources that establish American law.
3. Describe the types of modern legal systems in the world.
4. Explain the primary sources of law in the United States.
{% endhint %}

## Contents

{% stepper %}
{% step %}
{% content-ref url="introduction-to-american-law-and-the-legal-system/1.1-the-relationship-between-business-and-law" %}
[1.1-the-relationship-between-business-and-law](introduction-to-american-law-and-the-legal-system/1.1-the-relationship-between-business-and-law)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="introduction-to-american-law-and-the-legal-system/2.2-law-and-its-functions" %}
[2.2-law-and-its-functions](introduction-to-american-law-and-the-legal-system/2.2-law-and-its-functions)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="introduction-to-american-law-and-the-legal-system/2.3-modern-legal-systems-of-the-world" %}
[2.3-modern-legal-systems-of-the-world](introduction-to-american-law-and-the-legal-system/2.3-modern-legal-systems-of-the-world)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="introduction-to-american-law-and-the-legal-system/sources-of-law" %}
[sources-of-law](introduction-to-american-law-and-the-legal-system/sources-of-law)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="introduction-to-american-law-and-the-legal-system/important-business-laws-and-regulations" %}
[important-business-laws-and-regulations](introduction-to-american-law-and-the-legal-system/important-business-laws-and-regulations)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="introduction-to-american-law-and-the-legal-system/1-assessment-questions" %}
[1-assessment-questions](introduction-to-american-law-and-the-legal-system/1-assessment-questions)
{% endcontent-ref %}
{% endstep %}
{% endstepper %}
