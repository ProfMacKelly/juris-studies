# Contract Law: Common Law Contracts



{% hint style="success" %}
## LEARNING OBJECTIVES

1. Explain what constitutes a contract.
2. Understand how a contract is formed.
3. Know the defenses to performance of a contract.
4. Understand breach of contract and its consequences.
5. Identify remedies for breach of contract.
{% endhint %}

### Content

{% stepper %}
{% step %}
{% content-ref url="contract-law-part-i-common-law-contracts/introduction-and-essential-contractual-issues" %}
[introduction-and-essential-contractual-issues](contract-law-part-i-common-law-contracts/introduction-and-essential-contractual-issues)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="contract-law-part-i-common-law-contracts/contract-elements" %}
[contract-elements](contract-law-part-i-common-law-contracts/contract-elements)
{% endcontent-ref %}
{% endstep %}
{% endstepper %}
