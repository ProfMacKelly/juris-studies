# Contract Elements

{% stepper %}
{% step %}
{% content-ref url="contract-elements/introduction-and-terminology" %}
[introduction-and-terminology](contract-elements/introduction-and-terminology)
{% endcontent-ref %}
{% endstep %}

{% step %}
{% content-ref url="contract-elements/the-offer" %}
[the-offer](contract-elements/the-offer)
{% endcontent-ref %}
{% endstep %}
{% endstepper %}

<details>

<summary>Attributions and Licensing</summary>

Except where otherwise noted, this page's content is adapted from:&#x20;

* [What is Law and What Functions Does It Serve ](https://pressbooks.pub/introductiontobusinesslaw/chapter/chapter-1/)in [_Fundamentals of Business Law_ ](https://pressbooks.pub/introductiontobusinesslaw/)by Melissa Randall (2020), used under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).&#x20;
* [The Offer](https://2012books.lardbucket.org/books/the-legal-environment-and-foundations-of-business-law/s12-02-the-offer.html) in [_The Legal Environment and Foundations of Business Law_](https://2012books.lardbucket.org/books/the-legal-environment-and-foundations-of-business-law/index.html) by Mayer, D., Warner, D. M., Siedel, G. J., Lieberman, J. K., & Martina, A. R., used under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).&#x20;

This page is licensed under [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/).  <img src="https://3740340822-files.gitbook.io/~/files/v0/b/gitbook-x-prod.appspot.com/o/spaces%2FX7KyXZptCmBnyJBn0ocw%2Fuploads%2FsC0H3i5DKWLdoOKEIY7l%2FCC%20BY%20NC%20SA%20badge.png?alt=media&#x26;token=9d010a86-960f-4d15-9c98-aa8945b9764e" alt="" data-size="line">

</details>
